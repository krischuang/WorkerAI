--
-- PostgreSQL database dump
--

\restrict IRA9wPhYBlg3h0vhLfvXqbu6BVoIBURTOxpL0y3gh8IpzWhIkghEYrpeJWe3fW0

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg13+1)
-- Dumped by pg_dump version 16.14 (Debian 16.14-1.pgdg13+1)

-- Started on 2026-06-11 07:14:27 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 908 (class 1247 OID 24931)
-- Name: AgentStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."AgentStatus" AS ENUM (
    'idle',
    'running',
    'offline',
    'error'
);


ALTER TYPE public."AgentStatus" OWNER TO postgres;

--
-- TOC entry 905 (class 1247 OID 16702)
-- Name: ClaudePermissionMode; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ClaudePermissionMode" AS ENUM (
    'read_only',
    'workspace_write',
    'full_autonomous'
);


ALTER TYPE public."ClaudePermissionMode" OWNER TO postgres;

--
-- TOC entry 896 (class 1247 OID 16666)
-- Name: CommandStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CommandStatus" AS ENUM (
    'success',
    'failed'
);


ALTER TYPE public."CommandStatus" OWNER TO postgres;

--
-- TOC entry 875 (class 1247 OID 16584)
-- Name: CostLevel; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CostLevel" AS ENUM (
    'low',
    'medium',
    'high'
);


ALTER TYPE public."CostLevel" OWNER TO postgres;

--
-- TOC entry 962 (class 1247 OID 42344)
-- Name: CycleStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."CycleStatus" AS ENUM (
    'idle',
    'scanning',
    'detecting_debt',
    'generating_suggestions',
    'awaiting_approval',
    'executing',
    'reviewing',
    'completed',
    'cancelled',
    'failed'
);


ALTER TYPE public."CycleStatus" OWNER TO postgres;

--
-- TOC entry 953 (class 1247 OID 41368)
-- Name: DebtCategory; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DebtCategory" AS ENUM (
    'architecture',
    'testing',
    'documentation',
    'security',
    'performance'
);


ALTER TYPE public."DebtCategory" OWNER TO postgres;

--
-- TOC entry 950 (class 1247 OID 41359)
-- Name: DebtSeverity; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DebtSeverity" AS ENUM (
    'low',
    'medium',
    'high',
    'critical'
);


ALTER TYPE public."DebtSeverity" OWNER TO postgres;

--
-- TOC entry 956 (class 1247 OID 41380)
-- Name: DebtStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DebtStatus" AS ENUM (
    'open',
    'acknowledged',
    'in_progress',
    'resolved',
    'wont_fix'
);


ALTER TYPE public."DebtStatus" OWNER TO postgres;

--
-- TOC entry 869 (class 1247 OID 16562)
-- Name: Priority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Priority" AS ENUM (
    'P1',
    'P2',
    'P3',
    'P4'
);


ALTER TYPE public."Priority" OWNER TO postgres;

--
-- TOC entry 866 (class 1247 OID 16555)
-- Name: ProjectStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ProjectStatus" AS ENUM (
    'active',
    'paused',
    'archived'
);


ALTER TYPE public."ProjectStatus" OWNER TO postgres;

--
-- TOC entry 941 (class 1247 OID 39718)
-- Name: ReviewStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ReviewStatus" AS ENUM (
    'pending',
    'running',
    'done',
    'incomplete',
    'skipped'
);


ALTER TYPE public."ReviewStatus" OWNER TO postgres;

--
-- TOC entry 944 (class 1247 OID 40501)
-- Name: ScanStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ScanStatus" AS ENUM (
    'running',
    'completed',
    'failed'
);


ALTER TYPE public."ScanStatus" OWNER TO postgres;

--
-- TOC entry 893 (class 1247 OID 16658)
-- Name: ServerStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ServerStatus" AS ENUM (
    'unknown',
    'connected',
    'failed'
);


ALTER TYPE public."ServerStatus" OWNER TO postgres;

--
-- TOC entry 971 (class 1247 OID 43428)
-- Name: SuggestionSourceType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SuggestionSourceType" AS ENUM (
    'scan',
    'debt',
    'review',
    'manual'
);


ALTER TYPE public."SuggestionSourceType" OWNER TO postgres;

--
-- TOC entry 968 (class 1247 OID 43419)
-- Name: SuggestionStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SuggestionStatus" AS ENUM (
    'pending_review',
    'approved',
    'rejected',
    'converted'
);


ALTER TYPE public."SuggestionStatus" OWNER TO postgres;

--
-- TOC entry 872 (class 1247 OID 16572)
-- Name: TaskStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TaskStatus" AS ENUM (
    'pending',
    'running',
    'paused',
    'completed',
    'failed',
    'queued',
    'archived'
);


ALTER TYPE public."TaskStatus" OWNER TO postgres;

--
-- TOC entry 878 (class 1247 OID 16592)
-- Name: TaskType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TaskType" AS ENUM (
    'coding',
    'research',
    'writing',
    'review',
    'maintenance'
);


ALTER TYPE public."TaskType" OWNER TO postgres;

--
-- TOC entry 238 (class 1255 OID 31951)
-- Name: execution_log_search_vector_update(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.execution_log_search_vector_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW."searchVector" = to_tsvector('english',
    COALESCE(NEW."logText", '') || ' ' ||
    COALESCE(NEW."outputSummary", '') || ' ' ||
    COALESCE(NEW."errorMessage", '') || ' ' ||
    COALESCE(NEW."exitReason", '')
  );
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.execution_log_search_vector_update() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 222 (class 1259 OID 24939)
-- Name: Agent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Agent" (
    id text NOT NULL,
    "serverId" text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    "workDir" text NOT NULL,
    "tmuxSession" text NOT NULL,
    status public."AgentStatus" DEFAULT 'offline'::public."AgentStatus" NOT NULL,
    "claudePermissionMode" public."ClaudePermissionMode" DEFAULT 'workspace_write'::public."ClaudePermissionMode" NOT NULL,
    "claudeSessionPct" double precision,
    "claudeSessionResets" text,
    "claudeSessionResetsAt" timestamp(3) without time zone,
    "claudeWeekPct" double precision,
    "claudeWeekResets" text,
    "claudeWeekResetsAt" timestamp(3) without time zone,
    "claudeUsageRaw" text,
    "claudeUsageFetchedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "defaultTaskTimeoutMinutes" integer,
    "consecutiveFailures" integer DEFAULT 0 NOT NULL,
    "healthScore" integer,
    "lastHealthCheckAt" timestamp(3) without time zone,
    "autoRecovery" boolean DEFAULT false NOT NULL,
    "lastRecoveryAt" timestamp(3) without time zone,
    "maxRecoveryAttempts" integer DEFAULT 3 NOT NULL,
    "recoveryAttempts" integer DEFAULT 0 NOT NULL,
    "autoPauseEnabled" boolean DEFAULT true NOT NULL,
    "pausedAt" timestamp(3) without time zone,
    "pausedDueToUsage" boolean DEFAULT false NOT NULL,
    "claudeLastRefreshStatus" text,
    "claudeUsageCreditsEnabled" boolean
);


ALTER TABLE public."Agent" OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 35671)
-- Name: AgentUsageSnapshot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AgentUsageSnapshot" (
    id text NOT NULL,
    "agentId" text NOT NULL,
    "usagePercent" double precision,
    "resetTime" text,
    "resetAt" timestamp(3) without time zone,
    "usageCreditsEnabled" boolean,
    "captureStatus" text DEFAULT 'unknown'::text NOT NULL,
    "capturedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "rawOutput" text,
    "cleanedOutput" text
);


ALTER TABLE public."AgentUsageSnapshot" OWNER TO postgres;

--
-- TOC entry 227 (class 1259 OID 30249)
-- Name: AuditEvent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AuditEvent" (
    id text NOT NULL,
    "entityType" text NOT NULL,
    "entityId" text NOT NULL,
    "eventType" text NOT NULL,
    "actorType" text DEFAULT 'system'::text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."AuditEvent" OWNER TO postgres;

--
-- TOC entry 219 (class 1259 OID 16634)
-- Name: DailyReport; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DailyReport" (
    id text NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedCount" integer DEFAULT 0 NOT NULL,
    "failedCount" integer DEFAULT 0 NOT NULL,
    "runningCount" integer DEFAULT 0 NOT NULL,
    "pendingCount" integer DEFAULT 0 NOT NULL,
    "reportText" text,
    "topProjectId" text,
    "topProjectName" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "queuedCount" integer DEFAULT 0 NOT NULL,
    "retriedCount" integer DEFAULT 0 NOT NULL,
    "timedOutCount" integer DEFAULT 0 NOT NULL,
    "recoveryCount" integer DEFAULT 0 NOT NULL,
    "avgExecutionMinutes" double precision,
    "activeServerCount" integer DEFAULT 0 NOT NULL,
    "activeAgentCount" integer DEFAULT 0 NOT NULL,
    "generatedBy" text DEFAULT 'manual'::text NOT NULL,
    "periodStart" timestamp(3) without time zone,
    "periodEnd" timestamp(3) without time zone
);


ALTER TABLE public."DailyReport" OWNER TO postgres;

--
-- TOC entry 233 (class 1259 OID 41391)
-- Name: DebtItem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DebtItem" (
    id text NOT NULL,
    "projectId" text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    severity public."DebtSeverity" DEFAULT 'medium'::public."DebtSeverity" NOT NULL,
    category public."DebtCategory" DEFAULT 'architecture'::public."DebtCategory" NOT NULL,
    status public."DebtStatus" DEFAULT 'open'::public."DebtStatus" NOT NULL,
    evidence jsonb DEFAULT '{}'::jsonb NOT NULL,
    "resolvedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."DebtItem" OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 16625)
-- Name: ExecutionLog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ExecutionLog" (
    id text NOT NULL,
    "taskId" text NOT NULL,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "finishedAt" timestamp(3) without time zone,
    status public."TaskStatus" NOT NULL,
    "logText" text,
    "errorMessage" text,
    "outputSummary" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "failureReason" text,
    "retryNumber" integer DEFAULT 0 NOT NULL,
    "archivedAt" timestamp(3) without time zone,
    "durationMs" integer,
    "exitReason" text,
    "paneCapture" text,
    "searchVector" tsvector,
    "actualCostUsd" double precision,
    "tokenCount" integer,
    "usageSnapshotPct" double precision
);


ALTER TABLE public."ExecutionLog" OWNER TO postgres;

--
-- TOC entry 234 (class 1259 OID 42367)
-- Name: ImprovementCycle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ImprovementCycle" (
    id text NOT NULL,
    "projectId" text NOT NULL,
    status public."CycleStatus" DEFAULT 'idle'::public."CycleStatus" NOT NULL,
    "automationLevel" integer DEFAULT 1 NOT NULL,
    "scanId" text,
    "tasksCreated" integer DEFAULT 0 NOT NULL,
    "tasksExecuted" integer DEFAULT 0 NOT NULL,
    "tasksReviewed" integer DEFAULT 0 NOT NULL,
    "suggestionsGenerated" integer DEFAULT 0 NOT NULL,
    "suggestionsApproved" integer DEFAULT 0 NOT NULL,
    "cycleError" text,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "nextCycleAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ImprovementCycle" OWNER TO postgres;

--
-- TOC entry 237 (class 1259 OID 44590)
-- Name: MonthlyReport; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MonthlyReport" (
    id text NOT NULL,
    "monthStart" timestamp(3) without time zone NOT NULL,
    "completedCount" integer DEFAULT 0 NOT NULL,
    "failedCount" integer DEFAULT 0 NOT NULL,
    "runningCount" integer DEFAULT 0 NOT NULL,
    "pendingCount" integer DEFAULT 0 NOT NULL,
    "queuedCount" integer DEFAULT 0 NOT NULL,
    "retriedCount" integer DEFAULT 0 NOT NULL,
    "timedOutCount" integer DEFAULT 0 NOT NULL,
    "recoveryCount" integer DEFAULT 0 NOT NULL,
    "avgExecutionMinutes" double precision,
    "activeServerCount" integer DEFAULT 0 NOT NULL,
    "activeAgentCount" integer DEFAULT 0 NOT NULL,
    "agentUtilisation" jsonb DEFAULT '{}'::jsonb NOT NULL,
    "topCompletedTasks" jsonb DEFAULT '[]'::jsonb NOT NULL,
    "generatedBy" text DEFAULT 'manual'::text NOT NULL,
    "reportText" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MonthlyReport" OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 16603)
-- Name: Project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Project" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    priority public."Priority" DEFAULT 'P3'::public."Priority" NOT NULL,
    status public."ProjectStatus" DEFAULT 'active'::public."ProjectStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "completedTasks" integer,
    "completionPct" double precision,
    "estimatedCompletionAt" timestamp(3) without time zone,
    "failedTasks" integer,
    "pendingTasks" integer,
    "progressUpdatedAt" timestamp(3) without time zone,
    "runningTasks" integer,
    "totalTasks" integer,
    "autoReviewEnabled" boolean DEFAULT false NOT NULL,
    "autoScanEnabled" boolean DEFAULT false NOT NULL,
    "lastScannedAt" timestamp(3) without time zone,
    "scanFrequencyDays" integer DEFAULT 7 NOT NULL,
    "cycleFrequencyDays" integer DEFAULT 7 NOT NULL,
    "improvementAutomationLevel" integer DEFAULT 0 NOT NULL,
    "lastImprovementCycleAt" timestamp(3) without time zone,
    "nextImprovementCycleAt" timestamp(3) without time zone
);


ALTER TABLE public."Project" OWNER TO postgres;

--
-- TOC entry 232 (class 1259 OID 40509)
-- Name: ProjectScan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProjectScan" (
    id text NOT NULL,
    "projectId" text NOT NULL,
    "scanType" text DEFAULT 'gap_analysis'::text NOT NULL,
    status public."ScanStatus" DEFAULT 'running'::public."ScanStatus" NOT NULL,
    findings jsonb DEFAULT '[]'::jsonb NOT NULL,
    "findingsCount" integer DEFAULT 0 NOT NULL,
    "scannedTaskCount" integer DEFAULT 0 NOT NULL,
    "runOnServerId" text,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "errorMessage" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ProjectScan" OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 28145)
-- Name: RecoveryLog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."RecoveryLog" (
    id text NOT NULL,
    "serverId" text,
    "agentId" text,
    "triggeredBy" text DEFAULT 'auto'::text NOT NULL,
    success boolean NOT NULL,
    command text,
    "errorMessage" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."RecoveryLog" OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 29167)
-- Name: ScheduledResume; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ScheduledResume" (
    id text NOT NULL,
    "resourceType" text NOT NULL,
    "resourceId" text NOT NULL,
    "resumeAt" timestamp(3) without time zone NOT NULL,
    triggered boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ScheduledResume" OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 16671)
-- Name: Server; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Server" (
    id text NOT NULL,
    name text NOT NULL,
    host text NOT NULL,
    username text NOT NULL,
    port integer DEFAULT 22 NOT NULL,
    "sshKeyPath" text NOT NULL,
    status public."ServerStatus" DEFAULT 'unknown'::public."ServerStatus" NOT NULL,
    "lastCheckedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "claudeSessionPct" double precision,
    "claudeSessionResets" text,
    "claudeUsageFetchedAt" timestamp(3) without time zone,
    "claudeUsageRaw" text,
    "claudeWeekPct" double precision,
    "claudeWeekResets" text,
    "claudeSessionResetsAt" timestamp(3) without time zone,
    "claudeWeekResetsAt" timestamp(3) without time zone,
    "claudePermissionMode" public."ClaudePermissionMode" DEFAULT 'workspace_write'::public."ClaudePermissionMode" NOT NULL,
    "tmuxSession" text DEFAULT 'claude'::text NOT NULL,
    "defaultTaskTimeoutMinutes" integer,
    "consecutiveFailures" integer DEFAULT 0 NOT NULL,
    "healthScore" integer,
    "lastHealthCheckAt" timestamp(3) without time zone,
    "autoRecovery" boolean DEFAULT false NOT NULL,
    "lastRecoveryAt" timestamp(3) without time zone,
    "maxRecoveryAttempts" integer DEFAULT 3 NOT NULL,
    "recoveryAttempts" integer DEFAULT 0 NOT NULL,
    "autoPauseEnabled" boolean DEFAULT true NOT NULL,
    "pausedAt" timestamp(3) without time zone,
    "pausedDueToUsage" boolean DEFAULT false NOT NULL,
    "capacityScore" double precision,
    "activeTaskCount" integer DEFAULT 0 NOT NULL,
    "maxConcurrentTasks" integer DEFAULT 10 NOT NULL,
    "capacityUpdatedAt" timestamp(3) without time zone
);


ALTER TABLE public."Server" OWNER TO postgres;

--
-- TOC entry 221 (class 1259 OID 16681)
-- Name: ServerCommandLog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ServerCommandLog" (
    id text NOT NULL,
    "serverId" text NOT NULL,
    command text NOT NULL,
    status public."CommandStatus" NOT NULL,
    output text,
    "errorMessage" text,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "finishedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ServerCommandLog" OWNER TO postgres;

--
-- TOC entry 225 (class 1259 OID 28656)
-- Name: SystemConfig; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SystemConfig" (
    key text NOT NULL,
    value text NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."SystemConfig" OWNER TO postgres;

--
-- TOC entry 217 (class 1259 OID 16613)
-- Name: Task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Task" (
    id text NOT NULL,
    "projectId" text NOT NULL,
    title text NOT NULL,
    description text,
    priority public."Priority" DEFAULT 'P3'::public."Priority" NOT NULL,
    status public."TaskStatus" DEFAULT 'pending'::public."TaskStatus" NOT NULL,
    "estimatedCostLevel" public."CostLevel" DEFAULT 'medium'::public."CostLevel" NOT NULL,
    "taskType" public."TaskType" DEFAULT 'coding'::public."TaskType" NOT NULL,
    "resultSummary" text,
    "nextAction" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "serverId" text,
    "agentId" text,
    "completionNonce" text,
    "tmuxOutputOffset" integer,
    "taskTmuxSession" text,
    "timeoutMinutes" integer,
    "lastProgressAt" timestamp(3) without time zone,
    "stallDetectedAt" timestamp(3) without time zone,
    "lastFailReason" text,
    "maxRetries" integer DEFAULT 0 NOT NULL,
    "retryAfter" timestamp(3) without time zone,
    "retryCount" integer DEFAULT 0 NOT NULL,
    "blockedByCount" integer DEFAULT 0 NOT NULL,
    "autoReviewEnabled" boolean DEFAULT false NOT NULL,
    "reviewCompletedAt" timestamp(3) without time zone,
    "reviewScheduledAt" timestamp(3) without time zone,
    "reviewStartedAt" timestamp(3) without time zone,
    "reviewStatus" public."ReviewStatus",
    "reviewVerdictNotes" text,
    "scheduledFor" timestamp(3) without time zone
);


ALTER TABLE public."Task" OWNER TO postgres;

--
-- TOC entry 231 (class 1259 OID 38960)
-- Name: TaskDependency; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TaskDependency" (
    id text NOT NULL,
    "taskId" text NOT NULL,
    "dependsOnId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."TaskDependency" OWNER TO postgres;

--
-- TOC entry 235 (class 1259 OID 43437)
-- Name: TaskSuggestion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TaskSuggestion" (
    id text NOT NULL,
    "projectId" text NOT NULL,
    "sourceType" public."SuggestionSourceType" DEFAULT 'manual'::public."SuggestionSourceType" NOT NULL,
    "sourceId" text,
    title text NOT NULL,
    description text NOT NULL,
    priority public."Priority" DEFAULT 'P3'::public."Priority" NOT NULL,
    "taskType" public."TaskType" DEFAULT 'coding'::public."TaskType" NOT NULL,
    "estimatedCostLevel" public."CostLevel" DEFAULT 'medium'::public."CostLevel" NOT NULL,
    rationale text,
    status public."SuggestionStatus" DEFAULT 'pending_review'::public."SuggestionStatus" NOT NULL,
    "convertedTaskId" text,
    "reviewNote" text,
    "reviewedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TaskSuggestion" OWNER TO postgres;

--
-- TOC entry 229 (class 1259 OID 37230)
-- Name: TaskTemplate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TaskTemplate" (
    id text NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    "taskType" public."TaskType" DEFAULT 'coding'::public."TaskType" NOT NULL,
    "estimatedCostLevel" public."CostLevel" DEFAULT 'medium'::public."CostLevel" NOT NULL,
    priority public."Priority" DEFAULT 'P3'::public."Priority" NOT NULL,
    "titleTemplate" text NOT NULL,
    "descriptionTemplate" text NOT NULL,
    variables jsonb DEFAULT '[]'::jsonb NOT NULL,
    "isBuiltIn" boolean DEFAULT false NOT NULL,
    "usageCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TaskTemplate" OWNER TO postgres;

--
-- TOC entry 230 (class 1259 OID 38245)
-- Name: WeeklyAnalytics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WeeklyAnalytics" (
    id text NOT NULL,
    "weekStart" timestamp(3) without time zone NOT NULL,
    "weekEnd" timestamp(3) without time zone NOT NULL,
    "tasksCompleted" integer DEFAULT 0 NOT NULL,
    "tasksFailed" integer DEFAULT 0 NOT NULL,
    "tasksRetried" integer DEFAULT 0 NOT NULL,
    "tasksTimedOut" integer DEFAULT 0 NOT NULL,
    "tasksCreated" integer DEFAULT 0 NOT NULL,
    "reviewsRun" integer DEFAULT 0 NOT NULL,
    "reviewsPassed" integer DEFAULT 0 NOT NULL,
    "reviewsFailed" integer DEFAULT 0 NOT NULL,
    "avgExecutionMinutes" double precision,
    "p50ExecutionMinutes" double precision,
    "p95ExecutionMinutes" double precision,
    "workerRecoveries" integer DEFAULT 0 NOT NULL,
    "dispatchFailures" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."WeeklyAnalytics" OWNER TO postgres;

--
-- TOC entry 236 (class 1259 OID 44569)
-- Name: WeeklyReport; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WeeklyReport" (
    id text NOT NULL,
    "weekStart" timestamp(3) without time zone NOT NULL,
    "completedCount" integer DEFAULT 0 NOT NULL,
    "failedCount" integer DEFAULT 0 NOT NULL,
    "runningCount" integer DEFAULT 0 NOT NULL,
    "pendingCount" integer DEFAULT 0 NOT NULL,
    "queuedCount" integer DEFAULT 0 NOT NULL,
    "retriedCount" integer DEFAULT 0 NOT NULL,
    "timedOutCount" integer DEFAULT 0 NOT NULL,
    "recoveryCount" integer DEFAULT 0 NOT NULL,
    "avgExecutionMinutes" double precision,
    "activeServerCount" integer DEFAULT 0 NOT NULL,
    "activeAgentCount" integer DEFAULT 0 NOT NULL,
    "agentUtilisation" jsonb DEFAULT '{}'::jsonb NOT NULL,
    "topCompletedTasks" jsonb DEFAULT '[]'::jsonb NOT NULL,
    "generatedBy" text DEFAULT 'manual'::text NOT NULL,
    "reportText" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."WeeklyReport" OWNER TO postgres;

--
-- TOC entry 223 (class 1259 OID 27687)
-- Name: WorkerHealth; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WorkerHealth" (
    id text NOT NULL,
    "serverId" text,
    "agentId" text,
    "healthScore" integer NOT NULL,
    "sshOk" boolean NOT NULL,
    "tmuxOk" boolean NOT NULL,
    "claudeOk" boolean NOT NULL,
    "latencyMs" integer,
    "errorMessage" text,
    "checkedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."WorkerHealth" OWNER TO postgres;

--
-- TOC entry 215 (class 1259 OID 16545)
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- TOC entry 3800 (class 0 OID 24939)
-- Dependencies: 222
-- Data for Name: Agent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Agent" (id, "serverId", name, slug, "workDir", "tmuxSession", status, "claudePermissionMode", "claudeSessionPct", "claudeSessionResets", "claudeSessionResetsAt", "claudeWeekPct", "claudeWeekResets", "claudeWeekResetsAt", "claudeUsageRaw", "claudeUsageFetchedAt", "createdAt", "updatedAt", "defaultTaskTimeoutMinutes", "consecutiveFailures", "healthScore", "lastHealthCheckAt", "autoRecovery", "lastRecoveryAt", "maxRecoveryAttempts", "recoveryAttempts", "autoPauseEnabled", "pausedAt", "pausedDueToUsage", "claudeLastRefreshStatus", "claudeUsageCreditsEnabled") FROM stdin;
cmq6w5d940000525uus1ckhga	cmq6ke2xl0000s25u4a8i94ta	agent-1	agent-1	/home/ec2-user/claude-agents/agent-1	claude-agent-1	idle	full_autonomous	11	11 June, 9:50 pm (Sydney)	2026-06-11 11:50:00	11	18 June, 9:00 am (Sydney)	2026-06-17 23:00:00	 ($0.1537)\n\n  Current session\n  █████▌                                             11% used\n  Resets 11:50am (UTC)\n\n  Current week (all models)\n  █████▌                                             11% used\n  Resets Jun 17, 11pm (UTC)\n\n  What's contributing to your limits usage?\n  Approximate, based on local sessions on this machine — does not include\n  other devices or claude.ai\n\n  Scanning local sessions…\n\n  Usage credits\n  Usage credits are off · /usage-credits to turn them on\n\n  Esc to cancel	2026-06-11 07:12:18.038	2026-06-09 17:05:46.072	2026-06-11 07:12:18.041	\N	0	100	2026-06-11 07:06:45.103	f	2026-06-11 06:53:34.966	3	5	t	\N	f	ok	\N
cmq6wcl430001525urn13fvcx	cmq6ke2xl0000s25u4a8i94ta	agent-2	agent-2	/home/ec2-user/claude-agents/agent-2	claude-agent-2	idle	full_autonomous	17	11 June, 9:50 pm (Sydney)	2026-06-11 11:50:00	42	\N	\N	 51s\n   Total code changes:    7853 lines added, 937 lines removed\n   Usage by model:\n       claude-haiku-4-5:  986 input, 6.9k output, 1.4m cache read, 55.0k\n   cache write ($0.2453)\n      claude-sonnet-4-6:  7.1k input, 425.2k output, 91.1m cache read, 1.1m\n   cache write ($37.72)\n\n   Current session\n   ████████▌                                          17% used\n   Resets 11:50am (UTC)\n\n   Current week (all models)\n   █████████████████████                              42% used                ↓	2026-06-11 07:14:26.141	2026-06-09 17:11:22.851	2026-06-11 07:14:26.144	\N	0	100	2026-06-11 07:06:45.12	f	\N	3	0	t	\N	f	ok	\N
\.


--
-- TOC entry 3806 (class 0 OID 35671)
-- Dependencies: 228
-- Data for Name: AgentUsageSnapshot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AgentUsageSnapshot" (id, "agentId", "usagePercent", "resetTime", "resetAt", "usageCreditsEnabled", "captureStatus", "capturedAt", "rawOutput", "cleanedOutput") FROM stdin;
cmq86nqdg0000lt5u7eoj27en	cmq6w5d940000525uus1ckhga	\N	\N	\N	f	ok	2026-06-10 14:47:45.22	8G(API):[26G0s[39m\r\r\n[3G[37mTotal[9Gduration[18G(wall):[26G1h[29G19m[33G51s[39m\r\r\n[3G[37mTotal[9Gcode[14Gchanges:[26G0[28Glines[34Gadded,[41G0[43Glines[49Gremoved[39m\r\r\n[3G[37mUsage:[26G0[28Ginput,[35G0[37Goutput,[45G0[47Gcache[53Gread,[59G0[61Gcache[67Gwrite[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m██████████████████████████████████████████████████[54G[39m[49m100%[59Gused\r\r\n[3G[37mResets[10G3:50pm[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m██████████                                        [54G[39m[49m20%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A[30D[27B\r[2C[5A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r[2C[1B19%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r[2C[1B [37mLonger sessions are more expensive even when cached. /compact mid-task, [39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[37A[30D[37B\r[18C[21A[37m0:59pm (UTC)\r[2C[18B[39m[1mUsage credits\r[2C[1B[22m[37mUsage credits are off · /usage-credits to turn them on\r[2C[1B[39m[K\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[38A	B[<u[>1u[>4;2m❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   StatsSession\n\nTotalcost:$0.0000\nTotalduration(API):0s\nTotalduration(wall):1h19m51s\nTotalcodechanges:0linesadded,0linesremoved\nUsage:0input,0output,0cacheread,0cachewrite\n\nCurrentsession\n██████████████████████████████████████████████████100%used\nResets3:50pm(UTC)\n\nCurrentweek(allmodels)\n██████████                                        20%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nLast 24h· these are independent characteristics of your usage, not a breakdown19%ofyourusagewasat>150kcontext Longer sessions are more expensive even when cached. /compact mid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nRefreshing…\n\nEsctocancel\n0:59pm (UTC)Usage creditsUsage credits are off · /usage-credits to turn them on\nEsctocancel
cmq86ov2c0003lt5u3r3nj2yn	cmq6w5d940000525uus1ckhga	\N	\N	\N	f	ok	2026-06-10 14:48:37.956	:[26G$0.0000[39m\r\r\n[3G[37mTotal[9Gduration[18G(API):[26G0s[39m\r\r\n[3G[37mTotal[9Gduration[18G(wall):[26G4s[39m\r\r\n[3G[37mTotal[9Gcode[14Gchanges:[26G0[28Glines[34Gadded,[41G0[43Glines[49Gremoved[39m\r\r\n[3G[37mUsage:[26G0[28Ginput,[35G0[37Goutput,[45G0[47Gcache[53Gread,[59G0[61Gcache[67Gwrite[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m██████████████████████████████████████████████████[54G[39m[49m100%[59Gused\r\r\n[3G[37mResets[10G3:50pm[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m██████████                                        [54G[39m[49m20%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A[30D[27B\r[2C[5A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r[2C[1B19%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r[2C[1B [37mLonger sessions are more expensive even when cached. /compact mid-task, [39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[37A[30D[37B\r[2C[3A[1mUsage credits\r[2C[1B[22m[37mUsage credits are off · /usage-credits to turn them on\r[2C[1B[39m[K\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[38A	❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   StatsSession\n\nTotalcost:$0.0000\nTotalduration(API):0s\nTotalduration(wall):4s\nTotalcodechanges:0linesadded,0linesremoved\nUsage:0input,0output,0cacheread,0cachewrite\n\nCurrentsession\n██████████████████████████████████████████████████100%used\nResets3:50pm(UTC)\n\nCurrentweek(allmodels)\n██████████                                        20%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nLast 24h· these are independent characteristics of your usage, not a breakdown19%ofyourusagewasat>150kcontext Longer sessions are more expensive even when cached. /compact mid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nRefreshing…\n\nEsctocancel\nUsage creditsUsage credits are off · /usage-credits to turn them on\nEsctocancel
cmq86ply40007lt5uxqmq94hy	cmq6wcl430001525urn13fvcx	\N	\N	\N	\N	error	2026-06-10 14:49:12.796	\n	\N
cmq86qyec0008lt5u2jdhh0to	cmq6w5d940000525uus1ckhga	\N	\N	\N	f	ok	2026-06-10 14:50:15.588	ation[18G(API):[26G0s[39m\r\r\n[3G[37mTotal[9Gduration[18G(wall):[26G1m[29G42s[39m\r\r\n[3G[37mTotal[9Gcode[14Gchanges:[26G0[28Glines[34Gadded,[41G0[43Glines[49Gremoved[39m\r\r\n[3G[37mUsage:[26G0[28Ginput,[35G0[37Goutput,[45G0[47Gcache[53Gread,[59G0[61Gcache[67Gwrite[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m██████████████████████████████████████████████████[54G[39m[49m100%[59Gused\r\r\n[3G[37mResets[10G3:50pm[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m██████████                                        [54G[39m[49m20%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A[30D[27B\r[2C[5A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r[2C[1B19%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r[2C[1B [37mLonger sessions are more expensive even when cached. /compact mid-task, [39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[37A[30D[37B\r[18C[21A[37m0:59pm (UTC)\r[2C[18B[39m[1mUsage credits\r[2C[1B[22m[37mUsage credits are off · /usage-credits to turn them on\r[2C[1B[39m[K\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[38A	B[<u[>1u[>4;2m❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   StatsSession\n\nTotalcost:$0.0000\nTotalduration(API):0s\nTotalduration(wall):1m42s\nTotalcodechanges:0linesadded,0linesremoved\nUsage:0input,0output,0cacheread,0cachewrite\n\nCurrentsession\n██████████████████████████████████████████████████100%used\nResets3:50pm(UTC)\n\nCurrentweek(allmodels)\n██████████                                        20%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nLast 24h· these are independent characteristics of your usage, not a breakdown19%ofyourusagewasat>150kcontext Longer sessions are more expensive even when cached. /compact mid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nRefreshing…\n\nEsctocancel\n0:59pm (UTC)Usage creditsUsage credits are off · /usage-credits to turn them on\nEsctocancel
cmq87clys0000pw5u0jlfl8dj	cmq6w5d940000525uus1ckhga	\N	\N	\N	\N	error	2026-06-10 15:07:05.909	[30D[27B\r[2C[5A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r[2C[1B19%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r[2C[1B [37mLonger sessions are more expensive even when cached. /compact mid-task, [39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[37A[30D[37B\r[2C[3A[1mUsage credits\r[2C[1B[22m[37mUsage credits are off · /usage-credits to turn them on\r[2C[1B[39m[K\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[38A	Last 24h· these are independent characteristics of your usage, not a breakdown19%ofyourusagewasat>150kcontext Longer sessions are more expensive even when cached. /compact mid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nRefreshing…\n\nEsctocancel\nUsage creditsUsage credits are off · /usage-credits to turn them on\nEsctocancel
cmq87dop00001pw5unkisvgt7	cmq6wcl430001525urn13fvcx	17	15 June, 7:00 pm (Sydney)	2026-06-15 09:00:00	\N	ok	2026-06-10 15:07:56.1	sage?[22m[K\r[2C[1B [37mApproximate, based on local sessions on this[49Gmachine[57G— doe[63G not include [79G↓[39m[23;1H[4;32H[H\r[2B[91m▝▜[40m█████[49m▛▘[39m  [37mSonnet 4.6 · Claude Pro[39m[K\r[1B[91m  ▘▘ ▝▝  [39m  [37m/home/ec2-user[39m[K\r[2B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[14G[22m[39mStatus[23GConfig[31G[104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[1B[K\r[3C[1B[1mSession[22m[K\r[3C[1B[K\r[11C[1B[37mst:        [27G$0.0000[39m[K\r[3C[1B[37mTotal duration[19G(API):[28Gs[39m[K\r[3C[1B[37mTotal duration (wall): 1h 30m 41s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUsage:                 0 input, 0 output, 0 cache read, 0 cache write\r[3C[1B[39m[K\r[3C[1B[1mWhat's contributing to your limits usage?\r[3C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[3C[1Bother devices or claude.ai[39m[K\r[3C[1B[K\r[3C[1B[37mScanning local sessions…\r[3C[1B[39m[K\r[3C[1B[37mEsc to c[13Gncel[39m                                                           [23;1H[7;32H[H\r[78C[22B[K[23;1H[7;32H[H\r[5B   [37mFable 5 is now available with the latest version of Claude Code! Run "claude \r[3C[1Bupdate" to update to v2.1.170+[39m[K\r[1C[2B[91m▎[4G[1mOpus 4.8 is now available![22m[37m · /model to switch\r[3C[2B[39m[K\r[1B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[22m[39m  Status   Config  [104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[1B[K\r[3C[1B[1mSession[22m[K\r[3C[2B[37mTotal cost:            $0.0000[39m[K\r[3C[1B[37mTotal duration (API):[26G 0s[39m[K\r[3C[1B[37mTotal[11Guration (wa[23Gl): 1h 30m 41s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUs[7Gge:  [13G     [19G        0 input, 0 output, 0 cache read, 0 cache write[39m[23;1H[13;32H	B▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔   Settings  Status   Config Usage StatsSessionTotal cost:            $0.0000 Total duration (API):  0sTotal duration (wall): 1h 30m 41sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache writeCurrent session██████████████████████████████████████████████████100%usedResets 2pm (UTC)Current week (all models)████████▌                                          17% used   Resets Jun 15, 9am (UTC)   What's contributing to your limits usage? Approximate, based on local sessions on thismachine— doe not include ↓▝▜█████▛▘  Sonnet 4.6 · Claude Pro  ▘▘ ▝▝    /home/ec2-user▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔SettingsStatusConfig Usage StatsSessionst:        $0.0000Total duration(API):sTotal duration (wall): 1h 30m 41sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache writeWhat's contributing to your limits usage?Approximate, based on local sessions on this machine — does not include other devices or claude.aiScanning local sessions…Esc to cncel                                                              Fable 5 is now available with the latest version of Claude Code! Run "claude update" to update to v2.1.170+▎Opus 4.8 is now available! · /model to switch▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔Settings  Status   Config   Usage StatsSessionTotal cost:            $0.0000Total duration (API): 0sTotaluration (wal): 1h 30m 41sTotal code changes:    0 lines added, 0 lines removedUsge:               0 input, 0 output, 0 cache read, 0 cache write
cmq87ebec0005pw5ubx7pi77r	cmq6wcl430001525urn13fvcx	17	15 June, 7:00 pm (Sydney)	2026-06-15 09:00:00	f	ok	2026-06-10 15:08:25.524	(B[<u[>1u[>4;2m[?1000h[?1002h[?1003h[?1006h[?25l[H\r[2B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[1B[39m   [94m[1mSettings[22m[39m  Status   Config[31G[104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[2B[1mSession[22m[K\r[3C[1B[K\r[3C[1B[37mTotal cost:            $0.0000\r[1C[1B[39m [4G[37mTotal duration (API):  0s[39m[K\r[3C[1B[37mTotal duration (wall): 1h 31m 11s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUsage:                 0 input, 0 output, 0 cache read, 0 cache write\r[3C[2B[39m[1mCurrent session\r[3C[1B[22m[47m[33m██████████████████████████████████████████████████[55G[39m[49m100%[60Gused\r[3C[1B[37mResets 2pm (UTC)\r[3C[2B[39m[1mCurrent week (all models)\r[3C[1B[22m[47m[33m████████▌                                         [39m[49m 17% used[K\r[1B   [37mResets Jun 15, 9am (UTC)[39m[K\r[1B[K\r[1B   [1mWhat's contributing to your limits usage?[22m[K\r[2C[1B [37mApproximate, based on local sessions on this[49Gmachine[57G— doe[63G not include [79G↓[39m[23;1H[4;32H[H\r[3C[21B[37mRefreshing…[39m[K\r[3C[1B                                                                        [23;1H[4;32H[H\r[78C[22B[K[23;1H[4;32H[H\r[29C[14B[47m[33m                        [55G[39m[49m52% used[K\r[10C[1B[37m7:10pm (UTC)\r[11C[3B[47m[33m███▌[55G[39m[49m23\r[3C[3B[1mUsage credits\r[3C[1B[22m[37mUsage credits are off · /usage-credits to turn them on[39m[23;1H[4;32H	B▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔   Settings  Status   Config Usage StatsSessionTotal cost:            $0.0000 Total duration (API):  0sTotal duration (wall): 1h 31m 11sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache writeCurrent session██████████████████████████████████████████████████100%usedResets 2pm (UTC)Current week (all models)████████▌                                          17% used   Resets Jun 15, 9am (UTC)   What's contributing to your limits usage? Approximate, based on local sessions on thismachine— doe not include ↓Refreshing…                                                                                                52% used7:10pm (UTC)███▌23Usage creditsUsage credits are off · /usage-credits to turn them on
cmq87em2l0006pw5uecsf5t0c	cmq6wcl430001525urn13fvcx	17	15 June, 7:00 pm (Sydney)	2026-06-15 09:00:00	\N	ok	2026-06-10 15:08:39.357	sage?[22m[K\r[2C[1B [37mApproximate, based on local sessions on this[49Gmachine[57G— doe[63G not include [79G↓[39m[23;1H[4;32H[H\r[2B[91m▝▜[40m█████[49m▛▘[39m  [37mSonnet 4.6 · Claude Pro[39m[K\r[1B[91m  ▘▘ ▝▝  [39m  [37m/home/ec2-user[39m[K\r[2B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[14G[22m[39mStatus[23GConfig[31G[104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[1B[K\r[3C[1B[1mSession[22m[K\r[3C[1B[K\r[11C[1B[37mst:        [27G$0.0000[39m[K\r[3C[1B[37mTotal duration[19G(API):[28Gs[39m[K\r[3C[1B[37mTotal duration (wall): 1h 31m 24s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUsage:                 0 input, 0 output, 0 cache read, 0 cache write\r[3C[1B[39m[K\r[3C[1B[1mWhat's contributing to your limits usage?\r[3C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[3C[1Bother devices or claude.ai[39m[K\r[3C[1B[K\r[3C[1B[37mScanning local sessions…\r[3C[1B[39m[K\r[3C[1B[37mEsc to c[13Gncel[39m                                                           [23;1H[7;32H[H\r[78C[22B[K[23;1H[7;32H[H\r[5B   [37mFable 5 is now available with the latest version of Claude Code! Run "claude \r[3C[1Bupdate" to update to v2.1.170+[39m[K\r[1C[2B[91m▎[4G[1mOpus 4.8 is now available![22m[37m · /model to switch\r[3C[2B[39m[K\r[1B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[22m[39m  Status   Config  [104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[1B[K\r[3C[1B[1mSession[22m[K\r[3C[2B[37mTotal cost:            $0.0000[39m[K\r[3C[1B[37mTotal duration (API):[26G 0s[39m[K\r[3C[1B[37mTotal[11Guration (wa[23Gl): 1h 31m 24s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUs[7Gge:  [13G     [19G        0 input, 0 output, 0 cache read, 0 cache write[39m[23;1H[13;32H	▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔   Settings  Status   Config Usage StatsSessionTotal cost:            $0.0000 Total duration (API):  0sTotal duration (wall): 1h 31m 24sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache writeCurrent session██████████████████████████████████████████████████100%usedResets 2pm (UTC)Current week (all models)████████▌                                         17%used   Resets Jun 15, 9am (UTC)   What's contributing to your limits usage? Approximate, based on local sessions on thismachine— doe not include ↓▝▜█████▛▘  Sonnet 4.6 · Claude Pro  ▘▘ ▝▝    /home/ec2-user▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔SettingsStatusConfig Usage StatsSessionst:        $0.0000Total duration(API):sTotal duration (wall): 1h 31m 24sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache writeWhat's contributing to your limits usage?Approximate, based on local sessions on this machine — does not include other devices or claude.aiScanning local sessions…Esc to cncel                                                              Fable 5 is now available with the latest version of Claude Code! Run "claude update" to update to v2.1.170+▎Opus 4.8 is now available! · /model to switch▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔Settings  Status   Config   Usage StatsSessionTotal cost:            $0.0000Total duration (API): 0sTotaluration (wal): 1h 31m 24sTotal code changes:    0 lines added, 0 lines removedUsge:               0 input, 0 output, 0 cache read, 0 cache write
cmq87fyjm0007pw5ulb6epj48	cmq6wcl430001525urn13fvcx	\N	\N	\N	\N	error	2026-06-10 15:09:42.178	▔▔\r[3C[1B[1mSettings[14G[22m[39mStatus[23GConfig[31G[104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[2B[1mSession\r[3C[2B[22m[37mTotal cost:            $0.0000\r[3C[1BTotal duration (API):  0s\r[3C[1BTotal duration (wall): 6s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUsage:                 0 input, 0 output, 0 cache read, 0 cache write[39m[K\r[1B[K\r[1B   [37mLoading usage data…[39m[K\r[1B[K\r[2C[1B [37mEsc to cancel[39m[K[23;1H[11;32H[H\r[5B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[22m[39m  Status   Config  [104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[2B[1mSession\r[1B[22m[K\r[3C[1B[37mTotal cost:            $0.0000[39m[K\r[3C[1B[37mTotal duration (API):  0s\r[3C[1BTotal duration (wall): 6s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUsage:     [27G0 input, 0 output, 0 cache read, 0 cache write\r[3C[1B[39m[K\r[3C[1B[1mWhat's contributing to your limits usage?\r[3C[1B[22m[37mApproximate, bas[21Gd on[26Glocal sessions on[44Gthis machin[56G — does not include \r[3C[1Bother devices[18Gor[21Gclaude.a[30G[39m[K\r[3C[2B[37mSc[7Gnning local sessions…[39m[23;1H[7;32H[H\r[5B   [37mFable 5 is now available with the latest version of Claude Code! Run "claude \r[3C[1Bupdate" to update to v2.1.170+[39m[K\r[3C[2B[K\r[3C[2B[K\r[1B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[22m[39m  Status   Config[31G[104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[1B[K\r[3C[1B[1mSession[22m[K\r[3C[2B[37mTotal cost:            $0.0000[39m[K\r[3C[1B[37mTotal duration (API):[26G 0s[39m[K\r[3C[1B[37mTotal[11Guration (wa[23Gl): 6s[39m[K\r[3C[1B[37mTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUs[7Gge:  [13G     [19G        0 input, 0 output, 0 cache read, 0 cache write[39m[23;1H[13;32H	▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔SettingsStatusConfig Usage StatsSessionTotal cost:            $0.0000Total duration (API):  0sTotal duration (wall): 6sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache write   Loading usage data… Esc to cancel▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔Settings  Status   Config   Usage StatsSessionTotal cost:            $0.0000Total duration (API):  0sTotal duration (wall): 6sTotal code changes:    0 lines added, 0 lines removedUsage:     0 input, 0 output, 0 cache read, 0 cache writeWhat's contributing to your limits usage?Approximate, basd onlocal sessions onthis machin — does not include other devicesorclaude.aScnning local sessions…   Fable 5 is now available with the latest version of Claude Code! Run "claude update" to update to v2.1.170+▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔Settings  Status   Config Usage StatsSessionTotal cost:            $0.0000Total duration (API): 0sTotaluration (wal): 6sTotal code changes:    0 lines added, 0 lines removedUsge:               0 input, 0 output, 0 cache read, 0 cache write
cmq87g5tx0008pw5u9wkxmmx6	cmq6wcl430001525urn13fvcx	22	15 June, 7:00 pm (Sydney)	2026-06-15 09:00:00	\N	ok	2026-06-10 15:09:51.621	Jun 15, 9am (UTC)[39m[K\r[1B[K\r[1B   [1mWhat's contributing to your limits usage?[22m[K\r[2C[1B [37mApproximate, based on local sessions on this[49Gmachine[57G— doe[63G not include [79G↓[39m[23;1H[4;32H[H\r[2B[91m▝▜[40m█████[49m▛▘[39m  [37mSonnet 4.6 · Claude Pro[39m[K\r[1B[91m  ▘▘ ▝▝  [39m  [37m/home/ec2-user[39m[K\r[2B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[14G[22m[39mStatus[23GConfig[31G[104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[1B[K\r[3C[1B[1mSession[22m[K\r[3C[1B[K\r[11C[1B[37mst:        [27G$0.0000[39m[K\r[3C[1B[37mTotal duration[19G(API):[28Gs[39m[K\r[3C[1B[37mTotal duration (wall): 15s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUsage:                 0 input, 0 output, 0 cache read, 0 cache write\r[3C[1B[39m[K\r[3C[1B[1mWhat's contributing to your limits usage?\r[3C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[3C[1Bother devices or claude.ai[39m[K\r[3C[1B[K\r[3C[1B[37mScanning local sessions…\r[3C[1B[39m[K\r[3C[1B[37mEsc to c[13Gncel[39m                                                           [23;1H[7;32H[H\r[78C[22B[K[23;1H[7;32H[H\r[5B   [37mFable 5 is now available with the latest version of Claude Code! Run "claude \r[3C[1Bupdate" to update to v2.1.170+[39m[K\r[3C[2B[K\r[3C[2B[K\r[1B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[22m[39m  Status   Config [31G[104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[1B[K\r[3C[1B[1mSession[22m[K\r[3C[2B[37mTotal cost:            $0.0000[39m[K\r[3C[1B[37mTotal duration (API):[26G 0s[39m[K\r[3C[1B[37mTotal[11Guration (wa[23Gl): 15s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUs[7Gge:  [13G     [19G        0 input, 0 output, 0 cache read, 0 cache write[39m[23;1H[13;32H	▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔   Settings  Status   Config Usage StatsSessionTotal cost:            $0.0000Total duration (API):  0sTotal duration (wall): 15sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache writeCurrent session██████████████████████████                        52%usedResets 7:10pm (UTC)Current week (all models) ███████████                                        22% used   Resets Jun 15, 9am (UTC)   What's contributing to your limits usage? Approximate, based on local sessions on thismachine— doe not include ↓▝▜█████▛▘  Sonnet 4.6 · Claude Pro  ▘▘ ▝▝    /home/ec2-user▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔SettingsStatusConfig Usage StatsSessionst:        $0.0000Total duration(API):sTotal duration (wall): 15sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache writeWhat's contributing to your limits usage?Approximate, based on local sessions on this machine — does not include other devices or claude.aiScanning local sessions…Esc to cncel                                                              Fable 5 is now available with the latest version of Claude Code! Run "claude update" to update to v2.1.170+▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔Settings  Status   Config  Usage StatsSessionTotal cost:            $0.0000Total duration (API): 0sTotaluration (wal): 15sTotal code changes:    0 lines added, 0 lines removedUsge:               0 input, 0 output, 0 cache read, 0 cache write
cmq87gnqj0009pw5u3c91zpu1	cmq6w5d940000525uus1ckhga	20	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	f	ok	2026-06-10 15:10:14.827	0000[39m\r\r\n[3G[37mTotal[9Gduration[18G(API):[26G0s[39m\r\r\n[3G[37mTotal[9Gduration[18G(wall):[26G21m[30G41s[39m\r\r\n[3G[37mTotal[9Gcode[14Gchanges:[26G0[28Glines[34Gadded,[41G0[43Glines[49Gremoved[39m\r\r\n[3G[37mUsage:[26G0[28Ginput,[35G0[37Goutput,[45G0[47Gcache[53Gread,[59G0[61Gcache[67Gwrite[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m██████████████████████████████████████████████████[54G[39m[49m100%[59Gused\r\r\n[3G[37mResets[10G3:50pm[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m██████████                                        [54G[39m[49m20%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A[30D[27B\r[2C[5A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r[2C[1B19%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r[2C[1B [37mLonger sessions are more expensive even when cached. /compact mid-task, [39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[37A[30D[37B\r[2C[3A[1mUsage credits\r[2C[1B[22m[37mUsage credits are off · /usage-credits to turn them on\r[2C[1B[39m[K\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[38A	❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   StatsSession\n\nTotalcost:$0.0000\nTotalduration(API):0s\nTotalduration(wall):21m41s\nTotalcodechanges:0linesadded,0linesremoved\nUsage:0input,0output,0cacheread,0cachewrite\n\nCurrentsession\n██████████████████████████████████████████████████100%used\nResets3:50pm(UTC)\n\nCurrentweek(allmodels)\n██████████                                        20%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nLast 24h· these are independent characteristics of your usage, not a breakdown19%ofyourusagewasat>150kcontext Longer sessions are more expensive even when cached. /compact mid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nRefreshing…\n\nEsctocancel\nUsage creditsUsage credits are off · /usage-credits to turn them on\nEsctocancel
cmq88sf4k000zpw5unw7lgaxt	cmq6wcl430001525urn13fvcx	22	15 June, 7:00 pm (Sydney)	2026-06-15 09:00:00	\N	ok	2026-06-10 15:47:23.156	15, 9am (UTC)[39m[K\r[1B[K\r[1B   [1mWhat's contributing to your limits usage?[22m[K\r[2C[1B [37mApproximate, based on local sessions on this[49Gmachine[57G— doe[63G not include [79G↓[39m[23;1H[4;32H[H\r[2B[91m▝▜[40m█████[49m▛▘[39m  [37mSonnet 4.6 · Claude Pro[39m[K\r[1B[91m  ▘▘ ▝▝  [39m  [37m/home/ec2-user[39m[K\r[2B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[14G[22m[39mStatus[23GConfig[31G[104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[1B[K\r[3C[1B[1mSession[22m[K\r[3C[1B[K\r[11C[1B[37mst:        [27G$0.0000[39m[K\r[3C[1B[37mTotal duration[19G(API):[28Gs[39m[K\r[3C[1B[37mTotal duration (wall): 37m 47s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUsage:                 0 input, 0 output, 0 cache read, 0 cache write\r[3C[1B[39m[K\r[3C[1B[1mWhat's contributing to your limits usage?\r[3C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[3C[1Bother devices or claude.ai[39m[K\r[3C[1B[K\r[3C[1B[37mScanning local sessions…\r[3C[1B[39m[K\r[3C[1B[37mEsc to c[13Gncel[39m                                                           [23;1H[7;32H[H\r[78C[22B[K[23;1H[7;32H[H\r[5B   [37mFable 5 is now available with the latest version of Claude Code! Run "claude \r[3C[1Bupdate" to update to v2.1.170+[39m[K\r[3C[2B[K\r[3C[2B[K\r[1B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[22m[39m  Status   Config  [104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[1B[K\r[3C[1B[1mSession[22m[K\r[3C[2B[37mTotal cost:            $0.0000[39m[K\r[3C[1B[37mTotal duration (API):[26G 0s[39m[K\r[3C[1B[37mTotal[11Guration (wa[23Gl): 37m 47s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUs[7Gge:  [13G     [19G        0 input, 0 output, 0 cache read, 0 cache write[39m[23;1H[13;32H	B▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔   Settings  Status   Config Usage StatsSessionTotal cost:            $0.0000Total duration (API):  0sTotal duration (wall): 37m 47sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache writeCurrent session██████████████████████████                        52%usedResets 7:10pm (UTC)Current week (all models)███████████                                        22% used   Resets Jun 15, 9am (UTC)   What's contributing to your limits usage? Approximate, based on local sessions on thismachine— doe not include ↓▝▜█████▛▘  Sonnet 4.6 · Claude Pro  ▘▘ ▝▝    /home/ec2-user▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔SettingsStatusConfig Usage StatsSessionst:        $0.0000Total duration(API):sTotal duration (wall): 37m 47sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache writeWhat's contributing to your limits usage?Approximate, based on local sessions on this machine — does not include other devices or claude.aiScanning local sessions…Esc to cncel                                                              Fable 5 is now available with the latest version of Claude Code! Run "claude update" to update to v2.1.170+▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔Settings  Status   Config   Usage StatsSessionTotal cost:            $0.0000Total duration (API): 0sTotaluration (wal): 37m 47sTotal code changes:    0 lines added, 0 lines removedUsge:               0 input, 0 output, 0 cache read, 0 cache write
cmq88snu60010pw5uyfcfa7tz	cmq6wcl430001525urn13fvcx	22	15 June, 7:00 pm (Sydney)	2026-06-15 09:00:00	\N	ok	2026-06-10 15:47:34.447	15, 9am (UTC)[39m[K\r[1B[K\r[1B   [1mWhat's contributing to your limits usage?[22m[K\r[2C[1B [37mApproximate, based on local sessions on this[49Gmachine[57G— doe[63G not include [79G↓[39m[23;1H[4;32H[H\r[2B[91m▝▜[40m█████[49m▛▘[39m  [37mSonnet 4.6 · Claude Pro[39m[K\r[1B[91m  ▘▘ ▝▝  [39m  [37m/home/ec2-user[39m[K\r[2B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[14G[22m[39mStatus[23GConfig[31G[104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[1B[K\r[3C[1B[1mSession[22m[K\r[3C[1B[K\r[11C[1B[37mst:        [27G$0.0000[39m[K\r[3C[1B[37mTotal duration[19G(API):[28Gs[39m[K\r[3C[1B[37mTotal duration (wall): 37m 58s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUsage:                 0 input, 0 output, 0 cache read, 0 cache write\r[3C[1B[39m[K\r[3C[1B[1mWhat's contributing to your limits usage?\r[3C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[3C[1Bother devices or claude.ai[39m[K\r[3C[1B[K\r[3C[1B[37mScanning local sessions…\r[3C[1B[39m[K\r[3C[1B[37mEsc to c[13Gncel[39m                                                           [23;1H[7;32H[H\r[78C[22B[K[23;1H[7;32H[H\r[5B   [37mFable 5 is now available with the latest version of Claude Code! Run "claude \r[3C[1Bupdate" to update to v2.1.170+[39m[K\r[3C[2B[K\r[3C[2B[K\r[1B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[22m[39m  Status   Config  [104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[1B[K\r[3C[1B[1mSession[22m[K\r[3C[2B[37mTotal cost:            $0.0000[39m[K\r[3C[1B[37mTotal duration (API):[26G 0s[39m[K\r[3C[1B[37mTotal[11Guration (wa[23Gl): 37m 58s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUs[7Gge:  [13G     [19G        0 input, 0 output, 0 cache read, 0 cache write[39m[23;1H[13;32H	B▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔   Settings  Status   Config Usage StatsSessionTotal cost:            $0.0000Total duration (API):  0sTotal duration (wall): 37m 58sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache writeCurrent session██████████████████████████                        52%usedResets 7:10pm (UTC)Current week (all models)███████████                                       22%used   Resets Jun 15, 9am (UTC)   What's contributing to your limits usage? Approximate, based on local sessions on thismachine— doe not include ↓▝▜█████▛▘  Sonnet 4.6 · Claude Pro  ▘▘ ▝▝    /home/ec2-user▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔SettingsStatusConfig Usage StatsSessionst:        $0.0000Total duration(API):sTotal duration (wall): 37m 58sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache writeWhat's contributing to your limits usage?Approximate, based on local sessions on this machine — does not include other devices or claude.aiScanning local sessions…Esc to cncel                                                              Fable 5 is now available with the latest version of Claude Code! Run "claude update" to update to v2.1.170+▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔Settings  Status   Config   Usage StatsSessionTotal cost:            $0.0000Total duration (API): 0sTotaluration (wal): 37m 58sTotal code changes:    0 lines added, 0 lines removedUsge:               0 input, 0 output, 0 cache read, 0 cache write
cmq88tf4o0014pw5umb4vjr6m	cmq6wcl430001525urn13fvcx	\N	\N	\N	\N	error	2026-06-10 15:48:09.816	[H\r[11B[K\r[3C[1B[K\r[3C[2B[K\r[3C[2B[K\r[3C[1B[K\r[3C[1B                              [64G[37m● high · /effort\r[1B────────────────────────────────────────────────────────────────────────────────\r[1B[39m❯ [4G[K\r[1B[37m────────────────────────────────────────────────────────────────────────────────\r[2C[1B[91m⏵⏵ bypass permissions on[37m (shift+tab to cycle) · ← for agents[39m[23;1H[21;3H[?25h	● high · /effort────────────────────────────────────────────────────────────────────────────────❯ ────────────────────────────────────────────────────────────────────────────────⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents
cmq88toux0015pw5uynufrj0q	cmq6wcl430001525urn13fvcx	22	15 June, 7:00 pm (Sydney)	2026-06-15 09:00:00	f	ok	2026-06-10 15:48:22.425	[?25l[H\r[2B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[1B[39m   [94m[1mSettings[22m[39m  Status   Config[31G[104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[2B[1mSession[22m[K\r[3C[1B[K\r[3C[1B[37mTotal cost:            $0.0000\r[3C[1BTotal duration (API):  0s\r[3C[1BTotal duration (wall): 38m 46s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUsage:                 0 input, 0 output, 0 cache read, 0 cache write\r[3C[2B[39m[1mCurrent session\r[3C[1B[22m[47m[33m██████████████████████████                        [55G[39m[49m52%[59Gused\r[3C[1B[37mResets 7:10pm (UTC)\r[3C[2B[39m[1mCurrent week (all models)\r[3C[1B[22m[47m[33m███████████                                       [55G[39m[49m22%[59Gused[64G[K\r[1B   [37mResets Jun 15, 9am (UTC)[39m[K\r[1B[K\r[1B   [1mWhat's contributing to your limits usage?[22m[K\r[2C[1B [37mApproximate, based on local sessions on this[49Gmachine[57G— doe[63G not include [79G↓[39m[23;1H[4;32H[H\r[3C[21B[37mRefreshing…[39m[K\r[3C[1B                                                                        [23;1H[4;32H[H\r[78C[22B[K[23;1H[4;32H[H\r[29C[14B[47m[33m██████████████████[55G[39m[49m88\r[14C[4B[47m[33m██[56G[39m[49m6\r[3C[3B[1mUsage credits\r[3C[1B[22m[37mUsage credits are off · /usage-credits to turn them on[39m[23;1H[4;32H	▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔   Settings  Status   Config Usage StatsSessionTotal cost:            $0.0000Total duration (API):  0sTotal duration (wall): 38m 46sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache writeCurrent session██████████████████████████                        52%usedResets 7:10pm (UTC)Current week (all models)███████████                                       22%used   Resets Jun 15, 9am (UTC)   What's contributing to your limits usage? Approximate, based on local sessions on thismachine— doe not include ↓Refreshing…                                                                        ██████████████████88██6Usage creditsUsage credits are off · /usage-credits to turn them on
cmq88txfw0016pw5u2azxgwpd	cmq6wcl430001525urn13fvcx	22	15 June, 7:00 pm (Sydney)	2026-06-15 09:00:00	\N	ok	2026-06-10 15:48:33.548	15, 9am (UTC)[39m[K\r[1B[K\r[1B   [1mWhat's contributing to your limits usage?[22m[K\r[2C[1B [37mApproximate, based on local sessions on this[49Gmachine[57G— doe[63G not include [79G↓[39m[23;1H[4;32H[H\r[2B[91m▝▜[40m█████[49m▛▘[39m  [37mSonnet 4.6 · Claude Pro[39m[K\r[1B[91m  ▘▘ ▝▝  [39m  [37m/home/ec2-user[39m[K\r[2B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[14G[22m[39mStatus[23GConfig[31G[104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[1B[K\r[3C[1B[1mSession[22m[K\r[3C[1B[K\r[11C[1B[37mst:        [27G$0.0000[39m[K\r[3C[1B[37mTotal duration[19G(API):[28Gs[39m[K\r[3C[1B[37mTotal duration (wall): 38m 57s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUsage:                 0 input, 0 output, 0 cache read, 0 cache write\r[3C[1B[39m[K\r[3C[1B[1mWhat's contributing to your limits usage?\r[3C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[3C[1Bother devices or claude.ai[39m[K\r[3C[1B[K\r[3C[1B[37mScanning local sessions…\r[3C[1B[39m[K\r[3C[1B[37mEsc to c[13Gncel[39m                                                           [23;1H[7;32H[H\r[78C[22B[K[23;1H[7;32H[H\r[5B   [37mFable 5 is now available with the latest version of Claude Code! Run "claude \r[3C[1Bupdate" to update to v2.1.170+[39m[K\r[3C[2B[K\r[3C[2B[K\r[1B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[22m[39m  Status   Config  [104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[1B[K\r[3C[1B[1mSession[22m[K\r[3C[2B[37mTotal cost:            $0.0000[39m[K\r[3C[1B[37mTotal duration (API):[26G 0s[39m[K\r[3C[1B[37mTotal[11Guration (wa[23Gl): 38m 57s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUs[7Gge:  [13G     [19G        0 input, 0 output, 0 cache read, 0 cache write[39m[23;1H[13;32H	▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔   Settings  Status   Config Usage StatsSessionTotal cost:            $0.0000Total duration (API):  0sTotal duration (wall): 38m 57sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache writeCurrent session██████████████████████████                        52%usedResets 7:10pm (UTC)Current week (all models)███████████                                       22%used   Resets Jun 15, 9am (UTC)   What's contributing to your limits usage? Approximate, based on local sessions on thismachine— doe not include ↓▝▜█████▛▘  Sonnet 4.6 · Claude Pro  ▘▘ ▝▝    /home/ec2-user▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔SettingsStatusConfig Usage StatsSessionst:        $0.0000Total duration(API):sTotal duration (wall): 38m 57sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache writeWhat's contributing to your limits usage?Approximate, based on local sessions on this machine — does not include other devices or claude.aiScanning local sessions…Esc to cncel                                                              Fable 5 is now available with the latest version of Claude Code! Run "claude update" to update to v2.1.170+▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔Settings  Status   Config   Usage StatsSessionTotal cost:            $0.0000Total duration (API): 0sTotaluration (wal): 38m 57sTotal code changes:    0 lines added, 0 lines removedUsge:               0 input, 0 output, 0 cache read, 0 cache write
cmq90rz4n005y0xms4c20n2bg	cmq6wcl430001525urn13fvcx	37	\N	\N	\N	ok	2026-06-11 04:50:51.671	(B[<u[>1u[>4;2m[?1000h[?1002h[?1003h[?1006h]0;✳ Implement AI task review queue system[?25l[H[7G[92m87[11G[37m [15G<Suspense[25Gfallback={<div[40GclassName=[92m"p-4 md:p-8 text-sm text\r[6C[1B  [11G-zinc-500"[37m>Loading…</div>}>\r[1B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[22m[39m  Status   Config  [104m[30m[1m Usage [22m[39m[49m  Stats[K\r[5C[1B[K\r[3C[1B[1mSession[22m[K\r[5C[1B[K\r[3C[1B[37mTotal cost:            $23.21\r[1B[39m [3G [37mTotal duration (API):  1h 22m 15s\r[1B[39m   [37mTotal du[13Gation (wall):[27G13h 41m 16s[39m[K\r[3C[1B[37mTotal code changes:    6229[32Gli[35Ges added, 784 lines removed\r[3C[1BUsage by model:\r[1B[39m [3G [37m    claude-haiku-4-5:  986[31Ginput, 6.9k output, 1.4m cache read, 55.0k \r[1B[39m   [37mcache write ($0.2453)[39m[K\r[3C[1B[37m   claude-s[16Gnnet-4-6:  5.7k input, 294.9k output, 52.8m cache read, 716.8k\r[3C[1Bcache write ($22.97)\r[1B[39m[K\r[2C[1B [1mCurrent session[22m[K\r[3C[1B[47m[33m███████████████████████████████████               [39m[49m 70% used[K\r[1B   [37mResets 6:50am (UTC)[39m[K\r[1B[K\r[1B   [1mCurrent week (all models)[22m[K\r[2C[1B [47m[33m██████████████████▌                               [39m[49m 37% used    [79G[37m↓[39m[23;1H[4;32H[H\r[3C[17B[1mWhat's contr[17Gbuting to your limits usage?\r[3C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[3C[1Both[8Gr devices[18Gor claude.ai\r[3C[2BScanning local sessions…[39m[K\r[3C[1B                                                  [55G   [59G    [23;1H[4;32H[H\r[78C[22B[K[23;1H[4;32H[H\r[3C[21B[37mLast 24h[13G· these are independent characteristics of your usage, not a \r[3C[1Bbreakdown[39m[23;1H[4;32H[H\r[78C[22B[37m↓[39m[23;1H[4;32H	B87 <Suspensefallback={<divclassName="p-4 md:p-8 text-sm text  -zinc-500">Loading…</div>}>▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔Settings  Status   Config   Usage   StatsSessionTotal cost:            $23.21  Total duration (API):  1h 22m 15s   Total duation (wall):13h 41m 16sTotal code changes:    6229lies added, 784 lines removedUsage by model:      claude-haiku-4-5:  986input, 6.9k output, 1.4m cache read, 55.0k    cache write ($0.2453)   claude-snnet-4-6:  5.7k input, 294.9k output, 52.8m cache read, 716.8kcache write ($22.97) Current session███████████████████████████████████                70% used   Resets 6:50am (UTC)   Current week (all models) ██████████████████▌                                37% used    ↓What's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devicesor claude.aiScanning local sessions…                                                         Last 24h· these are independent characteristics of your usage, not a breakdown↓
cmq88v2220017pw5uuhahzmgs	cmq6wcl430001525urn13fvcx	22	15 June, 7:00 pm (Sydney)	2026-06-15 09:00:00	\N	ok	2026-06-10 15:49:26.186	15, 9am (UTC)[39m[K\r[1B[K\r[1B   [1mWhat's contributing to your limits usage?[22m[K\r[2C[1B [37mApproximate, based on local sessions on this[49Gmachine[57G— doe[63G not include [79G↓[39m[23;1H[4;32H[H\r[2B[91m▝▜[40m█████[49m▛▘[39m  [37mSonnet 4.6 · Claude Pro[39m[K\r[1B[91m  ▘▘ ▝▝  [39m  [37m/home/ec2-user[39m[K\r[2B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[14G[22m[39mStatus[23GConfig[31G[104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[1B[K\r[3C[1B[1mSession[22m[K\r[3C[1B[K\r[11C[1B[37mst:        [27G$0.0000[39m[K\r[3C[1B[37mTotal duration[19G(API):[28Gs[39m[K\r[3C[1B[37mTotal duration (wall): 39m 50s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUsage:                 0 input, 0 output, 0 cache read, 0 cache write\r[3C[1B[39m[K\r[3C[1B[1mWhat's contributing to your limits usage?\r[3C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[3C[1Bother devices or claude.ai[39m[K\r[3C[1B[K\r[3C[1B[37mScanning local sessions…\r[3C[1B[39m[K\r[3C[1B[37mEsc to c[13Gncel[39m                                                           [23;1H[7;32H[H\r[78C[22B[K[23;1H[7;32H[H\r[5B   [37mFable 5 is now available with the latest version of Claude Code! Run "claude \r[3C[1Bupdate" to update to v2.1.170+[39m[K\r[3C[2B[K\r[3C[2B[K\r[1B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[22m[39m  Status   Config  [104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[1B[K\r[3C[1B[1mSession[22m[K\r[3C[2B[37mTotal cost:            $0.0000[39m[K\r[3C[1B[37mTotal duration (API):[26G 0s[39m[K\r[3C[1B[37mTotal[11Guration (wa[23Gl): 39m 50s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUs[7Gge:  [13G     [19G        0 input, 0 output, 0 cache read, 0 cache write[39m[23;1H[13;32H	▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔   Settings  Status   Config Usage StatsSessionTotal cost:            $0.0000Total duration (API):  0sTotal duration (wall): 39m 50sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache writeCurrent session██████████████████████████                        52%usedResets 7:10pm (UTC)Current week (all models)███████████                                        22% used   Resets Jun 15, 9am (UTC)   What's contributing to your limits usage? Approximate, based on local sessions on thismachine— doe not include ↓▝▜█████▛▘  Sonnet 4.6 · Claude Pro  ▘▘ ▝▝    /home/ec2-user▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔SettingsStatusConfig Usage StatsSessionst:        $0.0000Total duration(API):sTotal duration (wall): 39m 50sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache writeWhat's contributing to your limits usage?Approximate, based on local sessions on this machine — does not include other devices or claude.aiScanning local sessions…Esc to cncel                                                              Fable 5 is now available with the latest version of Claude Code! Run "claude update" to update to v2.1.170+▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔Settings  Status   Config   Usage StatsSessionTotal cost:            $0.0000Total duration (API): 0sTotaluration (wal): 39m 50sTotal code changes:    0 lines added, 0 lines removedUsge:               0 input, 0 output, 0 cache read, 0 cache write
cmq88wgin0018pw5ufukbnd23	cmq6w5d940000525uus1ckhga	20	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	\N	ok	2026-06-10 15:50:31.583	[59G0[61Gcache[67Gwrite[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m██████████████████████████████████████████████████[54G[39m[49m100%[59Gused\r\r\n[3G[37mResets[10G3:50pm[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m██████████                                        [54G[39m[49m20%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A[30D[27B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[7A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[2C[1Both[7Gr devices[17Gor claude.ai\r[2C[2BScanning local sessions…[39m[K\r[2C[1B[K\r[2C[1B[37mEsc [8Go[10Gca[13Gcel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[17A[30D[17B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r\r\n[3G19%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A	B❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   Stats\nSession\n\nTotalcost:$0.0000\nTotalduration(API):0s\nTotalduration(wall):1h1m58s\nTotalcodechanges:0linesadded,0linesremoved\nUsage:0input,0output,0cacheread,0cachewrite\n\nCurrentsession\n██████████████████████████████████████████████████100%used\nResets3:50pm(UTC)\n\nCurrentweek(allmodels)\n██████████                                        20%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devicesor claude.aiScanning local sessions…Esc ocacelLast 24h· these are independent characteristics of your usage, not a breakdown\n19%ofyourusagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq88wvuo0019pw5u1g3bsa34	cmq6w5d940000525uus1ckhga	20	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	\N	ok	2026-06-10 15:50:51.456	[59G0[61Gcache[67Gwrite[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m██████████████████████████████████████████████████[54G[39m[49m100%[59Gused\r\r\n[3G[37mResets[10G3:50pm[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m██████████                                        [54G[39m[49m20%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A[30D[27B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[7A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[2C[1Both[7Gr devices[17Gor claude.ai\r[2C[2BScanning local sessions…[39m[K\r[2C[1B[K\r[2C[1B[37mEsc [8Go[10Gca[13Gcel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[17A[30D[17B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r\r\n[3G19%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A	B❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   Stats\nSession\n\nTotalcost:$0.0000\nTotalduration(API):0s\nTotalduration(wall):1h2m18s\nTotalcodechanges:0linesadded,0linesremoved\nUsage:0input,0output,0cacheread,0cachewrite\n\nCurrentsession\n██████████████████████████████████████████████████100%used\nResets3:50pm(UTC)\n\nCurrentweek(allmodels)\n██████████                                        20%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devicesor claude.aiScanning local sessions…Esc ocacelLast 24h· these are independent characteristics of your usage, not a breakdown\n19%ofyourusagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq88xkyc001bpw5uftk2qoqb	cmq6w5d940000525uus1ckhga	20	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	\N	ok	2026-06-10 15:51:23.988	,[59G0[61Gcache[67Gwrite[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m                                                  [54G[39m[49m0%[57Gused\r\r\n[3G[37mResets[10G8:50pm[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m██████████                                        [54G[39m[49m20%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A[30D[27B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[7A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[2C[1Both[7Gr devices[17Gor claude.ai\r[2C[2BScanning local sessions…[39m[K\r[2C[1B[K\r[2C[1B[37mEsc [8Go[10Gca[13Gcel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[17A[30D[17B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r\r\n[3G19%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A	B❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   StatsSession\n\nTotalcost:$0.0000\nTotalduration(API):0s\nTotalduration(wall):9s\nTotalcodechanges:0linesadded,0linesremoved\nUsage:0input,0output,0cacheread,0cachewrite\n\nCurrentsession\n                                                  0%used\nResets8:50pm(UTC)\n\nCurrentweek(allmodels)\n██████████                                        20%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devicesor claude.aiScanning local sessions…Esc ocacelLast 24h· these are independent characteristics of your usage, not a breakdown\n19%ofyourusagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq890j6h001hpw5urefolxz7	cmq6w5d940000525uus1ckhga	20	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	\N	ok	2026-06-10 15:53:41.657	[56Gcache[62Gread,[68G42.5k[74Gcache[39m\r\r\n[3G[37mwrite[9G($0.4100)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[37m❯ [39m\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[3G[91m⏵⏵[6Gbypass[13Gpermissions[25Gon[37m (shift+tab[39Gto[42Gcycle)[49G·[51Gesc[55Gto[58Ginterrupt[39m\r\r\n[10G[91m✘[12GAuto-update[24Gfailed:[32Gno[35Gwrite[41Gpermission[52Gto[55Gnpm[59Gprefix[66G·[68GRun[72G[1m/doctor[22m[39m\r\r\n[30C[27A[30D[27B\r[2C[9A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r[2C[1B18%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r[1B   [37mLonger sessions are more expensive even when cached. /compact mid-task, [39m[K\r[1B  [4G[37m/clear when switching to new tasks.\r[1B[39m[K\r[2C[1B[1mSkills, subagents, plugins, and MCP servers[22m[K\r[2C[1B[37mNo attribution data yet · accumulates as you use Claude[39m[K\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[37m❯ [39m\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[3G[91m⏵⏵[6Gbypass[13Gpermissions[25Gon[37m (shift+tab[39Gto[42Gcycle)[49G·[51Gesc[55Gto[58Ginterrupt[39m\r\r\n[10G[91m✘[12GAuto-update[24Gfailed:[32Gno[35Gwrite[41Gpermission[52Gto[55Gnpm[59Gprefix[66G·[68GRun[72G[1m/doctor[22m[39m\r\r\n[30C[37A	.5kcache\nwrite($0.4100)\n\nCurrentsession\n█                                                 2%used\nResets8:50pm(UTC)\n\nCurrentweek(allmodels)\n██████████                                        20%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·esctointerrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor\nTotalduration(API):1m19s\nTotalduration(wall):2m27s\nTotalcodechanges:0linesadded,0linesremoved\nUsagebymodel:\n claude-haiku-4-5:871input,14output,0cacheread,0cachewrite\n($0.0009)\n claude-sonnet-4-6:25input,3.0koutput,687.2kcacheread,42.5kcache\nwrite($0.4100)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nEsctocancel\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·esctointerrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor\nLast 24h· these are independent characteristics of your usage, not a breakdown18%ofyourusagewasat>150kcontext   Longer sessions are more expensive even when cached. /compact mid-task,   /clear when switching to new tasks.Skills, subagents, plugins, and MCP serversNo attribution data yet · accumulates as you use Claude\n\ndtoday·wtoweek\n\nEsctocancel\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·esctointerrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor
cmq891wbi001ipw5uq5h902x0	cmq6wcl430001525urn13fvcx	22	15 June, 7:00 pm (Sydney)	2026-06-15 09:00:00	f	ok	2026-06-10 15:54:45.342	(B[<u[>1u[>4;2m[?1000h[?1002h[?1003h[?1006h[?25l[H\r[2B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[1B[39m   [94m[1mSettings[22m[39m  Status   Config[31G[104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[2B[1mSession[22m[K\r[3C[1B[K\r[3C[1B[37mTotal cost:            $0.0000\r[3C[1BTotal duration (API):  0s\r[3C[1BTotal duration (wall): 45m 9s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUsage:                 0 input, 0 output, 0 cache read, 0 cache write\r[3C[2B[39m[1mCurrent session\r[3C[1B[22m[47m[33m██████████████████████████                        [55G[39m[49m52%[59Gused\r[3C[1B[37mResets 7:10pm (UTC)\r[3C[2B[39m[1mCurrent week (all models)\r[3C[1B[22m[47m[33m███████████                                       [39m[49m 22% used[K\r[1B   [37mResets Jun 15, 9am (UTC)[39m[K\r[1B[K\r[1B   [1mWhat's contributing to your limits usage?[22m[K\r[2C[1B [37mApproximate, based on local sessions on this[49Gmachine[57G— doe[63G not include [79G↓[39m[23;1H[4;32H[H\r[3C[21B[37mRefreshing…[39m[K\r[3C[1B                                                                        [23;1H[4;32H[H\r[78C[22B[K[23;1H[4;32H[H\r[29C[14B[47m[33m█████████████████████[55G[39m[49m94\r[14C[4B[47m[33m██▌[56G[39m[49m7\r[3C[3B[1mUsage credits\r[3C[1B[22m[37mUsage credits are off · /usage-credits to turn them on[39m[23;1H[4;32H	B▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔   Settings  Status   Config Usage StatsSessionTotal cost:            $0.0000Total duration (API):  0sTotal duration (wall): 45m 9sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache writeCurrent session██████████████████████████                        52%usedResets 7:10pm (UTC)Current week (all models)███████████                                        22% used   Resets Jun 15, 9am (UTC)   What's contributing to your limits usage? Approximate, based on local sessions on thismachine— doe not include ↓Refreshing…                                                                        █████████████████████94██▌7Usage creditsUsage credits are off · /usage-credits to turn them on
cmq8922q8001jpw5ulfi84ual	cmq6wcl430001525urn13fvcx	22	15 June, 7:00 pm (Sydney)	2026-06-15 09:00:00	\N	ok	2026-06-10 15:54:53.648	15, 9am (UTC)[39m[K\r[1B[K\r[1B   [1mWhat's contributing to your limits usage?[22m[K\r[2C[1B [37mApproximate, based on local sessions on this[49Gmachine[57G— doe[63G not include [79G↓[39m[23;1H[4;32H[H\r[2B[91m▝▜[40m█████[49m▛▘[39m  [37mSonnet 4.6 · Claude Pro[39m[K\r[1B[91m  ▘▘ ▝▝  [39m  [37m/home/ec2-user[39m[K\r[2B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[14G[22m[39mStatus[23GConfig[31G[104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[1B[K\r[3C[1B[1mSession[22m[K\r[3C[1B[K\r[11C[1B[37mst:        [27G$0.0000[39m[K\r[3C[1B[37mTotal duration[19G(API):[28Gs[39m[K\r[3C[1B[37mTotal duration (wall): 45m 17s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUsage:                 0 input, 0 output, 0 cache read, 0 cache write\r[3C[1B[39m[K\r[3C[1B[1mWhat's contributing to your limits usage?\r[3C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[3C[1Bother devices or claude.ai[39m[K\r[3C[1B[K\r[3C[1B[37mScanning local sessions…\r[3C[1B[39m[K\r[3C[1B[37mEsc to c[13Gncel[39m                                                           [23;1H[7;32H[H\r[78C[22B[K[23;1H[7;32H[H\r[5B   [37mFable 5 is now available with the latest version of Claude Code! Run "claude \r[3C[1Bupdate" to update to v2.1.170+[39m[K\r[3C[2B[K\r[3C[2B[K\r[1B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[22m[39m  Status   Config  [104m[30m[1m Usage [40G[22m[39m[49mStats\r[3C[1B[K\r[3C[1B[1mSession[22m[K\r[3C[2B[37mTotal cost:            $0.0000[39m[K\r[3C[1B[37mTotal duration (API):[26G 0s[39m[K\r[3C[1B[37mTotal[11Guration (wa[23Gl): 45m 17s\r[3C[1BTotal code changes:    0 lines added, 0 lines removed\r[3C[1BUs[7Gge:  [13G     [19G        0 input, 0 output, 0 cache read, 0 cache write[39m[23;1H[13;32H	▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔   Settings  Status   Config Usage StatsSessionTotal cost:            $0.0000Total duration (API):  0sTotal duration (wall): 45m 17sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache writeCurrent session██████████████████████████                        52%usedResets 7:10pm (UTC)Current week (all models)███████████                                       22%used   Resets Jun 15, 9am (UTC)   What's contributing to your limits usage? Approximate, based on local sessions on thismachine— doe not include ↓▝▜█████▛▘  Sonnet 4.6 · Claude Pro  ▘▘ ▝▝    /home/ec2-user▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔SettingsStatusConfig Usage StatsSessionst:        $0.0000Total duration(API):sTotal duration (wall): 45m 17sTotal code changes:    0 lines added, 0 lines removedUsage:                 0 input, 0 output, 0 cache read, 0 cache writeWhat's contributing to your limits usage?Approximate, based on local sessions on this machine — does not include other devices or claude.aiScanning local sessions…Esc to cncel                                                              Fable 5 is now available with the latest version of Claude Code! Run "claude update" to update to v2.1.170+▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔Settings  Status   Config   Usage StatsSessionTotal cost:            $0.0000Total duration (API): 0sTotaluration (wal): 45m 17sTotal code changes:    0 lines added, 0 lines removedUsge:               0 input, 0 output, 0 cache read, 0 cache write
cmq894ekl001kpw5u0wrbbvns	cmq6w5d940000525uus1ckhga	20	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	f	ok	2026-06-10 15:56:42.309	7G14[40Goutput,[48G0[50Gcache[56Gread,[62G0[64Gcache[70Gwrite[39m\r\r\n[3G[37m($0.0009)[39m\r\r\n[3G[37m [6Gclaude-sonnet-4-6:[26G394[30Ginput,[37G11.3k[43Goutput,[51G2.4m[56Gcache[62Gread,[68G60.9k[74Gcache[39m\r\r\n[3G[37mwrite[9G($1.12)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m██▌                                               [54G[39m[49m5%[57Gused\r\r\n[3G[37mResets[10G8:50pm[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m██████████                                        [54G[39m[49m20%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[31A[30D[31B\r[2C[5A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r[2C[1B18%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r[2C[1B [37mLonger sessions are more expensive even when cached. /compact mid-task, [39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[41A[30D[41B\r[12C[22A[47m[33m▌[55G[39m[49m1\r[18C[1B[37m0:59pm (UTC)\r[2C[18B[39m[1mUsage credits\r[2C[1B[22m[37mUsage credits are off · /usage-credits to turn them on\r[2C[1B[39m[K\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[42A	B❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   Stats\nSession\n\nTotalcost:$1.12\nTotalduration(API):3m43s\nTotalduration(wall):5m28s\nTotalcodechanges:236linesadded,2linesremoved\nUsagebymodel:\n claude-haiku-4-5:871input,14output,0cacheread,0cachewrite\n($0.0009)\n claude-sonnet-4-6:394input,11.3koutput,2.4mcacheread,60.9kcache\nwrite($1.12)\n\nCurrentsession\n██▌                                               5%used\nResets8:50pm(UTC)\n\nCurrentweek(allmodels)\n██████████                                        20%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nLast 24h· these are independent characteristics of your usage, not a breakdown18%ofyourusagewasat>150kcontext Longer sessions are more expensive even when cached. /compact mid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nRefreshing…\n\nEsctocancel\n▌10:59pm (UTC)Usage creditsUsage credits are off · /usage-credits to turn them on\nEsctocancel
cmq897vz0001rpw5umr2rz69n	cmq6w5d940000525uus1ckhga	21	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	\N	ok	2026-06-10 15:59:24.828	[49G·[51Gesc[55Gto[58Ginterrupt[39m\r\r\n[10G[91m✘[12GAuto-update[24Gfailed:[32Gno[35Gwrite[41Gpermission[52Gto[55Gnpm[59Gprefix[66G·[68GRun[72G[1m/doctor[22m[39m\r\r\n[30C[37A[30D[37B\r[2C[22A[K\r[2C[1B[37mTotal[9Gcost:  [17G  [20G      $1.63\r[2C[1BTotal duration (API):  4m 40s\r[2C[1BTotal duration (w[21Gll): 8m 11s[39m[K\r[2C[1B[37mTot[7Gl code changes:    400 lines added, 2 lines removed\r[2C[1BUsage by model:\r[2C[1B    claude-haiku-4-5:  871 input, 14 output, 0 cache read, 0 cache write \r[2C[1B($0.0009)[39m[K\r[2C[1B[37m   cl[9Gude-sonnet-4-6: [26G405 input, 14.9k output, 3.0m cache read, 131.9k \r[2C[1Bcache write ($1.63)\r[2C[1B[39m[K\r[2C[1B[1mWhat's contributing to your limits usage?[22m[K\r[2C[1B[37mApproximate, based on local sessions on this machine — does not include \r[2C[1Bother devices [18Gr claude.ai\r[2C[2BLast 24h · these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[1B[39m[K\r[1B  17%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r[1B   [37mLonger sessions are more expensive even when cached. /compact mid-task, [39m[K\r[2C[1B [37m/clear when switching to new [34Gasks.[39m[K\r[9C[1B[K\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[37m❯ [39m\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[3G[91m⏵⏵[6Gbypass[13Gpermissions[25Gon[37m (shift+tab[39Gto[42Gcycle)[49G·[51Gesc[55Gto[58Ginterrupt[39m\r\r\n[10G[91m✘[12GAuto-update[24Gfailed:[32Gno[35Gwrite[41Gpermission[52Gto[55Gnpm[59Gprefix[66G·[68GRun[72G[1m/doctor[22m[39m\r\r\n[30C[37A	────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·esctointerrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor\nWhat's contributing to your limits usage?Approximate, based on local sessions on this machine — does not include other devices orclaude.aiLast 24h · these are independent characteristics of your usage, not a breakdown17% of your usage was at >150k contextLonger sessions are more expensive even when cached. /compact mid-task,  /clear when switching to new tasks.Skills, subagents, plugins, and MCP serversNo attribution data yet · accumulates as you use Clauded to day · w to week  Esc to cancel❯ ────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·esctointerrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor\nTotalcost:          $1.63Total duration (API):  4m 40sTotal duration (wll): 8m 11sTotl code changes:    400 lines added, 2 lines removedUsage by model:    claude-haiku-4-5:  871 input, 14 output, 0 cache read, 0 cache write ($0.0009)   clude-sonnet-4-6: 405 input, 14.9k output, 3.0m cache read, 131.9k cache write ($1.63)What's contributing to your limits usage?Approximate, based on local sessions on this machine — does not include other devices r claude.aiLast 24h · these are independent characteristics of your usage, not a breakdown  17%ofyourusagewasat>150kcontext   Longer sessions are more expensive even when cached. /compact mid-task,  /clear when switching to new asks.\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·esctointerrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor
cmq89kdd200076c5uslp76ons	cmq6w5d940000525uus1ckhga	\N	\N	\N	\N	error	2026-06-10 16:09:07.238	8A[91md[8G[93ma[25G[37m75[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[15A[37m \r[5C[7B[91mu[9G[93mt[25G[37m80[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h]0;⠐ Implement server capacity scoring system[?25l[2D[5B\r[6C[8A[91mla[10G[93min[26G[37m4[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[8C[8A[91mt[12G[93mg[26G[37m7[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[9C[8A[91mi[13G[93m…[25G[37m91[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[10C[8A[91mng[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[8A[91m✻[13G…[26G[37m2[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[25C[8A[37m4[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[8A[91m✶[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[16C[8A[37m5[26G5[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[8A[91m*[26G[37m6[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[15A[37m●[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[25C[8A[37m7[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[8A[91m✢[26G[37m8[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[25C[8A[37m9[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[23C[8A[37m600[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[8A[91m·[26G[37m1[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[25C[8A[37m2[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h]0;⠂ Implement server capacity scoring system[?25l[2D[5B\r[25C[8A[37m3[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[25C[8A[37m4[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[25C[8A[37m5[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[15A[37m \r[2C[7B[93mU[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[8A[91m✢[4G[93mn[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[4C[8A[93md[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[2C[8A[91mUn[6G[93mul[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[8A[91m*[5Gd[8G[93ma[17G[37m6[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h	B/home/ec2-user/WorkerAI/claude-task-monitor/prisma/schema.prisma)\n ⎿ Running…\n ⎿ modelDailyReport{\nidString@id@default(cuid())\ndateDateTime@default(now())\n…+17lines(ctrl+otoexpand)\n\n Reading1file…(ctrl+otoexpand)\n ⎿$cat\n/home/ec2-user/WorkerAI/claude-task-monitor/app/reports/daily/page.tsx\n\n❯ /usage\n ⎿Settingsdialogdismissed\n\n✽Undulating…(12s·↑421tokens)\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·esctointerrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor\nSettingsdialogdismissed\nU\n\n\n\n\n\n\n\nnd\n\n\n\n\n\n\n\n✻Uu\n\n\n\n\n\n\n\nnl\n\n\n\n\n\n\n\nda\n\n\n\n\n\n\n\nula↓\n\n\n\n\n\n\n\n✶5\n\n\n\n\n\n\n\n*39\n\n\n\n\n\n\n\n✢31\n\n\n\n\n\n\n\n2\n\n\n\n\n\n\n\n·4\n\n\n\n\n\n\n\n2s… (ctrl+o to expand)\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n/home/ec2-user/WorkerAI/claude-task-monitor/app/dashboard/page.tsx | head -100\n\n\n\n\n\n\n\n\n\n\n\n\n43\n\n\n\n\n\n\n\n51\n\n\n\n\n\n\n\n2\n\n\n\n\n\n\n\n✢4\n\n\n\n\n\n\n\n●\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n3\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n*463\n\n\n\n\n\n\n\nUndulating…\n\n\n\n\n\n\n\nUndulating…↑88\n\n\n\n\n\n\n\n✶501\n\n\n\n\n\n\n\nU26\n\n\n\n\n\n\n\n/home/ec2-user/WorkerAI/claude-task-monitor/app/api/dashboard/route.ts\n\n\n\n\n\n\n\n\n\n\n\n\n✻n38\n\n\n\n\n\n\n\nUdu51\n\n\n\n\n\n\n\n✽nl63\n\n\n\n\n\n\n\nda75\n\n\n\n\n\n\n\n ut80\n\n\n\n\n\n\n\nlain4\n\n\n\n\n\n\n\ntg7\n\n\n\n\n\n\n\ni…91\n\n\n\n\n\n\n\nng\n\n\n\n\n\n\n\n✻…2\n\n\n\n\n\n\n\n4\n\n\n\n\n\n\n\n✶\n\n\n\n\n\n\n\n55\n\n\n\n\n\n\n\n*6\n\n\n\n\n\n\n\n●\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n7\n\n\n\n\n\n\n\n✢8\n\n\n\n\n\n\n\n9\n\n\n\n\n\n\n\n600\n\n\n\n\n\n\n\n·1\n\n\n\n\n\n\n\n2\n\n\n\n\n\n\n\n3\n\n\n\n\n\n\n\n4\n\n\n\n\n\n\n\n5\n\n\n\n\n\n\n\n U\n\n\n\n\n\n\n\n✢n\n\n\n\n\n\n\n\nd\n\n\n\n\n\n\n\nUnul\n\n\n\n\n\n\n\n*da6
cmq89knrz00086c5udx271x5a	cmq6w5d940000525uus1ckhga	22	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	\N	ok	2026-06-10 16:09:20.735	cache[9Gwrite[15G($3.46)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m██████████▌                                       [54G[39m[49m21%[58Gused\r\r\n[3G[37mResets[10G8:50pm[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m███████████                                       [54G[39m[49m22%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[31A[30D[31B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[7A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[2C[1Both[7Gr devices[17Gor claude.ai\r[2C[2BScanning local sessions…[39m[K\r[2C[1B[K\r[2C[1B[37mEsc [8Go[10Gca[13Gcel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[21A[30D[21B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r\r\n[3G15%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[31A	B❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   Stats\nSession\n\nTotalcost:$3.46\nTotalduration(API):8m42s\nTotalduration(wall):18m7s\nTotalcodechanges:1178linesadded,8linesremoved\nUsagebymodel:\n claude-haiku-4-5:871input,14output,0cacheread,0cachewrite\n($0.0009)\n claude-sonnet-4-6:791input,29.9koutput,7.0mcacheread,245.2k\ncachewrite($3.46)\n\nCurrentsession\n██████████▌                                       21%used\nResets8:50pm(UTC)\n\nCurrentweek(allmodels)\n███████████                                       22%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devicesor claude.aiScanning local sessions…Esc ocacelLast 24h· these are independent characteristics of your usage, not a breakdown\n15%ofyourusagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq8a50hs000x6c5uwdfh1fdo	cmq6w5d940000525uus1ckhga	24	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	\N	ok	2026-06-10 16:25:10.336	cache[9Gwrite[15G($1.55)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m████████████████████                              [54G[39m[49m40%[58Gused\r\r\n[3G[37mResets[10G8:50pm[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m████████████                                      [54G[39m[49m24%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[31A[30D[31B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[7A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[2C[1Both[7Gr devices[17Gor claude.ai\r[2C[2BScanning local sessions…[39m[K\r[2C[1B[K\r[2C[1B[37mEsc [8Go[10Gca[13Gcel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[21A[30D[21B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r\r\n[3G14%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[31A	❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   StatsSession\n\nTotalcost:$1.55\nTotalduration(API):4m51s\nTotalduration(wall):13m17s\nTotalcodechanges:396linesadded,108linesremoved\nUsagebymodel:\n claude-haiku-4-5:859input,15output,0cacheread,0cachewrite\n($0.0009)\n claude-sonnet-4-6:402input,16.8koutput,2.9mcacheread,118.5k\ncachewrite($1.55)\n\nCurrentsession\n████████████████████                              40%used\nResets8:50pm(UTC)\n\nCurrentweek(allmodels)\n████████████                                      24%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devicesor claude.aiScanning local sessions…Esc ocacelLast 24h· these are independent characteristics of your usage, not a breakdown\n14%ofyourusagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq89q16a000e6c5ui8jjj2pz	cmq6w5d940000525uus1ckhga	22	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	\N	ok	2026-06-10 16:13:31.379	se Claude\r[2B[39m  [37md to day · w to week[39m[K\r[1B[K\r[1B  [37mEsc to cancel[39m[K\r[2C[1B[K\r[1B[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[37m❯ [39m\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[3G[91m⏵⏵[6Gbypass[13Gpermissions[25Gon[37m (shift+tab[39Gto[42Gcycle)[49G·[51Gesc[55Gto[58Ginterrupt[39m\r\r\n[10G[91m✘[12GAuto-update[24Gfailed:[32Gno[35Gwrite[41Gpermission[52Gto[55Gnpm[59Gprefix[66G·[68GRun[72G[1m/doctor[22m[39m\r\r\n[30C[37A[30D[37B\r[2C[22A[37m   claude-sonnet-4-6:[25G 21 input, 2.9k ou[44Gput, 440.2k[56Gcach[61G read, 41.4k cache\r[2C[1Bwrite[9G($0.3307)[39m[K\r[2C[2B[1mWhat's contributing to your limits usage?[22m[K\r[2C[1B[37mApproximate, based on local sessions on this machine — does not include \r[2C[1Bother devices or claude.ai\r[2C[1B[39m[K\r[2C[1B[37mLast 24h · these[24Gind[28Gp[30Gnd[34Gt characteristi[50Gs of your us[63Gge, not [72G [39m[K\r[2C[1B[37mbreakdown[39m[K\r[2C[2B15% of your usage was at >150k context[K\r[2C[1B [37mLonge[10G sessions are more[29Gexpensive even[44Gwhen cached. /compact mid-task, \r[3C[1B/clear when switching to new tasks.\r[2C[1B[39m[K\r[2C[1B[1mSkills, subagents, plugins, and MCP servers\r[2C[1B[22m[37mNo a[8Gtribution data yet · accumulates as you use Claude\r[2B[39m  [37md to day · w to week[39m[K\r[1B[K\r[1B  [37mEsc to cancel[39m[K\r[2C[1B[K\r[1B[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[37m❯ [39m\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[3G[91m⏵⏵[6Gbypass[13Gpermissions[25Gon[37m (shift+tab[39Gto[42Gcycle)[49G·[51Gesc[55Gto[58Ginterrupt[39m\r\r\n[10G[91m✘[12GAuto-update[24Gfailed:[32Gno[35Gwrite[41Gpermission[52Gto[55Gnpm[59Gprefix[66G·[68GRun[72G[1m/doctor[22m[39m\r\r\n[30C[37A	·wtoweek\n\nEsctocancel\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·esctointerrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor\n   claude-sonnet-4-6: 21 input, 2.9k ouput, 440.2kcach read, 41.4k cachewrite($0.3307)What's contributing to your limits usage?Approximate, based on local sessions on this machine — does not include other devices or claude.aiLast 24h · theseindpndt characteristis of your usge, not  breakdown15% of your usage was at >150k context Longe sessions are moreexpensive evenwhen cached. /compact mid-task, /clear when switching to new tasks.Skills, subagents, plugins, and MCP serversNo atribution data yet · accumulates as you use Claude  d to day · w to week  Esc to cancel────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·esctointerrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor\n   claude-sonnet-4-6: 21 input, 2.9k ouput, 440.2kcach read, 41.4k cachewrite($0.3307)What's contributing to your limits usage?Approximate, based on local sessions on this machine — does not include other devices or claude.aiLast 24h · theseindpndt characteristis of your usge, not  breakdown15% of your usage was at >150k context Longe sessions are moreexpensive evenwhen cached. /compact mid-task, /clear when switching to new tasks.Skills, subagents, plugins, and MCP serversNo atribution data yet · accumulates as you use Claude  d to day · w to week  Esc to cancel────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·esctointerrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor
cmq89s290000f6c5u7z5tn5q5	cmq6w5d940000525uus1ckhga	\N	\N	\N	\N	error	2026-06-10 16:15:06.084	[?25l[2D[5B\r[10A[91m✶[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[10A[91m✻[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[28C[10A[37m↓[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[10A[91m✽[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h]0;⠂ Implement automated daily reports with scheduler[?25l[2D[5B\r[10A[91m✻[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[10A[37m [3G[39mSearching for [1m1[22m pattern… [37m(ctrl+o[38G [40Gxpand)\r[1B[39m[K\r[1B[91m✻[3GPhilosophising… [37m(2m 59s · ↓[31G9.2k tokens)\r[1B  ⎿  Tip: Use /btw to ask a quick side question without interrupting Claude's \r[1B[39m     [37mcurrent work[39m[K\r[1B[K\r[2B[37m❯ [39m[K\r[1B[37m────────────────────────────────────────────────────────────────────────────────\r[2C[1B[91m⏵⏵ bypass permissions on[37m (shift+tab to cycle) · esc to [60Gterrupt[39m[K\r\r\n[10G[91m✘[12GAuto-update[24Gfailed:[32Gno[35Gwrite[41Gpermission[52Gto[55Gnpm[59Gprefix[66G·[68GRun[72G[1m/doctor[22m[39m\r\r\n[54G[37mSettings[63Gdialog[70Gdismissed[39m\r\r\n[2C[5A[?25h[?25l[2D[5B\r[10A[91m✶[20G[37m3[23G0s · ↓[39m [37m9.2k tokens)[39m[K\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[14C[10A[93mng…[28G[37m↑[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[14C[10A[91mn[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[10A[91m*[16Gg[32G[37m3[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[16C[10A[91m…[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[10A[91m✢[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[12A[37m●[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[10A[91m·[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h]0;⠐ Implement automated daily reports with scheduler[?25l[2D[5B\r[10A[91m✢[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[12A[37m [39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h[?25l[2D[5B\r[10A[91m*[23G[37m1[39m\r\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n[2C[5A[?25h	Last 24h · these are independent characteristics of your usage, not a breakdown14% of your usage was at >150k contextLongesessions are moreexpensive even when cached. /compact mid-task, /clear when switching to new tasks.Skills, subagents, plugins, and MCP serversNo attribution data yet · accumulates as you use Clauded to day · w to weekUsage creditsUsage credits are off · /usage-credits to turn them onEsc to cancel────────────────────────────────────────────────────────────────────────────────❯ ────────────────────────────────────────────────────────────────────────────────⏵⏵ bypass permissions on (shift+tab to cycle) · esc to interrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor\n 65+ _lastDailyReportDate?:string |null;\n 66 //zombie-detectionpane-linebaseline(ownedbylib/zombie-d\n  etection.ts)\n 67 _zombiePaneLines?:Map<string,number>;\n 68 };\n\n●Update(instrumentation.node.ts)\n ⎿ Erroreditingfile\n\n❯ /usage\n ⎿Settingsdialogdismissed\n\n·Philosophising…(2m58s·↑9.2ktokens)\n ⎿ Tip:Use/btwtoaskaquicksidequestionwithoutinterruptingClaude's\ncurrentwork\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·esctointerrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor\nSettingsdialogdismissed\n✢\n\n\n\n\n\n\n\n\n\n*9\n\n\n\n\n\n\n\n\n\n✶\n\n\n\n\n\n\n\n\n\n✻\n\n\n\n\n\n\n\n\n\n↓\n\n\n\n\n\n\n\n\n\n✽\n\n\n\n\n\n\n\n\n\n✻\n\n\n\n\n\n\n\n\n\n Searching for 1 pattern… (ctrl+o xpand)✻Philosophising… (2m 59s · ↓9.2k tokens)  ⎿  Tip: Use /btw to ask a quick side question without interrupting Claude's      current work❯ ────────────────────────────────────────────────────────────────────────────────⏵⏵ bypass permissions on (shift+tab to cycle) · esc to terrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor\nSettingsdialogdismissed\n✶30s · ↓ 9.2k tokens)\n\n\n\n\n\n\n\n\n\nng…↑\n\n\n\n\n\n\n\n\n\nn\n\n\n\n\n\n\n\n\n\n*g3\n\n\n\n\n\n\n\n\n\n…\n\n\n\n\n\n\n\n\n\n✢\n\n\n\n\n\n\n\n\n\n●\n\n\n\n\n\n\n\n\n\n\n\n·\n\n\n\n\n\n\n\n\n\n✢\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n*1
cmq89s8e6000g6c5urtj5cxq6	cmq6w5d940000525uus1ckhga	23	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	\N	ok	2026-06-10 16:15:14.046	\n[3G[37mwrite[9G($0.79)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m███████████████                                   [54G[39m[49m30%[58Gused\r\r\n[3G[37mResets[10G8:50pm[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m███████████▌                                      [54G[39m[49m23%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[31A[30D[31B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[7A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[2C[1Both[7Gr devices[17Gor claude.ai\r[2C[2BScanning local sessions…[39m[K\r[2C[1B[K\r[2C[1B[37mEsc [8Go[10Gca[13Gcel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[21A[30D[21B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r\r\n[3G14%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[31A	❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   StatsSession\n\nTotalcost:$0.79\nTotalduration(API):2m52s\nTotalduration(wall):3m21s\nTotalcodechanges:235linesadded,95linesremoved\nUsagebymodel:\n claude-haiku-4-5:859input,15output,0cacheread,0cachewrite\n($0.0009)\n claude-sonnet-4-6:38input,9.3koutput,1.5mcacheread,53.7kcache\nwrite($0.79)\n\nCurrentsession\n███████████████                                   30%used\nResets8:50pm(UTC)\n\nCurrentweek(allmodels)\n███████████▌                                      23%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devicesor claude.aiScanning local sessions…Esc ocacelLast 24h· these are independent characteristics of your usage, not a breakdown\n14%ofyourusagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq89w7z5000k6c5udbw87ceb	cmq6w5d940000525uus1ckhga	24	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	f	ok	2026-06-10 16:18:20.129	Ginp[33Gt, 13.4k outp[47Gt, 2.0m cache read, 113.0k cache\r[2C[1Bwrite ($1.22)\r[2C[1B[39m[K\r[2C[1B[1mCurrent session\r[2C[1B[22m[47m[33m███████████████████▌                              [54G[39m[49m39%[58Gused\r[2C[1B[37mResets 8:50pm[17G(UTC)[39m[K\r[2C[2B[1mCurrent week (all models)\r[2C[1B[22m[47m[33m████████████                                      [54G[39m[49m24%[58Gused\r[1B  [37mResets Jun 10, 11pm (UTC)[39m[K\r[1B[K\r[1B  [1mWhat's contributing to your limits usage?[22m[K\r[2C[1B[37mApproximate, based on local sessions [41Gn this machine —[58Gdoes not include \r[2C[1Bother devices or claude.ai[39m[K\r\r\n\r\r\n[3G[37mLast[8G24h[12G·[14Gthese[20Gare[24Gindependent[36Gcharacteristics[52Gof[55Gyour[60Gusage,[67Gnot[71Ga[39m\r\r\n[3G[37mbreakdown[39m\r\r\n\r\r\n[3G14%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[1mUsage[9Gcredits[22m\r\r\n[3G[37mUsage[9Gcredits[17Gare[21Goff[25G·[27G/usage-credits[42Gto[45Gturn[50Gthem[55Gon[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[37m❯ [39m\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[3G[91m⏵⏵[6Gbypass[13Gpermissions[25Gon[37m (shift+tab[39Gto[42Gcycle)[49G·[51Gesc[55Gto[58Ginterrupt[39m\r\r\n[10G[91m✘[12GAuto-update[24Gfailed:[32Gno[35Gwrite[41Gpermission[52Gto[55Gnpm[59Gprefix[66G·[68GRun[72G[1m/doctor[22m[39m\r\r\n[30C[48A	led:nowritepermissiontonpmprefix·Run/doctor\nother devices orclaude.aiLast 24h · these are independent characteristics of your usage, not a breakdown14% of your usage was at >150k contextLonger sessions are more expensive even when cached. /compact mid-task,  /clear when switching to new tasks.Skills, subagents, plugins, and MCP serversNo attribution data yet · accumulates as you use Clauded to day · w to weekUsage creditsUage credits are off · /usage-credits to turn them on  Esc to cancel❯ ────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·esctointerrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor\nTotl cost:            $1.22Total duration (API):  3m 52sTotal duration (wall): 6m 27sTotal cod chages:   321 line addd, 108 lines removedUsag by model:    claude-haiku-4-5:  859 input, 15 output, 0 cache read, 0 cache write ($0.0009)  claude-sonet-4-6:  48inpt, 13.4k outpt, 2.0m cache read, 113.0k cachewrite ($1.22)Current session███████████████████▌                              39%usedResets 8:50pm(UTC)Current week (all models)████████████                                      24%used  Resets Jun 10, 11pm (UTC)  What's contributing to your limits usage?Approximate, based on local sessions n this machine —does not include other devices or claude.ai\n\nLast24h·theseareindependentcharacteristicsofyourusage,nota\nbreakdown\n\n14%ofyourusagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nUsagecredits\nUsagecreditsareoff·/usage-creditstoturnthemon\n\nEsctocancel\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·esctointerrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor
cmq8a0h2l000s6c5u67s7vmgs	cmq6w5d940000525uus1ckhga	24	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	\N	ok	2026-06-10 16:21:38.541	cache[9Gwrite[15G($1.55)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m████████████████████                              [54G[39m[49m40%[58Gused\r\r\n[3G[37mResets[10G8:50pm[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m████████████                                      [54G[39m[49m24%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[31A[30D[31B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[7A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[2C[1Both[7Gr devices[17Gor claude.ai\r[2C[2BScanning local sessions…[39m[K\r[2C[1B[K\r[2C[1B[37mEsc [8Go[10Gca[13Gcel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[21A[30D[21B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r\r\n[3G14%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[31A	B❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   Stats\nSession\n\nTotalcost:$1.55\nTotalduration(API):4m51s\nTotalduration(wall):9m46s\nTotalcodechanges:396linesadded,108linesremoved\nUsagebymodel:\n claude-haiku-4-5:859input,15output,0cacheread,0cachewrite\n($0.0009)\n claude-sonnet-4-6:402input,16.8koutput,2.9mcacheread,118.5k\ncachewrite($1.55)\n\nCurrentsession\n████████████████████                              40%used\nResets8:50pm(UTC)\n\nCurrentweek(allmodels)\n████████████                                      24%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devicesor claude.aiScanning local sessions…Esc ocacelLast 24h· these are independent characteristics of your usage, not a breakdown\n14%ofyourusagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq8a2v9k000w6c5uf7uj274z	cmq6w5d940000525uus1ckhga	24	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	\N	ok	2026-06-10 16:23:30.248	cache[9Gwrite[15G($1.55)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m████████████████████                              [54G[39m[49m40%[58Gused\r\r\n[3G[37mResets[10G8:50pm[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m████████████                                      [54G[39m[49m24%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[31A[30D[31B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[7A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[2C[1Both[7Gr devices[17Gor claude.ai\r[2C[2BScanning local sessions…[39m[K\r[2C[1B[K\r[2C[1B[37mEsc [8Go[10Gca[13Gcel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[21A[30D[21B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r\r\n[3G14%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[31A	B❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   Stats\nSession\n\nTotalcost:$1.55\nTotalduration(API):4m51s\nTotalduration(wall):11m37s\nTotalcodechanges:396linesadded,108linesremoved\nUsagebymodel:\n claude-haiku-4-5:859input,15output,0cacheread,0cachewrite\n($0.0009)\n claude-sonnet-4-6:402input,16.8koutput,2.9mcacheread,118.5k\ncachewrite($1.55)\n\nCurrentsession\n████████████████████                              40%used\nResets8:50pm(UTC)\n\nCurrentweek(allmodels)\n████████████                                      24%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devicesor claude.aiScanning local sessions…Esc ocacelLast 24h· these are independent characteristics of your usage, not a breakdown\n14%ofyourusagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq8b2drl000d0xn2nyyfzkv2	cmq6w5d940000525uus1ckhga	24	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	\N	ok	2026-06-10 16:51:07.185	cache[9Gwrite[15G($1.55)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m████████████████████                              [54G[39m[49m40%[58Gused\r\r\n[3G[37mResets[10G8:50pm[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m████████████                                      [54G[39m[49m24%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[31A[30D[31B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[7A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[2C[1Both[7Gr devices[17Gor claude.ai\r[2C[2BScanning local sessions…[39m[K\r[2C[1B[K\r[2C[1B[37mEsc [8Go[10Gca[13Gcel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[21A[30D[21B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r\r\n[3G14%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[31A	B❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   Stats\nSession\n\nTotalcost:$1.55\nTotalduration(API):4m51s\nTotalduration(wall):39m14s\nTotalcodechanges:396linesadded,108linesremoved\nUsagebymodel:\n claude-haiku-4-5:859input,15output,0cacheread,0cachewrite\n($0.0009)\n claude-sonnet-4-6:402input,16.8koutput,2.9mcacheread,118.5k\ncachewrite($1.55)\n\nCurrentsession\n████████████████████                              40%used\nResets8:50pm(UTC)\n\nCurrentweek(allmodels)\n████████████                                      24%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devicesor claude.aiScanning local sessions…Esc ocacelLast 24h· these are independent characteristics of your usage, not a breakdown\n14%ofyourusagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq8dmkqy00020xnwcsfz21iv	cmq6wcl430001525urn13fvcx	27	15 June, 7:00 pm (Sydney)	2026-06-15 09:00:00	f	ok	2026-06-10 18:02:48.587	(B[<u[>1u[>4;2m[?1000h[?1002h[?1003h[?1006h[?25l[H[3G[100m[97mAPI: GET /api/analytics/weekly (last 12 weeks), GET \r[2C[1B/api[17G/weekly/[weekStar[35G], GET /api/analytics/summary (rolling 30-day\r[1B[49m[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[1B[39m   [94m[1mSettings[22m[39m  Status   Config  [104m[30m[1m Usage [22m[39m[49m  Stats[K\r[1B[K\r[1B   [1mSession[22m[K\r[1B[K\r[1B   [37mTotal cost:            $0.0000[39m[K\r[1B   [37mTotal duration (API):  0s[39m[K\r[1B   [37mTotal duration (wall): 2h 53m 13s[39m[K\r[1B   [37mTotal code changes:    0 lines added, 0 lines removed[39m[K\r[1B   [37mUsage:                 0 input, 0 output, 0 cache read, 0 cache write[39m[K\r[1B[K\r[1B   [1mCurrent session[22m[K\r[1B   [47m[33m██████████████████████████████████████████████████[39m[49m 100% used[K\r[1B   [37mResets 7:10pm (UTC)[39m[K\r[2B [3G [1mCurrent week (all models)\r[3C[1B[22m[47m[33m█████████████▌                                    [39m[49m 27% used[K\r[1B   [37mResets Jun 15, 9am (UTC)[39m[K\r[1B[K\r[1B   [1mWhat's contributing to your limits usage?[22m[K\r[2C[1B [37mApproximate, based on local sessions on this[49Gmachine[57G— doe[63G not include [79G↓[39m[23;1H[4;32H[H\r[3C[21B[37mRefreshing…[39m[K\r[3C[1B                                                                        [23;1H[4;32H[H\r[3C[21B[1mUsage credits\r[3C[1B[22m[37mUsage credits are off · /usage-credits to turn them on[39m[23;1H[4;32H[H\r[78C[22B[K[23;1H[4;32H	BAPI: GET /api/analytics/weekly (last 12 weeks), GET /api/weekly/[weekStar], GET /api/analytics/summary (rolling 30-day▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔   Settings  Status   Config   Usage   Stats   Session   Total cost:            $0.0000   Total duration (API):  0s   Total duration (wall): 2h 53m 13s   Total code changes:    0 lines added, 0 lines removed   Usage:                 0 input, 0 output, 0 cache read, 0 cache write   Current session   ██████████████████████████████████████████████████ 100% used   Resets 7:10pm (UTC)  Current week (all models)█████████████▌                                     27% used   Resets Jun 15, 9am (UTC)   What's contributing to your limits usage? Approximate, based on local sessions on thismachine— doe not include ↓Refreshing…                                                                        Usage creditsUsage credits are off · /usage-credits to turn them on
cmq8dn49600030xnw0p63kbee	cmq6w5d940000525uus1ckhga	24	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	\N	ok	2026-06-10 18:03:13.866	cache[9Gwrite[15G($1.55)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m████████████████████                              [54G[39m[49m40%[58Gused\r\r\n[3G[37mResets[10G8:50pm[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m████████████                                      [54G[39m[49m24%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[31A[30D[31B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[7A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[2C[1Both[7Gr devices[17Gor claude.ai\r[2C[2BScanning local sessions…[39m[K\r[2C[1B[K\r[2C[1B[37mEsc [8Go[10Gca[13Gcel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[21A[30D[21B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r\r\n[3G14%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[31A	B❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   StatsSession\n\nTotalcost:$1.55\nTotalduration(API):4m51s\nTotalduration(wall):1h51m21s\nTotalcodechanges:396linesadded,108linesremoved\nUsagebymodel:\n claude-haiku-4-5:859input,15output,0cacheread,0cachewrite\n($0.0009)\n claude-sonnet-4-6:402input,16.8koutput,2.9mcacheread,118.5k\ncachewrite($1.55)\n\nCurrentsession\n████████████████████                              40%used\nResets8:50pm(UTC)\n\nCurrentweek(allmodels)\n████████████                                      24%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devicesor claude.aiScanning local sessions…Esc ocacelLast 24h· these are independent characteristics of your usage, not a breakdown\n14%ofyourusagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq8dndhz00040xnwjm8352ui	cmq6w5d940000525uus1ckhga	24	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	\N	ok	2026-06-10 18:03:25.847	cache[9Gwrite[15G($1.55)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m████████████████████                              [54G[39m[49m40%[58Gused\r\r\n[3G[37mResets[10G8:50pm[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m████████████                                      [54G[39m[49m24%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[31A[30D[31B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[7A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[2C[1Both[7Gr devices[17Gor claude.ai\r[2C[2BScanning local sessions…[39m[K\r[2C[1B[K\r[2C[1B[37mEsc [8Go[10Gca[13Gcel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[21A[30D[21B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r\r\n[3G14%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[31A	❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   StatsSession\nTotalcost:$1.55\nTotalduration(API):4m51s\nTotalduration(wall):1h51m33s\nTotalcodechanges:396linesadded,108linesremoved\nUsagebymodel:\n claude-haiku-4-5:859input,15output,0cacheread,0cachewrite\n($0.0009)\n claude-sonnet-4-6:402input,16.8koutput,2.9mcacheread,118.5k\ncachewrite($1.55)\n\nCurrentsession\n████████████████████                              40%used\nResets8:50pm(UTC)\n\nCurrentweek(allmodels)\n████████████                                      24%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devicesor claude.aiScanning local sessions…Esc ocacelLast 24h· these are independent characteristics of your usage, not a breakdown\n14%ofyourusagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq8dnrwg00080xnwnhzy0jml	cmq6w5d940000525uus1ckhga	24	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	\N	ok	2026-06-10 18:03:44.512	put,[51G2.9m[56Gcache[62Gread,[68G118.5k[75Gcache[81Gwrite[87G($1.55)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m████████████████████                              [54G[39m[49m40%[58Gused\r\r\n[3G[37mResets[10G8:50pm[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m████████████                                      [54G[39m[49m24%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[75Gother[81Gdevices[89Gor[92Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[28A[30D[28B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[6A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include other devices or claude.ai\r[2C[1B[39m[K\r[2C[1B[37mScanning local sessions…\r[2C[1B[39m[K\r[2C[1B[37mEsc to cancel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[18A[30D[18B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a breakdown\r[2C[2B[39m14% of your usage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[76G/clear[39m\r\r\n[4G[37mwhen[9Gswitching[19Gto[22Gnew[26Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A	B❯ /usage                                                                                                                                                     ─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   Stats\nSession\n\nTotalcost:$1.55\nTotalduration(API):4m51s\nTotalduration(wall):1h51m52s\nTotalcodechanges:396linesadded,108linesremoved\nUsagebymodel:\n claude-haiku-4-5:859input,15output,0cacheread,0cachewrite($0.0009)\n claude-sonnet-4-6:402input,16.8koutput,2.9mcacheread,118.5kcachewrite($1.55)\n\nCurrentsession\n████████████████████                              40%used\nResets8:50pm(UTC)\n\nCurrentweek(allmodels)\n████████████                                      24%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotincludeotherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include other devices or claude.aiScanning local sessions…Esc to cancelLast 24h· these are independent characteristics of your usage, not a breakdown14% of your usagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,/clear\nwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq8dnxl000090xnwp0xtwsdy	cmq6w5d940000525uus1ckhga	24	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	\N	ok	2026-06-10 18:03:51.876	put,[51G2.9m[56Gcache[62Gread,[68G118.5k[75Gcache[81Gwrite[87G($1.55)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m████████████████████                              [54G[39m[49m40%[58Gused\r\r\n[3G[37mResets[10G8:50pm[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m████████████                                      [54G[39m[49m24%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[75Gother[81Gdevices[89Gor[92Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[28A[30D[28B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[6A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include other devices or claude.ai\r[2C[1B[39m[K\r[2C[1B[37mScanning local sessions…\r[2C[1B[39m[K\r[2C[1B[37mEsc to cancel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[18A[30D[18B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a breakdown\r[2C[2B[39m14% of your usage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[76G/clear[39m\r\r\n[4G[37mwhen[9Gswitching[19Gto[22Gnew[26Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A	❯ /usage                                                                                                                                                     ─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   StatsSession\n\nTotalcost:$1.55\nTotalduration(API):4m51s\nTotalduration(wall):1h51m59s\nTotalcodechanges:396linesadded,108linesremoved\nUsagebymodel:\n claude-haiku-4-5:859input,15output,0cacheread,0cachewrite($0.0009)\n claude-sonnet-4-6:402input,16.8koutput,2.9mcacheread,118.5kcachewrite($1.55)\n\nCurrentsession\n████████████████████                              40%used\nResets8:50pm(UTC)\n\nCurrentweek(allmodels)\n████████████                                      24%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotincludeotherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include other devices or claude.aiScanning local sessions…Esc to cancelLast 24h· these are independent characteristics of your usage, not a breakdown14% of your usagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,/clear\nwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq8do4z9000a0xnwgd3kdsgb	cmq6w5d940000525uus1ckhga	24	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	\N	ok	2026-06-10 18:04:01.462	put,[51G2.9m[56Gcache[62Gread,[68G118.5k[75Gcache[81Gwrite[87G($1.55)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m████████████████████                              [54G[39m[49m40%[58Gused\r\r\n[3G[37mResets[10G8:50pm[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m████████████                                      [54G[39m[49m24%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[75Gother[81Gdevices[89Gor[92Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[28A[30D[28B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[6A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include other devices or claude.ai\r[2C[1B[39m[K\r[2C[1B[37mScanning local sessions…\r[2C[1B[39m[K\r[2C[1B[37mEsc to cancel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[18A[30D[18B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a breakdown\r[2C[2B[39m14% of your usage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[76G/clear[39m\r\r\n[4G[37mwhen[9Gswitching[19Gto[22Gnew[26Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A	B❯ /usage                                                                                                                                                     ─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   StatsSession\n\nTotalcost:$1.55\nTotalduration(API):4m51s\nTotalduration(wall):1h52m9s\nTotalcodechanges:396linesadded,108linesremoved\nUsagebymodel:\n claude-haiku-4-5:859input,15output,0cacheread,0cachewrite($0.0009)\n claude-sonnet-4-6:402input,16.8koutput,2.9mcacheread,118.5kcachewrite($1.55)\n\nCurrentsession\n████████████████████                              40%used\nResets8:50pm(UTC)\n\nCurrentweek(allmodels)\n████████████                                      24%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotincludeotherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include other devices or claude.aiScanning local sessions…Esc to cancelLast 24h· these are independent characteristics of your usage, not a breakdown14% of your usagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,/clear\nwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq8dorgx000c0xnwgb62o31k	cmq6w5d940000525uus1ckhga	\N	\N	\N	\N	error	2026-06-10 18:04:30.609	[30D[36B[H[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[2K[1B[H[91m ▐[40m▛███▜[49m▌[12G[39m[1mClaude[19GCode[24G[22m[37mv2.1.169[39m\r\r\n[91m▝▜[40m█████[49m▛▘[12G[37mSonnet[19G4.6[23G·[25GClaude[32GPro[39m\r\r\n[91m [3G▘▘[6G▝▝[12G[37m/home/ec2-user[39m\r\r\n\r\r\n[4G[37mFable[10G5[12Gis[15Gnow[19Gavailable[29Gwith[34Gthe[38Glatest[45Gversion[53Gof[56GClaude[63GCode![69GRun[73G"claude[81Gupdate"[89Gto[92Gupdate[99Gto[102Gv2.1.170+[39m\r\r\n\r\r\n[100m[37m❯ [97m/usage[39m [49m\r\r\n[37m [3G⎿[6G[39mSettings[15Gdialog[22Gdismissed\r\r\n\r\r\n[37m─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────[39m\r\r\n❯ \r\r\n[37m─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[3G[91m⏵⏵[6Gbypass[13Gpermissions[25Gon[37m (shift+tab[39Gto[42Gcycle)[49G·[51G←[53Gfor[57Gagents[39m\r\r\n[56G[37mtmux[61Gfocus-events[74Goff[78G·[80Gadd[84G'set[89G-g[92Gfocus-events[105Gon'[109Gto[112G~/.tmux.conf[125Gand[129Greattach[138Gfor[142Gfocus[148Gtracking[39m\r\r\n[2C[4A[?25h[?25l[2D[4B\r[55C[1A                               [91m✘ Auto-update failed: no write permission to npm prefix · Run [1m/doctor[22m[39m\r\r\n[56G[37mtmux[61Gfocus-events[74Goff[78G·[80Gadd[84G'set[89G-g[92Gfocus-events[105Gon'[109Gto[112G~/.tmux.conf[125Gand[129Greattach[138Gfor[142Gfocus[148Gtracking[39m\r\r\n[2C[5A[?25h	▐▛███▜▌ClaudeCodev2.1.169\n▝▜█████▛▘Sonnet4.6·ClaudePro\n ▘▘▝▝/home/ec2-user\n\nFable5isnowavailablewiththelatestversionofClaudeCode!Run"claudeupdate"toupdatetov2.1.170+\n\n❯ /usage\n ⎿Settingsdialogdismissed\n\n─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────\n❯ \n─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·←foragents\ntmuxfocus-eventsoff·add'set-gfocus-eventson'to~/.tmux.confandreattachforfocustracking\n                               ✘ Auto-update failed: no write permission to npm prefix · Run /doctor\ntmuxfocus-eventsoff·add'set-gfocus-eventson'to~/.tmux.confandreattachforfocustracking
cmq8du887000l0xnwe719fpkr	cmq6w5d940000525uus1ckhga	28	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	\N	ok	2026-06-10 18:08:45.607	G0[50Gcache[56Gread,[62G0[64Gcache[70Gwrite[39m\r\r\n[3G[37m($0.0009)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[37m❯ [39m\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[3G[91m⏵⏵[6Gbypass[13Gpermissions[25Gon[37m (shift+tab[39Gto[42Gcycle)[49G·[51Gesc[55Gto[58Ginterrupt[39m\r\r\n[10G[91m✘[12GAuto-update[24Gfailed:[32Gno[35Gwrite[41Gpermission[52Gto[55Gnpm[59Gprefix[66G·[68GRun[72G[1m/doctor[22m[39m\r\r\n[30C[25A[30D[25B\r[2C[9A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r[2C[1B14%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r[1B   [37mLonger sessions are more expensive even when cached. /compact mid-task, [39m[K\r[1B  [4G[37m/clear when switching to new tasks.\r[1B[39m[K\r[2C[1B[1mSkills, subagents, plugins, and MCP servers[22m[K\r[2C[1B[37mNo attribution data yet · accumulates as you use Claude[39m[K\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[37m❯ [39m\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[3G[91m⏵⏵[6Gbypass[13Gpermissions[25Gon[37m (shift+tab[39Gto[42Gcycle)[49G·[51Gesc[55Gto[58Ginterrupt[39m\r\r\n[10G[91m✘[12GAuto-update[24Gfailed:[32Gno[35Gwrite[41Gpermission[52Gto[55Gnpm[59Gprefix[66G·[68GRun[72G[1m/doctor[22m[39m\r\r\n[30C[35A	ved\nUsagebymodel:\n claude-haiku-4-5:838input,16output,0cacheread,0cachewrite\n($0.0009)\n\nCurrentsession\n████████████████████████████████████████▌         81%used\nResets8:50pm(UTC)\n\nCurrentweek(allmodels)\n██████████████                                    28%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·esctointerrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor\n\nTotalcost:$0.0009\nTotalduration(API):1s\nTotalduration(wall):4m20s\nTotalcodechanges:0linesadded,0linesremoved\nUsagebymodel:\n claude-haiku-4-5:838input,16output,0cacheread,0cachewrite\n($0.0009)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nEsctocancel\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·esctointerrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor\nLast 24h· these are independent characteristics of your usage, not a breakdown14%ofyourusagewasat>150kcontext   Longer sessions are more expensive even when cached. /compact mid-task,   /clear when switching to new tasks.Skills, subagents, plugins, and MCP serversNo attribution data yet · accumulates as you use Claude\n\ndtoday·wtoweek\n\nEsctocancel\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·esctointerrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor
cmq8dyph1000u0xnwgbmrea85	cmq6w5d940000525uus1ckhga	28	11 June, 9:00 am (Sydney)	2026-06-10 23:00:00	\N	ok	2026-06-10 18:12:14.581	[56Gcache[62Gread,[68G37.0k[74Gcache[39m\r\r\n[3G[37mwrite[9G($0.4410)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[37m❯ [39m\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[3G[91m⏵⏵[6Gbypass[13Gpermissions[25Gon[37m (shift+tab[39Gto[42Gcycle)[49G·[51Gesc[55Gto[58Ginterrupt[39m\r\r\n[10G[91m✘[12GAuto-update[24Gfailed:[32Gno[35Gwrite[41Gpermission[52Gto[55Gnpm[59Gprefix[66G·[68GRun[72G[1m/doctor[22m[39m\r\r\n[30C[27A[30D[27B\r[2C[9A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r[2C[1B14%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r[1B   [37mLonger sessions are more expensive even when cached. /compact mid-task, [39m[K\r[1B  [4G[37m/clear when switching to new tasks.\r[1B[39m[K\r[2C[1B[1mSkills, subagents, plugins, and MCP servers[22m[K\r[2C[1B[37mNo attribution data yet · accumulates as you use Claude[39m[K\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[37m❯ [39m\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[3G[91m⏵⏵[6Gbypass[13Gpermissions[25Gon[37m (shift+tab[39Gto[42Gcycle)[49G·[51Gesc[55Gto[58Ginterrupt[39m\r\r\n[10G[91m✘[12GAuto-update[24Gfailed:[32Gno[35Gwrite[41Gpermission[52Gto[55Gnpm[59Gprefix[66G·[68GRun[72G[1m/doctor[22m[39m\r\r\n[30C[37A	0kcache\nwrite($0.4410)\n\nCurrentsession\n█████████████████████████████████████████▌        83%used\nResets8:50pm(UTC)\n\nCurrentweek(allmodels)\n██████████████                                    28%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·esctointerrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor\nTotalduration(API):1m33s\nTotalduration(wall):1m48s\nTotalcodechanges:0linesadded,0linesremoved\nUsagebymodel:\n claude-haiku-4-5:900input,14output,0cacheread,0cachewrite\n($0.0010)\n claude-sonnet-4-6:28input,4.4koutput,789.2kcacheread,37.0kcache\nwrite($0.4410)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nEsctocancel\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·esctointerrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor\nLast 24h· these are independent characteristics of your usage, not a breakdown14%ofyourusagewasat>150kcontext   Longer sessions are more expensive even when cached. /compact mid-task,   /clear when switching to new tasks.Skills, subagents, plugins, and MCP serversNo attribution data yet · accumulates as you use Claude\n\ndtoday·wtoweek\n\nEsctocancel\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·esctointerrupt\n✘Auto-updatefailed:nowritepermissiontonpmprefix·Run/doctor
cmq8ubae100940xnwolxt5qaa	cmq6w5d940000525uus1ckhga	30	11 June, 9:00 am (Sydney)	2027-06-10 23:00:00	\N	ok	2026-06-11 01:49:55.417	ut,[51G10.6m[57Gcache[63Gread,[69G369.2k[76Gcache[82Gwrite[88G($5.23)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m██████                                            [54G[39m[49m12%[58Gused\r\r\n[3G[37mResets[10G1:50am[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m███████████████                                   [54G[39m[49m30%[58Gused\r\r\n[3G[37mResets[10GJun[14G10,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[75Gother[81Gdevices[89Gor[92Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[28A[30D[28B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[6A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include other devices or claude.ai\r[2C[1B[39m[K\r[2C[1B[37mScanning local sessions…\r[2C[1B[39m[K\r[2C[1B[37mEsc to cancel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[18A[30D[18B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a breakdown\r[2C[2B[39m11% of your usage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[76G/clear[39m\r\r\n[4G[37mwhen[9Gswitching[19Gto[22Gnew[26Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A	B❯ /usage                                                                                                                                                     ─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────  Settings  Status   Config   Usage   Stats  SessionTotal cost:            $5.23\nTotalduration(API):12m35s\nTotalduration(wall):7h39m29s\nTotalcodechanges:1883linesadded,5linesremoved\nUsagebymodel:\n claude-haiku-4-5:900input,14output,0cacheread,0cachewrite($0.0010)\n claude-sonnet-4-6:829input,44.3koutput,10.6mcacheread,369.2kcachewrite($5.23)\n\nCurrentsession\n██████                                            12%used\nResets1:50am(UTC)\n\nCurrentweek(allmodels)\n███████████████                                   30%used\nResetsJun10,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotincludeotherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include other devices or claude.aiScanning local sessions…Esc to cancelLast 24h· these are independent characteristics of your usage, not a breakdown11% of your usagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,/clear\nwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq8ubis000950xnwakcdftge	cmq6wcl430001525urn13fvcx	30	15 June, 7:00 pm (Sydney)	2026-06-15 09:00:00	\N	ok	2026-06-11 01:50:06.289	(B[<u[>1u[>4;2m[?1000h[?1002h[?1003h[?1006h[?25l[H[5GAsync scan callbacks with idempotent[42Gstatus [50Guards to[59Gprevent ra[70Ges; p[76Gller\r[2C[1Balso acts as backup r[25Gcovery for scanning state[51G[K\r[1B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[2C[1B[39m [94m[1mSettings[22m[39m  Status   Co[26Gfig  [104m[30m[1m Usage [22m[39m[49m  Stats[K\r[2C[2B [1mSession[22m[K\r[2C[1B[K\r[3C[1B[37mTotal cost:            $6.24\r[2C[1B[39m [37mTotal duration (API):  24m 21s[39m[K\r[2C[1B [37mTotal duration (wall): 10h 40m 30s[39m[K\r[3C[1B[37mTotal code changes:    2642 lines added, 259 lines removed\r[2C[1B[39m [37mUsage by model:[20G[39m[K\r[2C[1B [37m    claude-haiku-4-5:  872 input, 15 output, 0 cache read, 0 cache write \r[3C[1B($0.0009)\r[1B[39m [3G [37m   [8Glaude-sonnet-4-6:  1.2k input, 92.4k output, 13.5m cache read, 213.7k \r[3C[1Bcache write ($6.24)\r[1B[39m[K\r[2C[1B [1mCurrent session[22m[K\r[3C[1B[47m[33m███████████████▌                                  [39m[49m 31% used[K\r[1B   [37mResets 12:10am (UTC)[39m[K\r[1B[K\r[1B   [1mCurrent week (all models)[22m[K\r[2C[1B [47m[33m███████████████                                   [39m[49m 30% used[79G[37m↓[39m[23;1H[4;32H[H\r[3C[18B[47m[33m                [55G[39m[49m0% used[K\r[3C[1B[K\r[3C[1B[1mCurrent week (all models)\r[3C[1B[22m[47m[33m███████████████▌                                  [55G[39m[49m31%[59Gused\r[3C[1B[37mResets Jun 15, 9am (UTC)[39m                          [55G   [59G    [23;1H[4;32H	BAsync scan callbacks with idempotentstatus uards toprevent raes; plleralso acts as backup rcovery for scanning state▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔ Settings  Status   Cofig   Usage   Stats SessionTotal cost:            $6.24 Total duration (API):  24m 21s Total duration (wall): 10h 40m 30sTotal code changes:    2642 lines added, 259 lines removed Usage by model:     claude-haiku-4-5:  872 input, 15 output, 0 cache read, 0 cache write ($0.0009)     laude-sonnet-4-6:  1.2k input, 92.4k output, 13.5m cache read, 213.7k cache write ($6.24) Current session███████████████▌                                   31% used   Resets 12:10am (UTC)   Current week (all models) ███████████████                                    30% used↓                0% usedCurrent week (all models)███████████████▌                                  31%usedResets Jun 15, 9am (UTC)
cmq8ubq3100960xnwn1clpa08	cmq6wcl430001525urn13fvcx	30	\N	\N	\N	ok	2026-06-11 01:50:15.757	(B[<u[>1u[>4;2m[?1000h[?1002h[?1003h[?1006h[?25l[H[5GAsync scan callbacks with idempotent[42Gstatus [50Guards to[59Gprevent ra[70Ges; p[76Gller\r[2C[1Balso acts as backup r[25Gcovery for scanning state[51G[K\r[1B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[2C[1B[39m [94m[1mSettings[22m[39m  Status   Co[26Gfig  [104m[30m[1m Usage [22m[39m[49m  Stats[K\r[2C[2B [1mSession[22m[K\r[2C[1B[K\r[3C[1B[37mTotal cost:            $6.24\r[2C[1B[39m [37mTotal duration (API):  24m 21s[39m[K\r[2C[1B [37mTotal duration (wall): 10h 40m 40s[39m[K\r[3C[1B[37mTotal code changes:    2642 lines added, 259 lines removed\r[2C[1B[39m [37mUsage by model:[20G[39m[K\r[2C[1B [37m    claude-haiku-4-5:  872 input, 15 output, 0 cache read, 0 cache write \r[3C[1B($0.0009)\r[1B[39m [3G [37m   [8Glaude-sonnet-4-6:  1.2k input, 92.4k output, 13.5m cache read, 213.7k \r[3C[1Bcache write ($6.24)\r[1B[39m[K\r[2C[1B [1mCurrent session[22m[K\r[3C[1B[47m[33m███████████████▌                                  [55G[39m[49m31%[59Gused[64G[K\r[1B   [37mResets 12:10am (UTC)[39m[K\r[1B[K\r[1B   [1mCurrent week (all models)[22m[K\r[2C[1B [47m[33m███████████████                                   [39m[49m 30% used[79G[37m↓[39m[23;1H[4;32H[H\r[3C[17B[1mWhat's contr[17Gbuting to your limits usage?\r[3C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[3C[1Both[8Gr devices or claude.ai\r[3C[2BScanning local sessions…[39m[K\r[3C[1B                                                  [55G   [59G    [23;1H[4;32H[H\r[78C[22B[K[23;1H[4;32H[H\r[3C[21B[37mLast 24h[13G· these are independent characteristics of your usage, not a \r[3C[1Bbreakdown[39m[23;1H[4;32H[H\r[78C[22B[37m↓[39m[23;1H[4;32H	BAsync scan callbacks with idempotentstatus uards toprevent raes; plleralso acts as backup rcovery for scanning state▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔ Settings  Status   Cofig   Usage   Stats SessionTotal cost:            $6.24 Total duration (API):  24m 21s Total duration (wall): 10h 40m 40sTotal code changes:    2642 lines added, 259 lines removed Usage by model:     claude-haiku-4-5:  872 input, 15 output, 0 cache read, 0 cache write ($0.0009)     laude-sonnet-4-6:  1.2k input, 92.4k output, 13.5m cache read, 213.7k cache write ($6.24) Current session███████████████▌                                  31%used   Resets 12:10am (UTC)   Current week (all models) ███████████████                                    30% used↓What's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devices or claude.aiScanning local sessions…                                                         Last 24h· these are independent characteristics of your usage, not a breakdown↓
cmq8uc0at00970xnwmvwed7kn	cmq6wcl430001525urn13fvcx	30	\N	\N	\N	ok	2026-06-11 01:50:28.998	[?25l[H[5GAsync scan callbacks with idempotent[42Gstatus [50Guards to[59Gprevent ra[70Ges; p[76Gller\r[2C[1Balso acts as backup r[25Gcovery for scanning state[51G[K\r[1B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[2C[1B[39m [94m[1mSettings[22m[39m  Status   Co[26Gfig  [104m[30m[1m Usage [22m[39m[49m  Stats[K\r[2C[2B [1mSession[22m[K\r[2C[1B[K\r[3C[1B[37mTotal cost:            $6.24\r[2C[1B[39m [37mTotal duration (API):  24m 21s[39m[K\r[2C[1B [37mTotal duration (wall): 10h 40m 53s[39m[K\r[3C[1B[37mTotal code changes:    2642 lines added, 259 lines removed\r[2C[1B[39m [37mUsage by model:[20G[39m[K\r[2C[1B [37m    claude-haiku-4-5:  872 input, 15 output, 0 cache read, 0 cache write \r[3C[1B($0.0009)\r[1B[39m [3G [37m   [8Glaude-sonnet-4-6:  1.2k input, 92.4k output, 13.5m cache read, 213.7k \r[3C[1Bcache write ($6.24)\r[1B[39m[K\r[2C[1B [1mCurrent session[22m[K\r[3C[1B[47m[33m███████████████▌                                  [55G[39m[49m31%[59Gused[64G[K\r[1B   [37mResets 12:10am (UTC)[39m[K\r[1B[K\r[1B   [1mCurrent week (all models)[22m[K\r[2C[1B [47m[33m███████████████                                   [39m[49m 30% used[79G[37m↓[39m[23;1H[4;32H[H\r[3C[17B[1mWhat's contr[17Gbuting to your limits usage?\r[3C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[3C[1Both[8Gr devices or claude.ai\r[3C[2BScanning local sessions…[39m[K\r[3C[1B                                                  [55G   [59G    [23;1H[4;32H[H\r[78C[22B[K[23;1H[4;32H[H\r[3C[21B[37mLast 24h[13G· these are independent characteristics of your usage, not a \r[3C[1Bbreakdown[39m[23;1H[4;32H[H\r[78C[22B[37m↓[39m[23;1H[4;32H	Async scan callbacks with idempotentstatus uards toprevent raes; plleralso acts as backup rcovery for scanning state▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔ Settings  Status   Cofig   Usage   Stats SessionTotal cost:            $6.24 Total duration (API):  24m 21s Total duration (wall): 10h 40m 53sTotal code changes:    2642 lines added, 259 lines removed Usage by model:     claude-haiku-4-5:  872 input, 15 output, 0 cache read, 0 cache write ($0.0009)     laude-sonnet-4-6:  1.2k input, 92.4k output, 13.5m cache read, 213.7k cache write ($6.24) Current session███████████████▌                                  31%used   Resets 12:10am (UTC)   Current week (all models) ███████████████                                    30% used↓What's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devices or claude.aiScanning local sessions…                                                         Last 24h· these are independent characteristics of your usage, not a breakdown↓
cmq8ujjbk009b0xnwvzm0ugqs	cmq6wcl430001525urn13fvcx	30	15 June, 7:00 pm (Sydney)	2026-06-15 09:00:00	\N	ok	2026-06-11 01:56:20.241	(B[<u[>1u[>4;2m[?1000h[?1002h[?1003h[?1006h[?25l[H[5GAsync scan callbacks with idempotent[42Gstatus [50Guards to[59Gprevent ra[70Ges; p[76Gller\r[2C[1Balso acts as backup r[25Gcovery for scanning state[51G[K\r[1B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[2C[1B[39m [94m[1mSettings[22m[39m  Status   Co[26Gfig  [104m[30m[1m Usage [22m[39m[49m  Stats[K\r[2C[2B [1mSession[22m[K\r[2C[1B[K\r[3C[1B[37mTotal cost:            $6.24\r[2C[1B[39m [37mTotal duration (API):  24m 21s[39m[K\r[2C[1B [37mTotal duration (wall): 10h 46m 44s[39m[K\r[3C[1B[37mTotal code changes:    2642 lines added, 259 lines removed\r[2C[1B[39m [37mUsage by model:[20G[39m[K\r[2C[1B [37m    claude-haiku-4-5:  872 input, 15 output, 0 cache read, 0 cache write \r[3C[1B($0.0009)\r[1B[39m [3G [37m   [8Glaude-sonnet-4-6:  1.2k input, 92.4k output, 13.5m cache read, 213.7k \r[3C[1Bcache write ($6.24)\r[1B[39m[K\r[2C[1B [1mCurrent session[22m[K\r[3C[1B[47m[33m███████████████▌                                  [39m[49m 31% used[K\r[1B   [37mResets 12:10am (UTC)[39m[K\r[1B[K\r[1B   [1mCurrent week (all models)[22m[K\r[2C[1B [47m[33m███████████████                                   [39m[49m 30% used[79G[37m↓[39m[23;1H[4;32H[H\r[3C[18B[47m[33m                [55G[39m[49m0% used[K\r[3C[1B[K\r[3C[1B[1mCurrent week (all models)\r[3C[1B[22m[47m[33m███████████████▌                                  [55G[39m[49m31%[59Gused\r[3C[1B[37mResets Jun 15, 9am (UTC)[39m                          [55G   [59G    [23;1H[4;32H	BAsync scan callbacks with idempotentstatus uards toprevent raes; plleralso acts as backup rcovery for scanning state▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔ Settings  Status   Cofig   Usage   Stats SessionTotal cost:            $6.24 Total duration (API):  24m 21s Total duration (wall): 10h 46m 44sTotal code changes:    2642 lines added, 259 lines removed Usage by model:     claude-haiku-4-5:  872 input, 15 output, 0 cache read, 0 cache write ($0.0009)     laude-sonnet-4-6:  1.2k input, 92.4k output, 13.5m cache read, 213.7k cache write ($6.24) Current session███████████████▌                                   31% used   Resets 12:10am (UTC)   Current week (all models) ███████████████                                    30% used↓                0% usedCurrent week (all models)███████████████▌                                  31%usedResets Jun 15, 9am (UTC)
cmq8y64e200320xmsljtk9t3g	cmq6w5d940000525uus1ckhga	\N	\N	\N	\N	rate_limited	2026-06-11 03:37:52.826	d for 7m 1s\n\n● How is Claude doing this session? (optional)\n  1: Bad    2: Fine   3: Good   0: Dismiss\n\n────────────────────────────────────────────────────────────────────────────────\n❯ commit this\n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents\n         ✘ Auto-update failed: no write permission to npm prefix · Run /doctor\n                        control this session from your phone · /remote-control	\N
cmq8zqupr004t0xmskdu9uayd	cmq6w5d940000525uus1ckhga	5	18 June, 9:00 am (Sydney)	2026-06-17 23:00:00	f	ok	2026-06-11 04:21:59.679	[9Gduration[18G(API):[26G0s[39m\r\r\n[3G[37mTotal[9Gduration[18G(wall):[26G4s[39m\r\r\n[3G[37mTotal[9Gcode[14Gchanges:[26G0[28Glines[34Gadded,[41G0[43Glines[49Gremoved[39m\r\r\n[3G[37mUsage:[26G0[28Ginput,[35G0[37Goutput,[45G0[47Gcache[53Gread,[59G0[61Gcache[67Gwrite[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m███████████████████████████▌                      [54G[39m[49m55%[58Gused\r\r\n[3G[37mResets[10G6:50am[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m██▌                                               [54G[39m[49m5%[57Gused\r\r\n[3G[37mResets[10GJun[14G17,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A[30D[27B\r[2C[5A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r[2C[1B12%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r[2C[1B [37mLonger sessions are more expensive even when cached. /compact mid-task, [39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[37A[30D[37B\r[4C[22A[47m[33m█[54G[39m[49m6\r[2C[19B[1mUsage credits\r[2C[1B[22m[37mUsage credits are off · /usage-credits to turn them on\r[2C[1B[39m[K\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[38A	❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   StatsSession\n\nTotalcost:$0.0000\nTotalduration(API):0s\nTotalduration(wall):4s\nTotalcodechanges:0linesadded,0linesremoved\nUsage:0input,0output,0cacheread,0cachewrite\n\nCurrentsession\n███████████████████████████▌                      55%used\nResets6:50am(UTC)\n\nCurrentweek(allmodels)\n██▌                                               5%used\nResetsJun17,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nLast 24h· these are independent characteristics of your usage, not a breakdown12%ofyourusagewasat>150kcontext Longer sessions are more expensive even when cached. /compact mid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nRefreshing…\n\nEsctocancel\n█6Usage creditsUsage credits are off · /usage-credits to turn them on\nEsctocancel
cmq8y6kj900330xmsysb7ecdp	cmq6wcl430001525urn13fvcx	33	\N	\N	\N	ok	2026-06-11 03:38:13.749	(B[<u[>1u[>4;2m[?1000h[?1002h[?1003h[?1006h[?25l[H[3Gpage[K\r[2C[1B-[5GShows[11G[1mPrerequisites[25G[22m(what[31Gthis[36Gtask[41Gwaits[47Gfor)[52Gwith[57Gremove[64Gbuttons\r[1B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[2C[1B[39m [94m[1mSettings[22m[39m  Status   Config  [104m[30m[1m Usage [22m[39m[49m [40GStats[K\r[2C[1B[K\r[2C[1B [1mSession[22m[K\r[2C[1B[K\r[3C[1B[37mTotal cost:            $13.11\r[2C[1B[39m [37mTotal duration (API):  49m 27s\r[2C[1B[39m [37mTotal duration (wall): 12h 28m 38s\r[2C[1B[39m [37mTotal code changes:    4074 lines added, 396 lines removed\r[2C[1B[39m [37mUsage by model:[39m[K\r[2C[1B [37m    claude-haiku-4-5:  986 input, 6.9k output, 1.4m cache read, 55.0k \r[3C[1Bcache write ($0.2453)\r[1B[39m [3G [37m   claude-sonnet-4-6:  3.4k input, 175.6k output, 28.3m cache read, 461.2k\r[3C[1Bcache write ($12.87)\r[1B[39m[K\r[2C[1B [1mCurrent session[22m[K\r[3C[1B[47m[33m███████████████▌                                  [39m[49m 31% used[K\r[1B   [37mResets 6:50am (UTC)[39m[K\r[1B[K\r[1B   [1mCurrent week (all models)[22m[K\r[2C[1B [47m[33m████████████████▌                                 [39m[49m 33% used[79G[37m↓[39m[23;1H[4;32H[H\r[19C[22B[47m[33m█[56G[39m[49m4[23;1H[4;32H	Bpage-ShowsPrerequisites(whatthistaskwaitsfor)withremovebuttons▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔ Settings  Status   Config   Usage  Stats SessionTotal cost:            $13.11 Total duration (API):  49m 27s Total duration (wall): 12h 28m 38s Total code changes:    4074 lines added, 396 lines removed Usage by model:     claude-haiku-4-5:  986 input, 6.9k output, 1.4m cache read, 55.0k cache write ($0.2453)     claude-sonnet-4-6:  3.4k input, 175.6k output, 28.3m cache read, 461.2kcache write ($12.87) Current session███████████████▌                                   31% used   Resets 6:50am (UTC)   Current week (all models) ████████████████▌                                  33% used↓█4
cmq8z8cr900420xms333ufl5t	cmq6wcl430001525urn13fvcx	35	\N	\N	\N	ok	2026-06-11 04:07:36.597	(B[<u[>1u[>4;2m[?1000h[?1002h[?1003h[?1006h[?25l[H[K\r[1B[37m  ⎿  Referenced file [1mCLAUDE.md\r[1B[22m[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[2C[1B[39m [94m[1mSettings[22m[39m  Status   Config  [104m[30m[1m Usage [22m[39m[49m  Stats[K\r[2B [3G [1mSession[22m[K\r[2C[2B [37mTotal cost:            $16.11[39m[K\r[2C[1B [37mTotal duration (API):  1h 1m 30s[39m[K\r[2C[1B [37mTotal duration (wall): 12h 58m 1s[39m[K\r[2C[1B [37mTotal code changes:    4971 lines added, 620 lines removed[39m[K\r[2C[1B [37mUsage by model:[39m[K\r[2C[1B [37m    claude-haiku-4-5:  986 input, 6.9k output, 1.4m cache read, 55.0k [39m[K\r[3C[1B[37mcache write ($0.2453)\r[1B[39m [3G [37m   [8Glaude-sonnet-4-6:  4.5k input, 220.0k output, 35.0m cache read, 548.3k\r[3C[1Bcache write ($15.86)\r[1B[39m[K\r[2C[1B [1mCurrent session[22m[K\r[3C[1B[47m[33m██████████████████████▌                           [55G[39m[49m45%[59Gused[64G[K\r[1B   [37mResets 6:50am (UTC)[39m[K\r[1B[K\r[1B   [1mCurrent week (all models)[22m[K\r[2C[1B [47m[33m█████████████████▌                                [39m[49m 35% used[79G[37m↓[39m[23;1H[4;32H[H\r[25C[18B[47m[33m█[56G[39m[49m6[23;1H[4;32H	B  ⎿  Referenced file CLAUDE.md▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔ Settings  Status   Config   Usage   Stats  Session Total cost:            $16.11 Total duration (API):  1h 1m 30s Total duration (wall): 12h 58m 1s Total code changes:    4971 lines added, 620 lines removed Usage by model:     claude-haiku-4-5:  986 input, 6.9k output, 1.4m cache read, 55.0k cache write ($0.2453)     laude-sonnet-4-6:  4.5k input, 220.0k output, 35.0m cache read, 548.3kcache write ($15.86) Current session██████████████████████▌                           45%used   Resets 6:50am (UTC)   Current week (all models) █████████████████▌                                 35% used↓█6
cmq8zpmh1004o0xmsabfp2tti	cmq6wcl430001525urn13fvcx	35	\N	\N	\N	ok	2026-06-11 04:21:02.341	(B[<u[>1u[>4;2m[?1000h[?1002h[?1003h[?1006h[?25l[H[K\r[1B[37m  ⎿  Referenced file [1mCLAUDE.md\r[1B[22m[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[2C[1B[39m [94m[1mSettings[22m[39m  Status   Config  [104m[30m[1m Usage [22m[39m[49m  Stats[K\r[2B [3G [1mSession[22m[K\r[2C[2B [37mTotal cost:            $16.11[39m[K\r[2C[1B [37mTotal duration (API):  1h 1m 30s[39m[K\r[2C[1B [37mTotal duration (wall): 13h 11m 26s[39G[39m[K\r[2C[1B [37mTotal code changes:    4971 lines added, 620 lines removed[39m[K\r[2C[1B [37mUsage by model:[39m[K\r[2C[1B [37m    claude-haiku-4-5:  986 input, 6.9k output, 1.4m cache read, 55.0k [39m[K\r[3C[1B[37mcache write ($0.2453)\r[1B[39m [3G [37m   [8Glaude-sonnet-4-6:  4.5k input, 220.0k output, 35.0m cache read, 548.3k\r[3C[1Bcache write ($15.86)\r[1B[39m[K\r[2C[1B [1mCurrent session[22m[K\r[3C[1B[47m[33m██████████████████████▌                           [39m[49m 45% used[K\r[1B   [37mResets 6:50am (UTC)[39m[K\r[1B[K\r[1B   [1mCurrent week (all models)[22m[K\r[2C[1B [47m[33m█████████████████▌                                [39m[49m 35% used[79G[37m↓[39m[23;1H[4;32H[H\r[25C[18B[47m[33m█[56G[39m[49m6\r[12C[1B[37m49[39m[23;1H[4;32H	B  ⎿  Referenced file CLAUDE.md▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔ Settings  Status   Config   Usage   Stats  Session Total cost:            $16.11 Total duration (API):  1h 1m 30s Total duration (wall): 13h 11m 26s Total code changes:    4971 lines added, 620 lines removed Usage by model:     claude-haiku-4-5:  986 input, 6.9k output, 1.4m cache read, 55.0k cache write ($0.2453)     laude-sonnet-4-6:  4.5k input, 220.0k output, 35.0m cache read, 548.3kcache write ($15.86) Current session██████████████████████▌                            45% used   Resets 6:50am (UTC)   Current week (all models) █████████████████▌                                 35% used↓█649
cmq8zqpm5004s0xmsx7ntj7se	cmq6w5d940000525uus1ckhga	\N	\N	\N	\N	error	2026-06-11 04:21:53.069	/usage\r\n[?2004l\r-bash: /usage: No such file or directory\r\n[?2004h[ec2-user@ip-172-31-23-229 ~]$ ^C[?2004l\r[?2004h[?2004l\r\r\n[?2004h[ec2-user@ip-172-31-23-229 ~]$ HOME=/home/ec2-user/claude-agents/agent-1 claude --dangerously-skip-permissions\r\n[?2004l\r7[r8[?25h[?25l[?2004h[?1004h[?2031h[<u[>1u[>4;2m[>0q[c[?2026$p[c]0;✳ Claude Code[91m ▐[40m▛███▜[49m▌[12G[39m[1mClaude[19GCode[24G[22m[37mv2.1.169[39m\r\r\n[91m▝▜[40m█████[49m▛▘[12G[37mSonnet[19G4.6[23G·[25GClaude[32GPro[39m\r\r\n[91m [3G▘▘[6G▝▝[12G[37m/home/ec2-user[39m\r\r\n\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n❯ [2mTry[7G"create[15Ga[17Gutil[22Glogging.py[33Gthat..."[22m\r\r\n[37m────────────────────────────────────────────────────────────────────────────────[39m\r\r\n[3G[91m⏵⏵[6Gbypass[13Gpermissions[25Gon[37m (shift+tab[39Gto[42Gcycle)[49G·[51G←[53Gfor[57Gagents[39m\r\r\n[63G[37m●[65Ghigh[70G·[72G/effort[39m\r\r\n[2C[4A[?25h	/usage\n-bash: /usage: No such file or directory\n[ec2-user@ip-172-31-23-229 ~]$ ^C\n[ec2-user@ip-172-31-23-229 ~]$ HOME=/home/ec2-user/claude-agents/agent-1 claude --dangerously-skip-permissions\n[?2026$p ▐▛███▜▌ClaudeCodev2.1.169\n▝▜█████▛▘Sonnet4.6·ClaudePro\n ▘▘▝▝/home/ec2-user\n\n────────────────────────────────────────────────────────────────────────────────\n❯ Try"createautillogging.pythat..."\n────────────────────────────────────────────────────────────────────────────────\n⏵⏵bypasspermissionson (shift+tabtocycle)·←foragents\n●high·/effort
cmq90ri20005x0xmsu7uz5po9	cmq6w5d940000525uus1ckhga	\N	\N	\N	\N	error	2026-06-11 04:50:29.544	\N	\N
cmq9127w00006czmsbmjue7n7	cmq6wcl430001525urn13fvcx	37	\N	\N	\N	ok	2026-06-11 04:58:49.584	(B[<u[>1u[>4;2m[?1000h[?1002h[?1003h[?1006h]0;✳ Implement AI task review queue system[?25l[H[3G[94mnextImprovementCycleAt[26G[39mto[29Gthe[33Gnear[38Gpast[43G—[45Gthe[49Gpoller[56Gwill[61Gpick[66Git[69Gup[72Gwithin\r[1B [3Gthe[7Gn[9Gxt 60 second[22G. Let me check the DB migration[54Gran:[K\r[1B[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[3C[1B[1mSettings[14G[22m[39mStatus[23GConfig[31G[104m[30m[1m Usage [40G[22m[39m[49mStats\r[1B[K\r[1B   [1mSession[22m[K\r[5C[1B[K\r[3C[1B[37mTotal cost:            $24.59\r[3C[1BTotal duration (API):  1h 26m 55s\r[3C[1BTotal duration[19G(wall):[27G13h 49m 14s[39m[K\r[3C[1B[37mTotal code change[22G: [25G  6229 lines added, 784 lines removed\r[3C[1BUsage by model:\r[1B[39m [3G [37m    claude-haiku-4-5:  986[31Ginput, 6.9k output, 1.4m cache read, 55.0k \r[1B[39m   [37mcache write ($0.2453)[39m[K\r[3C[1B[37m   claude-s[16Gnnet-4-6:  5.8k input, 306.7k output, 56.5m cache read, 740.4k\r[3C[1Bcache write ($24.35)\r[1B[39m[K\r[2C[1B [1mCurrent session[22m[K\r[3C[1B[47m[33m█████████████████████████████████████             [39m[49m 74% used[K\r[1B   [37mResets 6:50am (UTC)[39m[K\r[1B[K\r[1B   [1mCurrent week (all models)[22m[K\r[2C[1B [47m[33m██████████████████▌                               [39m[49m 37% used    [79G[37m↓[39m[23;1H[4;32H[H\r[3C[17B[1mWhat's contr[17Gbuting to your limits usage?\r[3C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[3C[1Both[8Gr devices[18Gor claude.ai\r[3C[2BScanning local sessions…[39m[K\r[3C[1B                                                  [55G   [59G    [23;1H[4;32H[H\r[78C[22B[K[23;1H[4;32H[H\r[3C[21B[37mLast 24h[13G· these are independent characteristics of your usage, not a \r[3C[1Bbreakdown[39m[23;1H[4;32H[H\r[78C[22B[37m↓[39m[23;1H[4;32H	BnextImprovementCycleAttothenearpast—thepollerwillpickitupwithin thenxt 60 second. Let me check the DB migrationran:▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔SettingsStatusConfig Usage Stats   SessionTotal cost:            $24.59Total duration (API):  1h 26m 55sTotal duration(wall):13h 49m 14sTotal code change:   6229 lines added, 784 lines removedUsage by model:      claude-haiku-4-5:  986input, 6.9k output, 1.4m cache read, 55.0k    cache write ($0.2453)   claude-snnet-4-6:  5.8k input, 306.7k output, 56.5m cache read, 740.4kcache write ($24.35) Current session█████████████████████████████████████              74% used   Resets 6:50am (UTC)   Current week (all models) ██████████████████▌                                37% used    ↓What's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devicesor claude.aiScanning local sessions…                                                         Last 24h· these are independent characteristics of your usage, not a breakdown↓
cmq93hx5r002se8mszsx7bo7l	cmq6w5d940000525uus1ckhga	6	18 June, 9:00 am (Sydney)	2026-06-17 23:00:00	\N	ok	2026-06-11 06:07:01.407	mcache[9Gwrite[15G($0.55)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m███████████████████████████████▌                  [54G[39m[49m63%[58Gused\r\r\n[3G[37mResets[10G6:50am[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m███                                               [54G[39m[49m6%[57Gused\r\r\n[3G[37mResets[10GJun[14G17,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[31A[30D[31B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[7A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[2C[1Both[7Gr devices[17Gor claude.ai\r[2C[2BScanning local sessions…[39m[K\r[2C[1B[K\r[2C[1B[37mEsc [8Go[10Gca[13Gcel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[21A[30D[21B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r\r\n[3G13%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[31A	B❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   StatsSession\n\nTotalcost:$0.55\nTotalduration(API):2m52s\nTotalduration(wall):1h45m6s\nTotalcodechanges:365linesadded,95linesremoved\nUsagebymodel:\n claude-haiku-4-5:762input,20output,0cacheread,0cachewrite\n($0.0009)\n claude-sonnet-4-6:365input,11.7koutput,731.7kcacheread,41.2k\ncachewrite($0.55)\n\nCurrentsession\n███████████████████████████████▌                  63%used\nResets6:50am(UTC)\n\nCurrentweek(allmodels)\n███                                               6%used\nResetsJun17,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devicesor claude.aiScanning local sessions…Esc ocacelLast 24h· these are independent characteristics of your usage, not a breakdown\n13%ofyourusagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq93ihd0002we8ms818uaj42	cmq6w5d940000525uus1ckhga	\N	\N	\N	\N	error	2026-06-11 06:07:27.588	usage\r\n[?2004l\r-bash: usage: command not found\r\n[?2004h[ec2-user@ip-172-31-23-229 ~]$ ^C[?2004l\r[?2004h[?2004l\r\r\n[?2004h[ec2-user@ip-172-31-23-229 ~]$ HOME=/home/ec2-user/claude-agents/agent-1 claude --dangerously-skip-permissions\r\n[?2004l\r	usage\n-bash: usage: command not found\n[ec2-user@ip-172-31-23-229 ~]$ ^C\n[ec2-user@ip-172-31-23-229 ~]$ HOME=/home/ec2-user/claude-agents/agent-1 claude --dangerously-skip-permissions
cmq93infb002xe8msp1g9mqwb	cmq6w5d940000525uus1ckhga	10	18 June, 9:00 am (Sydney)	2026-06-17 23:00:00	\N	ok	2026-06-11 06:07:35.447	[59G0[61Gcache[67Gwrite[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m█████████████████████████████████████████████████▌[54G[39m[49m99%[58Gused\r\r\n[3G[37mResets[10G6:50am[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m█████                                             [54G[39m[49m10%[58Gused\r\r\n[3G[37mResets[10GJun[14G17,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A[30D[27B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[7A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[2C[1Both[7Gr devices[17Gor claude.ai\r[2C[2BScanning local sessions…[39m[K\r[2C[1B[K\r[2C[1B[37mEsc [8Go[10Gca[13Gcel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[17A[30D[17B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r\r\n[3G13%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A	❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   StatsSession\n\nTotalcost:$0.0000\nTotalduration(API):0s\nTotalduration(wall):3s\nTotalcodechanges:0linesadded,0linesremoved\nUsage:0input,0output,0cacheread,0cachewrite\n\nCurrentsession\n█████████████████████████████████████████████████▌99%used\nResets6:50am(UTC)\n\nCurrentweek(allmodels)\n█████                                             10%used\nResetsJun17,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devicesor claude.aiScanning local sessions…Esc ocacelLast 24h· these are independent characteristics of your usage, not a breakdown\n13%ofyourusagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq9526iy006ue8msbbwer68i	cmq6w5d940000525uus1ckhga	10	18 June, 9:00 am (Sydney)	2026-06-17 23:00:00	\N	ok	2026-06-11 06:50:46.282	[59G0[61Gcache[67Gwrite[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m█████████████████████████████████████████████████▌[54G[39m[49m99%[58Gused\r\r\n[3G[37mResets[10G6:50am[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m█████                                             [54G[39m[49m10%[58Gused\r\r\n[3G[37mResets[10GJun[14G17,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A[30D[27B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[7A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[2C[1Both[7Gr devices[17Gor claude.ai\r[2C[2BScanning local sessions…[39m[K\r[2C[1B[K\r[2C[1B[37mEsc [8Go[10Gca[13Gcel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[17A[30D[17B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r\r\n[3G13%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A	B❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   Stats\nSession\n\nTotalcost:$0.0000\nTotalduration(API):0s\nTotalduration(wall):43m14s\nTotalcodechanges:0linesadded,0linesremoved\nUsage:0input,0output,0cacheread,0cachewrite\n\nCurrentsession\n█████████████████████████████████████████████████▌99%used\nResets6:50am(UTC)\n\nCurrentweek(allmodels)\n█████                                             10%used\nResetsJun17,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devicesor claude.aiScanning local sessions…Esc ocacelLast 24h· these are independent characteristics of your usage, not a breakdown\n13%ofyourusagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq952fvh006ve8msr728j09m	cmq6w5d940000525uus1ckhga	10	18 June, 9:00 am (Sydney)	2026-06-17 23:00:00	\N	ok	2026-06-11 06:50:58.397	[59G0[61Gcache[67Gwrite[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m█████████████████████████████████████████████████▌[54G[39m[49m99%[58Gused\r\r\n[3G[37mResets[10G6:50am[17G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m█████                                             [54G[39m[49m10%[58Gused\r\r\n[3G[37mResets[10GJun[14G17,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A[30D[27B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[7A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[2C[1Both[7Gr devices[17Gor claude.ai\r[2C[2BScanning local sessions…[39m[K\r[2C[1B[K\r[2C[1B[37mEsc [8Go[10Gca[13Gcel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[17A[30D[17B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r\r\n[3G13%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A	B❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   StatsSession\n\nTotalcost:$0.0000\nTotalduration(API):0s\nTotalduration(wall):43m26s\nTotalcodechanges:0linesadded,0linesremoved\nUsage:0input,0output,0cacheread,0cachewrite\n\nCurrentsession\n█████████████████████████████████████████████████▌99%used\nResets6:50am(UTC)\n\nCurrentweek(allmodels)\n█████                                             10%used\nResetsJun17,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devicesor claude.aiScanning local sessions…Esc ocacelLast 24h· these are independent characteristics of your usage, not a breakdown\n13%ofyourusagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq9532zg006ze8mszb717k7k	cmq6wcl430001525urn13fvcx	40	\N	\N	\N	ok	2026-06-11 06:51:28.348	]0;✳ Implement AI task review queue system[?25l[H[3G[100m                 \r[2C[1B[97mWhen you have fully comple[30Ged the task, output this exact completion block\r[1B[49m[94m▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\r[1B[39m   [94m[1mSettings[22m[39m  Status   Config  [104m[30m[1m Usage [22m[39m[49m  Stats[K\r[1B[K\r[3C[1B[1mSession\r[1B[22m[K\r[2C[1B [37mTotal cost:            $33.46\r[3C[1BTotal duration (API):  1h 51m 15s\r[1B[39m [3G [37mTotal duration (wall): 15h 41m 52s[39m[K\r[1B   [37mTotal code changes:    6894 lines added, 879 lines removed\r[3C[1BUsage by model:\r[1B[39m [3G [37m    claude-haiku-4-5:  986 i[33Gput, 6.9k output, 1.4m cache read, 55.0k \r[1B[39m   [37mcache write ($0.2453)[39m[K\r[3C[1B[37m   claude-s[16Gnnet-4-6:  6.7k input, 382.3k output, 79.2m cache read, 985.8k\r[3C[1Bcache write ($33.21)\r[1B[39m[K\r[2C[1B [1mCurrent session[22m[K\r[3C[1B[47m[33m█▌                                                [55G[39m[49m3% used[K\r[1B   [37mResets 11:50am (UTC)[39m[K\r[1B[K\r[1B   [1mCurrent week (all models)[22m[K\r[2C[1B [47m[33m████████████████████                              [39m[49m 40% used    [79G[37m↓[39m[23;1H[4;32H[H\r[3C[17B[1mWhat's contr[17Gbuting to your limits usage?\r[3C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[3C[1Both[8Gr devices or claude.ai\r[3C[2BScanning local sessions…[39m[K\r[3C[1B                                                  [55G   [59G    [23;1H[4;32H[H\r[78C[22B[K[23;1H[4;32H[H\r[3C[21B[37mLast 24h[13G· these are independent characteristics of your usage, not a \r[3C[1Bbreakdown[39m[23;1H[4;32H[H\r[78C[22B[37m↓[39m[23;1H[4;32H	When you have fully compleed the task, output this exact completion block▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔   Settings  Status   Config   Usage   StatsSession Total cost:            $33.46Total duration (API):  1h 51m 15s  Total duration (wall): 15h 41m 52s   Total code changes:    6894 lines added, 879 lines removedUsage by model:      claude-haiku-4-5:  986 iput, 6.9k output, 1.4m cache read, 55.0k    cache write ($0.2453)   claude-snnet-4-6:  6.7k input, 382.3k output, 79.2m cache read, 985.8kcache write ($33.21) Current session█▌                                                3% used   Resets 11:50am (UTC)   Current week (all models) ████████████████████                               40% used    ↓What's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devices or claude.aiScanning local sessions…                                                         Last 24h· these are independent characteristics of your usage, not a breakdown↓
cmq955hnp0072e8msp6gbw41s	cmq6w5d940000525uus1ckhga	\N	\N	\N	\N	error	2026-06-11 06:53:20.677	\N	\N
cmq955xzz0077e8msuoyul17g	cmq6w5d940000525uus1ckhga	\N	\N	\N	\N	error	2026-06-11 06:53:41.855	oes not include \r[2C[1Bother devi[15Gs or claude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[17A[30D[17B\r[20A   [37mFable 5 is now available with the latest version of Claude Code! Run "claude \r[3C[1Bupdate" to update to v2.1.170+\r[1B[39m[K\r[1B[100m[37m❯ [97m/usage[39m                                                                        \r[2B[49m[94m────────────────────────────────────────────────────────────────────────────────\r[2C[1B[1mSettings[13G[22m[39mStatus[22GConfig[30G[104m[30m[1m Usage [39G[22m[39m[49mStats\r[2C[1B[K\r[2C[1B[1mSession[22m[K\r[2C[1B[K\r[10C[1B[37mst:        [26G$0.0000[39m[K\r[2C[1B[37mTotal duration[18G(API):[27Gs[39m[K\r[2C[1B[37mTotal duration (wall): 1s\r[2C[1BTotal code changes:    0 lines added, 0 lines removed\r[2C[1BUsage:      [16G     [22G  [25G 0 input, 0 output, 0 cache r[55Gad, 0 cache[67Gwrite[39m[K\r[2C[1B[K\r[2C[1B[1mWhat's contributing to your limits usage?\r[2C[1B[22m[37mApproximate, ba[20Gd on local sessions on this machine — does not include \r[2C[1Bother devices or claude.ai\r[2C[1B[39m[K\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[17A[30D[17B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r\r\n[3G13%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A	❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   Stats\nSession\n\nTotalcost:$0.0000\nTotalduration(API):0s\nTotalduration(wall):1s\nTotalcodechanges:0linesadded,0linesremoved\nUsage:0input,0output,0cacheread,0cachewrite\n\nLoadingusagedata…\n\nEsctocancel\nWhat's contributing to your limits usage?Approximate, based on local sessions on this machine — does not include other devis or claude.ai\n\nScanninglocalsessions…\n\nEsctocancel\n   Fable 5 is now available with the latest version of Claude Code! Run "claude update" to update to v2.1.170+❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────SettingsStatusConfig Usage StatsSessionst:        $0.0000Total duration(API):sTotal duration (wall): 1sTotal code changes:    0 lines added, 0 lines removedUsage:              0 input, 0 output, 0 cache rad, 0 cachewriteWhat's contributing to your limits usage?Approximate, bad on local sessions on this machine — does not include other devices or claude.ai\nScanninglocalsessions…\n\nEsctocancel\nLast 24h· these are independent characteristics of your usage, not a breakdown\n13%ofyourusagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
cmq9562qa0078e8ms1yj2cgxu	cmq6w5d940000525uus1ckhga	10	18 June, 9:00 am (Sydney)	2026-06-17 23:00:00	\N	ok	2026-06-11 06:53:47.986	ead,[59G0[61Gcache[67Gwrite[39m\r\r\n\r\r\n[3G[1mCurrent[11Gsession[22m\r\r\n[3G[47m[33m                                                  [54G[39m[49m0%[57Gused\r\r\n[3G[37mResets[10G11:50am[18G(UTC)[39m\r\r\n\r\r\n[3G[1mCurrent[11Gweek[16G(all[21Gmodels)[22m\r\r\n[3G[47m[33m█████                                             [54G[39m[49m10%[58Gused\r\r\n[3G[37mResets[10GJun[14G17,[18G11pm[23G(UTC)[39m\r\r\n\r\r\n[3G[1mWhat's[10Gcontributing[23Gto[26Gyour[31Glimits[38Gusage?[22m\r\r\n[3G[37mApproximate,[16Gbased[22Gon[25Glocal[31Gsessions[40Gon[43Gthis[48Gmachine[56G—[58Gdoes[63Gnot[67Ginclude[39m\r\r\n[3G[37mother[9Gdevices[17Gor[20Gclaude.ai[39m\r\r\n\r\r\n[3G[37mScanning[12Glocal[18Gsessions…[39m\r\r\n\r\r\n[3G[37mRefreshing…[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A[30D[27B[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[1A[2K[G[1A\r[2C[7A[1mWhat's contr[16Gbuting to your limits usage?\r[2C[1B[22m[37mApproximate, based on local sessions on this machine — does not include \r[2C[1Both[7Gr devices or claude.ai\r[2C[2BScanning local sessions…[39m[K\r[2C[1B[K\r[2C[1B[37mEsc [8Go[10Gca[13Gcel[39m[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[1B[K\r[9A[30C[17A[30D[17B\r[2C[3A[37mLast 24h[12G· these are independent characteristics of your usage, not a \r[2C[1Bbreakdown\r[2C[1B[39m[K\r\r\n[3G13%[7Gof[10Gyour[15Gusage[21Gwas[25Gat[28G>150k[34Gcontext\r\r\n[4G[37mLonger[11Gsessions[20Gare[24Gmore[29Gexpensive[39Geven[44Gwhen[49Gcached.[57G/compact[66Gmid-task,[39m\r\r\n[4G[37m/clear[11Gwhen[16Gswitching[26Gto[29Gnew[33Gtasks.[39m\r\r\n\r\r\n[3G[1mSkills,[11Gsubagents,[22Gplugins,[31Gand[35GMCP[39Gservers[22m\r\r\n[3G[37mNo[6Gattribution[18Gdata[23Gyet[27G·[29Gaccumulates[41Gas[44Gyou[48Guse[52GClaude[39m\r\r\n\r\r\n[3G[37md[5Gto[8Gday[12G·[14Gw[16Gto[19Gweek[39m\r\r\n\r\r\n[3G[37mEsc[7Gto[10Gcancel[39m\r\r\n[30C[27A	❯ /usage                                                                        ────────────────────────────────────────────────────────────────────────────────Settings  Status   Config   Usage   StatsSession\n\nTotalcost:$0.0000\nTotalduration(API):0s\nTotalduration(wall):7s\nTotalcodechanges:0linesadded,0linesremoved\nUsage:0input,0output,0cacheread,0cachewrite\n\nCurrentsession\n                                                  0%used\nResets11:50am(UTC)\n\nCurrentweek(allmodels)\n█████                                             10%used\nResetsJun17,11pm(UTC)\n\nWhat'scontributingtoyourlimitsusage?\nApproximate,basedonlocalsessionsonthismachine—doesnotinclude\notherdevicesorclaude.ai\n\nScanninglocalsessions…\n\nRefreshing…\n\nEsctocancel\nWhat's contrbuting to your limits usage?Approximate, based on local sessions on this machine — does not include othr devices or claude.aiScanning local sessions…Esc ocacelLast 24h· these are independent characteristics of your usage, not a breakdown\n13%ofyourusagewasat>150kcontext\nLongersessionsaremoreexpensiveevenwhencached./compactmid-task,\n/clearwhenswitchingtonewtasks.\n\nSkills,subagents,plugins,andMCPservers\nNoattributiondatayet·accumulatesasyouuseClaude\n\ndtoday·wtoweek\n\nEsctocancel
\.


--
-- TOC entry 3805 (class 0 OID 30249)
-- Dependencies: 227
-- Data for Name: AuditEvent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AuditEvent" (id, "entityType", "entityId", "eventType", "actorType", payload, "createdAt") FROM stdin;
cmq83mbgw00030xpe1u5uo41c	task	cmq801l2u0008p35u5fkgy43k	task.queued	user	{"agentId": "cmq6w5d940000525uus1ckhga", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-10 13:22:40.4
cmq83mbw400050xpeyb63mu2k	task	cmq801l2u0008p35u5fkgy43k	task.dispatched	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "session": "claude-agent-1"}	2026-06-10 13:22:40.948
cmq83mjqo00060xpektyej0nx	task	cmq801l2p0007p35ubbze322d	task.queued	user	{"agentId": "cmq6w5d940000525uus1ckhga", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-10 13:22:51.12
cmq83mp3300070xpe5treahml	task	cmq801l250005p35u91238dex	task.queued	user	{"agentId": "cmq6w5d940000525uus1ckhga", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-10 13:22:58.047
cmq83tl8b000b0xpet83aa0hm	task	cmq801l2u0008p35u5fkgy43k	task.completed	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "detectedBy": "idle fallback (no marker after 6m)"}	2026-06-10 13:28:19.645
cmq83tln8000d0xpekh392e3w	task	cmq801l250005p35u91238dex	task.dispatched	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "session": "claude-agent-1"}	2026-06-10 13:28:20.181
cmq86o4f80002lt5uicp9mi2c	task	cmq801l2p0007p35ubbze322d	task.dispatched	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "session": "claude-agent-1"}	2026-06-10 14:48:03.428
cmq86vto90009lt5uk69110gk	task	cmq801l2p0007p35ubbze322d	task.completed	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "detectedBy": "idle fallback (no marker after 6m)"}	2026-06-10 14:54:02.746
cmq87i1jw000bpw5uply86qbq	task	cmq801l4i000jp35uipdtjawc	task.queued	user	{"agentId": "cmq6w5d940000525uus1ckhga", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-10 15:11:19.388
cmq87i82k000cpw5ucyw9daz4	task	cmq801l4f000ip35ubcwhnamd	task.queued	user	{"agentId": "cmq6w5d940000525uus1ckhga", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-10 15:11:27.836
cmq880ili000mpw5uuar8tzs9	task	cmq801l3f000cp35usrt9i0zy	task.queued	user	{"agentId": "cmq6w5d940000525uus1ckhga", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-10 15:25:41.286
cmq88yk8v001dpw5u58dd6z55	task	cmq801l2u0008p35u5fkgy43k	task.dispatched	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "session": "claude-agent-1"}	2026-06-10 15:52:09.727
cmq8969m6001lpw5u0cfkykb5	task	cmq801l2u0008p35u5fkgy43k	task.completed	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "detectedBy": "idle fallback (no marker after 6m)"}	2026-06-10 15:58:09.199
cmq896a3l001npw5utstqgbc2	task	cmq801l3f000cp35usrt9i0zy	task.dispatched	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "session": "claude-agent-1"}	2026-06-10 15:58:09.825
cmq89e7nq00006c5uejqm7ja2	task	cmq801l3f000cp35usrt9i0zy	task.completed	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "detectedBy": "idle fallback (no marker after 6m)"}	2026-06-10 16:04:19.922
cmq89jzj500046c5ulzz589yn	task	cmq801l3k000dp35uluceb7un	task.queued	user	{"agentId": "cmq6w5d940000525uus1ckhga", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-10 16:08:49.313
cmq89k07200066c5u6y63xhwg	task	cmq801l3k000dp35uluceb7un	task.dispatched	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "session": "claude-agent-1"}	2026-06-10 16:08:50.174
cmq89o665000a6c5uciw73rze	task	cmq801l3k000dp35uluceb7un	task.dispatched	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "session": "claude-agent-1"}	2026-06-10 16:12:04.541
cmq89yg57000l6c5uh3pq68it	task	cmq801l3k000dp35uluceb7un	task.completed	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "detectedBy": "idle fallback (no marker after 8m)"}	2026-06-10 16:20:04.028
cmq89ywu4000m6c5ul465ig9v	task	cmq801l4i000jp35uipdtjawc	task.queued	user	{"agentId": "cmq6wcl430001525urn13fvcx", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-10 16:20:25.66
cmq89z4r3000n6c5u5zsi6y5q	task	cmq801l3t000fp35uph6q5drr	task.queued	user	{"agentId": "cmq6wcl430001525urn13fvcx", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-10 16:20:35.919
cmq89zax4000o6c5u111geiem	task	cmq801l3p000ep35u17l9fnsv	task.queued	user	{"agentId": "cmq6wcl430001525urn13fvcx", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-10 16:20:43.912
cmq89zieq000p6c5us52pf9bc	task	cmq801l48000gp35upcewu3fv	task.queued	user	{"agentId": "cmq6wcl430001525urn13fvcx", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-10 16:20:53.618
cmq8a01le000r6c5utydt1cki	task	cmq801l4b000hp35u6q21s4je	task.queued	user	{"agentId": "cmq6wcl430001525urn13fvcx", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-10 16:21:18.482
cmq8dioe400010xnwksewscjk	task	cmq801l3p000ep35u17l9fnsv	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-10 17:59:46.684
cmq8dq30x000d0xnwbdooxchf	task	cmq801l3p000ep35u17l9fnsv	task.completed	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "detectedBy": "idle fallback (no marker after 6m)"}	2026-06-10 18:05:32.243
cmq8dq3ho000f0xnwhji6wo4e	task	cmq801l250005p35u91238dex	task.dispatched	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "session": "claude-agent-1"}	2026-06-10 18:05:32.844
cmq8dr1dy000g0xnw1b4t075q	task	cmq801l3p000ep35u17l9fnsv	task.queued	user	{"agentId": "cmq6w5d940000525uus1ckhga", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-10 18:06:16.774
cmq8dwiy9000t0xnwo1has71r	task	cmq801l3p000ep35u17l9fnsv	task.dispatched	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "session": "claude-agent-1"}	2026-06-10 18:10:32.817
cmq8e6syu000y0xnw9xf2x3wl	task	cmq801l3p000ep35u17l9fnsv	task.completed	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "detectedBy": "idle fallback (no marker after 8m)"}	2026-06-10 18:18:32.362
cmq8e6tei00100xnwu4xdsakt	task	cmq801l250005p35u91238dex	task.dispatched	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "session": "claude-agent-1"}	2026-06-10 18:18:32.922
cmq8eeijy00170xnwni6t7wfm	task	cmq801l250005p35u91238dex	task.completed	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "detectedBy": "idle fallback (no marker after 6m)"}	2026-06-10 18:24:32.11
cmq8g1llu00210xnw05fox9uc	task	cmq801l3t000fp35uph6q5drr	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-10 19:10:28.77
cmq8g9ecr00250xnw8vpfkgpd	task	cmq801l3t000fp35uph6q5drr	task.completed	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "detectedBy": "idle fallback (no marker after 6m)"}	2026-06-10 19:16:32.619
cmq8g9erg00270xnwgjp4wcu6	task	cmq801l48000gp35upcewu3fv	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-10 19:16:33.148
cmq8gh0v2002b0xnwnl5argym	task	cmq801l48000gp35upcewu3fv	task.completed	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "detectedBy": "idle fallback (no marker after 6m)"}	2026-06-10 19:22:28.384
cmq8gh19o002d0xnwijgj3j1o	task	cmq801l4b000hp35u6q21s4je	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-10 19:22:28.908
cmq8goqpl002h0xnwlbowjktx	task	cmq801l4b000hp35u6q21s4je	task.completed	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "detectedBy": "idle fallback (no marker after 6m)"}	2026-06-10 19:28:28.473
cmq8gor45002j0xnwh101o4y1	task	cmq801l4i000jp35uipdtjawc	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-10 19:28:28.997
cmq8h5jxy002t0xnwpb3v9v9a	task	cmq801l4i000jp35uipdtjawc	task.completed	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "detectedBy": "idle fallback (no marker after 13m)"}	2026-06-10 19:41:32.854
cmq8jz3oq00470xnwvp5pijkv	task	cmq801l4f000ip35ubcwhnamd	task.dispatched	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "session": "claude-agent-1"}	2026-06-10 21:00:30.698
cmq8k86sc004b0xnw18zxh1v3	task	cmq801l4f000ip35ubcwhnamd	task.completed	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "detectedBy": "idle fallback (no marker after 7m)"}	2026-06-10 21:07:34.626
cmq8vpln900040xmspygg19jm	task	cmq8vplmr00030xmszcu367qw	task.created	user	{"title": "test", "status": "pending", "priority": "P3", "taskType": "coding", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:29:02.805
cmq8vrbs500060xmscxw05kgx	task	cmq8vrbrn00050xmsc3knzsma	task.created	user	{"title": "Fix production build: resolve ssh2 / Turbopack incompatibility", "status": "pending", "priority": "P1", "taskType": "coding", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:30:23.333
cmq8vrq4u00080xms5qcebbmk	task	cmq8vrq4d00070xmsbohb72sq	task.created	user	{"title": "Implement webhook notifications for task completion and failure", "status": "pending", "priority": "P1", "taskType": "coding", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:30:41.934
cmq8vrq64000a0xms8q4i7rq3	task	cmq8vrq5y00090xmsgixurzts	task.created	user	{"title": "Fix tmux rate-limit false positive in fetchClaudeUsageViaTmux", "status": "pending", "priority": "P1", "taskType": "coding", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:30:41.98
cmq8vs37u000c0xms9rr0eaga	task	cmq8vs37n000b0xmsnu2oqier	task.created	user	{"title": "Expand Playwright E2E test suite to cover all major page flows", "status": "pending", "priority": "P2", "taskType": "coding", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:30:58.89
cmq8vsnbw000e0xmsuig3h4ds	task	cmq8vsnbo000d0xmsrr2fbhca	task.created	user	{"title": "Set up GitHub Actions CI/CD pipeline (lint, unit tests, E2E)", "status": "pending", "priority": "P2", "taskType": "maintenance", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:31:24.956
cmq8vsnd4000g0xmst3cxq9ra	task	cmq8vsncr000f0xmsks224km2	task.created	user	{"title": "Add task export to CSV and JSON from tasks list page", "status": "pending", "priority": "P2", "taskType": "coding", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:31:25
cmq8vsnf1000i0xmse4sifdnn	task	cmq8vsnes000h0xms0j94euut	task.created	user	{"title": "Add full-text search across tasks, projects, and agents", "status": "pending", "priority": "P2", "taskType": "coding", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:31:25.069
cmq8vt0iu000n0xmswg6qiodb	task	cmq8vt0il000m0xms72cipceo	task.created	user	{"title": "Add WebSocket auto-reconnect with exponential backoff in terminal", "status": "pending", "priority": "P2", "taskType": "coding", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:31:42.054
cmq8vt0k6000p0xmsrcef0fpa	task	cmq8vt0jo000o0xms5jqwfipu	task.created	user	{"title": "Implement SSH connection pool to eliminate per-request handshake overhead", "status": "pending", "priority": "P2", "taskType": "coding", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:31:42.102
cmq8vt0lr000r0xmsl63djetz	task	cmq8vt0ld000q0xms01l89pp0	task.created	user	{"title": "Add bulk task operations: multi-select, bulk assign, bulk archive", "status": "pending", "priority": "P2", "taskType": "coding", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:31:42.159
cmq8vteom000t0xmswd1x2epy	task	cmq8vteoe000s0xms4o0opkg6	task.created	user	{"title": "Build task dependency DAG visualization on project detail page", "status": "pending", "priority": "P2", "taskType": "coding", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:32:00.406
cmq8vteqm000v0xmsqrngq4jv	task	cmq8vteq2000u0xmsrzxq2w1t	task.created	user	{"title": "Add weekly and monthly report generation alongside daily reports", "status": "pending", "priority": "P3", "taskType": "coding", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:32:00.478
cmq8vtes1000x0xmskcnp9s12	task	cmq8vterw000w0xms74u219q3	task.created	user	{"title": "Implement time-based scheduled task dispatch (run task at specific datetime)", "status": "pending", "priority": "P3", "taskType": "coding", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:32:00.529
cmq8vtrwx000z0xms5oopqiky	task	cmq8vtrwi000y0xmscdmrqzyd	task.created	user	{"title": "Track actual Claude API cost per execution and surface cost analytics", "status": "pending", "priority": "P3", "taskType": "coding", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:32:17.553
cmq8vtrz400110xmsimat6h1l	task	cmq8vtryv00100xmsjp3bvgo3	task.created	user	{"title": "Add docker-compose.yml for one-command local development setup", "status": "pending", "priority": "P3", "taskType": "maintenance", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:32:17.632
cmq8vts0u00130xms3qp6mxg7	task	cmq8vts0p00120xms50ew2d47	task.created	user	{"title": "Improve mobile responsiveness: collapsible sidebar, responsive tables", "status": "pending", "priority": "P3", "taskType": "coding", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:32:17.694
cmq8vu62300150xmsi2gpbg3x	task	cmq8vu61w00140xms13kqf5dy	task.created	user	{"title": "Enable improvement cycle automation (level 1) for WorkerAI project", "status": "pending", "priority": "P3", "taskType": "maintenance", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:32:35.883
cmq8vu63900170xmsb9bf7xcg	task	cmq8vu63200160xmsftpfjjtx	task.created	user	{"title": "Add dark mode support using Tailwind CSS v4 and system preference detection", "status": "pending", "priority": "P3", "taskType": "coding", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:32:35.925
cmq8vu64c00190xmsxpt50m7c	task	cmq8vu64700180xmsprc9twqh	task.created	user	{"title": "Add keyboard shortcuts for power-user navigation and common actions", "status": "pending", "priority": "P4", "taskType": "coding", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:32:35.964
cmq8vud7h001b0xmsa3c17nwm	task	cmq8vud7c001a0xmsat6b7ywk	task.created	user	{"title": "Add database backup and restore scripts with automated daily snapshot", "status": "pending", "priority": "P4", "taskType": "maintenance", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8"}	2026-06-11 02:32:45.149
cmq8w20ip001f0xms9zb7q6t0	task	cmq8vrq5y00090xmsgixurzts	task.queued	user	{"agentId": "cmq6w5d940000525uus1ckhga", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 02:38:41.953
cmq8w20za001h0xmsw3scyp1h	task	cmq8vrq5y00090xmsgixurzts	task.dispatched	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "session": "claude-agent-1"}	2026-06-11 02:38:42.55
cmq8w26lt001i0xmsevavpw1l	task	cmq8vrq4d00070xmsbohb72sq	task.queued	user	{"agentId": "cmq6wcl430001525urn13fvcx", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 02:38:49.841
cmq8w2714001k0xmssxwz5fl3	task	cmq8vrq4d00070xmsbohb72sq	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-11 02:38:50.392
cmq8w2axq001l0xmsp47cu4ff	task	cmq8vrbrn00050xmsc3knzsma	task.queued	user	{"agentId": "cmq6w5d940000525uus1ckhga", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 02:38:55.454
cmq8w2e91001m0xmspx0n3awc	task	cmq8vteoe000s0xms4o0opkg6	task.queued	user	{"agentId": "cmq6wcl430001525urn13fvcx", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 02:38:59.749
cmq8w2i2g001n0xmszzzwp0q5	task	cmq8vt0ld000q0xms01l89pp0	task.queued	user	{"agentId": "cmq6w5d940000525uus1ckhga", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 02:39:04.696
cmq8w2ljz001o0xmsk55hoenz	task	cmq8vt0jo000o0xms5jqwfipu	task.queued	user	{"agentId": "cmq6wcl430001525urn13fvcx", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 02:39:09.215
cmq8w32sp001r0xmsaqksxnhd	task	cmq8vt0il000m0xms72cipceo	task.queued	user	{"agentId": "cmq6w5d940000525uus1ckhga", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 02:39:31.561
cmq8w2t9a001p0xms1w139fet	task	cmq8vteq2000u0xmsrzxq2w1t	task.queued	user	{"agentId": "cmq6w5d940000525uus1ckhga", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 02:39:19.198
cmq8w2yme001q0xms1yp7gd7a	task	cmq8vsnbo000d0xmsrr2fbhca	task.queued	user	{"agentId": "cmq6wcl430001525urn13fvcx", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 02:39:26.15
cmq8wbxcp001v0xms97wogkko	task	cmq8vrq4d00070xmsbohb72sq	task.completed	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "detectedBy": "idle fallback (no marker after 8m)"}	2026-06-11 02:46:24.415
cmq8wbxs7001x0xms6y9rshu9	task	cmq8vsnbo000d0xmsrr2fbhca	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-11 02:46:24.967
cmq8wig1p00210xmseghzg8bl	task	cmq8vsnbo000d0xmsrr2fbhca	task.completed	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "detectedBy": "idle fallback (no marker after 5m)"}	2026-06-11 02:51:28.573
cmq8wiggt00230xms1y62c9pa	task	cmq8vt0jo000o0xms5jqwfipu	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-11 02:51:29.117
cmq8wq5um002a0xmsvivkkdc1	task	cmq8vt0jo000o0xms5jqwfipu	task.completed	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "detectedBy": "idle fallback (no marker after 6m)"}	2026-06-11 02:57:28.606
cmq8wq69g002c0xmsqoyf1zb7	task	cmq8vteoe000s0xms4o0opkg6	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-11 02:57:29.14
cmq8wxvme002g0xmskwyerwaf	task	cmq8vteoe000s0xms4o0opkg6	task.completed	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "detectedBy": "idle fallback (no marker after 6m)"}	2026-06-11 03:03:28.599
cmq8y6wmo00350xmst4qmrh03	task	cmq8vrbrn00050xmsc3knzsma	task.dispatched	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "session": "claude-agent-1"}	2026-06-11 03:38:29.424
cmq8y9hs800370xmsn5qmbuvz	task	cmq8vt0il000m0xms72cipceo	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-11 03:40:30.152
cmq8ybyj0003b0xmsn82dye3k	task	cmq8vsnes000h0xms0j94euut	task.queued	user	{"agentId": "cmq6w5d940000525uus1ckhga", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 03:42:25.164
cmq8yc4ew003c0xmswhoungfj	task	cmq8vsncr000f0xmsks224km2	task.queued	user	{"agentId": "cmq6wcl430001525urn13fvcx", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 03:42:32.792
cmq8yc8fi003d0xmsy1bzdb3v	task	cmq8vs37n000b0xmsnu2oqier	task.queued	user	{"agentId": "cmq6w5d940000525uus1ckhga", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 03:42:37.998
cmq8yh3hw003e0xmsix0b6zcy	task	cmq8vt0il000m0xms72cipceo	task.completed	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "detectedBy": "idle fallback (no marker after 6m)"}	2026-06-11 03:46:24.904
cmq8yh3yi003g0xms06vc3bqb	task	cmq8vsncr000f0xmsks224km2	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-11 03:46:25.482
cmq8ynm9g003k0xmszwkui3xj	task	cmq8vsncr000f0xmsks224km2	task.completed	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "detectedBy": "idle fallback (no marker after 5m)"}	2026-06-11 03:51:29.14
cmq8ynmns003m0xmsreunty4a	task	cmq8vt0ld000q0xms01l89pp0	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-11 03:51:29.656
cmq8z5mkv003w0xmsm7r2no27	task	cmq8vrbrn00050xmsc3knzsma	task.completed	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "detectedBy": "idle fallback (no marker after 27m)"}	2026-06-11 04:05:29.359
cmq8z5mzm003y0xms2fnf4rr4	task	cmq8vs37n000b0xmsnu2oqier	task.dispatched	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "session": "claude-agent-1"}	2026-06-11 04:05:29.89
cmq8zangs00460xmsrxjnyf3m	task	cmq8zangj00450xmsea4j7axa	task.created	user	{"title": "e2e-proj-1781150963516-task-1", "status": "pending", "priority": "P2", "taskType": "coding", "projectId": "cmq8zanap00440xmszgvpm7yl"}	2026-06-11 04:09:23.788
cmq8zaoia004b0xms5g21ouql	task	cmq8zaoi6004a0xmsu2sgch1s	task.created	user	{"title": "e2e-queue-1781150964968-high-p1", "status": "pending", "priority": "P1", "taskType": "coding", "projectId": "cmq8zaohd00480xms0e44tlup"}	2026-06-11 04:09:25.138
cmq8zaoiq004d0xmsv6q2mxqy	task	cmq8zaoim004c0xmsucl7a2d5	task.created	user	{"title": "e2e-queue-1781150964968-high-p3", "status": "pending", "priority": "P3", "taskType": "coding", "projectId": "cmq8zaohd00480xms0e44tlup"}	2026-06-11 04:09:25.154
cmq8zaoje004f0xmsvj5cu0z1	task	cmq8zaojb004e0xmsy4sj6lhw	task.created	user	{"title": "e2e-queue-1781150964968-low-p1", "status": "pending", "priority": "P1", "taskType": "coding", "projectId": "cmq8zaohr00490xmsm6unbdw2"}	2026-06-11 04:09:25.178
cmq8zrhmt004u0xmsznegsteh	task	cmq8vs37n000b0xmsnu2oqier	task.completed	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "detectedBy": "idle fallback (no marker after 17m)"}	2026-06-11 04:22:29.381
cmq8zri1z004w0xmsd5axpbx2	task	cmq8vsnes000h0xms0j94euut	task.dispatched	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "session": "claude-agent-1"}	2026-06-11 04:22:29.927
cmq8zssdp004y0xmsccfcz7zu	task	cmq8vsnes000h0xms0j94euut	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-11 04:23:29.965
cmq8zuv76004z0xms2aja0r7i	task	cmq8vu63200160xmsftpfjjtx	task.queued	user	{"agentId": "cmq6wcl430001525urn13fvcx", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 04:25:06.93
cmq8zuz0i00500xmsymectyny	task	cmq8vu61w00140xms13kqf5dy	task.queued	user	{"agentId": "cmq6wcl430001525urn13fvcx", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 04:25:11.874
cmq8zv22l00510xmsgl85q24f	task	cmq8vts0p00120xms50ew2d47	task.queued	user	{"agentId": "cmq6wcl430001525urn13fvcx", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 04:25:15.837
cmq8zz7y500560xmsykmxfolf	task	cmq8vteq2000u0xmsrzxq2w1t	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-11 04:28:30.077
cmq906xrc005b0xmsdtw1h11q	task	cmq8vts0p00120xms50ew2d47	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-11 04:34:30.12
cmq90dd2u005g0xmswf2n0ay6	task	cmq8vu61w00140xms13kqf5dy	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-11 04:39:29.91
cmq90j862005l0xmsgxdo2dwm	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	user	{"cycleId": "cmq90j85q005k0xms4anaj2ze", "automationLevel": 1}	2026-06-11 04:44:03.482
cmq90js8w005m0xmss1kseru6	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq90j85q005k0xms4anaj2ze"}	2026-06-11 04:44:29.504
cmq90jsa6005o0xmsrjg0zddi	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq90j85q005k0xms4anaj2ze"}	2026-06-11 04:44:29.55
cmq90po12005s0xms6u27sxca	task	cmq8vtryv00100xmsjp3bvgo3	task.queued	user	{"agentId": "cmq6wcl430001525urn13fvcx", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 04:49:03.979
cmq90psjk005t0xms87c0t9yr	task	cmq8vtrwi000y0xmscdmrqzyd	task.queued	user	{"agentId": "cmq6wcl430001525urn13fvcx", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 04:49:09.824
cmq90pw0m005u0xmsrv1ua6gl	task	cmq8vterw000w0xms74u219q3	task.queued	user	{"agentId": "cmq6wcl430001525urn13fvcx", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 04:49:14.326
cmq90pz6h005v0xmsksww0yj3	task	cmq8vud7c001a0xmsat6b7ywk	task.queued	user	{"agentId": "cmq6wcl430001525urn13fvcx", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 04:49:18.425
cmq90q2ig005w0xmsq00mgzbw	task	cmq8vu64700180xmsprc9twqh	task.queued	user	{"agentId": "cmq6wcl430001525urn13fvcx", "serverId": "cmq6ke2xl0000s25u4a8i94ta"}	2026-06-11 04:49:22.744
cmq911j560001czmsy8jf5sjy	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq911j4w0000czmsvhtai8y3", "automationLevel": 1}	2026-06-11 04:58:17.514
cmq911nqr0003czmstbtln67r	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq911j4w0000czmsvhtai8y3"}	2026-06-11 04:58:23.475
cmq911nsj0005czms9sp3dzbo	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq911j4w0000czmsvhtai8y3"}	2026-06-11 04:58:23.539
cmq912lpq0008czmstb14tr5l	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq912lpm0007czmst2iyfbpk", "automationLevel": 1}	2026-06-11 04:59:07.502
cmq913wby0009czms49qv3o73	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq912lpm0007czmst2iyfbpk"}	2026-06-11 05:00:07.918
cmq913wdi000bczmsrv57wg13	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq912lpm0007czmst2iyfbpk"}	2026-06-11 05:00:07.974
cmq9156h6000dczmsyq6cz4sf	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq9156h3000cczms3ofgnnw3", "automationLevel": 1}	2026-06-11 05:01:07.722
cmq916gur000hczmsalgvf8v0	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq9156h3000cczms3ofgnnw3"}	2026-06-11 05:02:07.827
cmq916gwn000jczmsamlpb75k	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq9156h3000cczms3ofgnnw3"}	2026-06-11 05:02:07.895
cmq917r9k000lczmsq5ey14rr	task	cmq8vterw000w0xms74u219q3	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-11 05:03:07.976
cmq917rar000nczmsechx1jca	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq917rag000mczms7g3spca7", "automationLevel": 1}	2026-06-11 05:03:08.019
cmq919157000oczms8xe5hajf	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq917rag000mczms7g3spca7"}	2026-06-11 05:04:07.435
cmq91915u000qczmsjliaku4c	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq917rag000mczms7g3spca7"}	2026-06-11 05:04:07.458
cmq91abn8000sczms8kla90tc	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq91abn2000rczmscsunqv10", "automationLevel": 1}	2026-06-11 05:05:07.7
cmq91bm31000tczmsm6ldwb98	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq91abn2000rczmscsunqv10"}	2026-06-11 05:06:07.885
cmq91bm3u000vczms0p6p7npc	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq91abn2000rczmscsunqv10"}	2026-06-11 05:06:07.914
cmq91cwq80010czmsch9prxo2	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq91cwq6000zczmsb22y41ft", "automationLevel": 1}	2026-06-11 05:07:08.336
cmq91e6vq0011czmscnpga72x	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq91cwq6000zczmsb22y41ft"}	2026-06-11 05:08:08.153
cmq91e6xc0013czmsg4l2a8ie	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq91cwq6000zczmsb22y41ft"}	2026-06-11 05:08:08.208
cmq91fgv40015czms2xmer6ad	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq91fgux0014czmsfsl1lafg", "automationLevel": 1}	2026-06-11 05:09:07.744
cmq91grec0016czms1xc670od	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq91fgux0014czmsfsl1lafg"}	2026-06-11 05:10:08.052
cmq91grfm0018czms88nfnha9	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq91fgux0014czmsfsl1lafg"}	2026-06-11 05:10:08.098
cmq91hyov001aczmsmd96cdm2	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq91hyoh0019czmsc9khznar", "automationLevel": 1}	2026-06-11 05:11:04.159
cmq91jbzf001eczmslb98ekhk	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq91hyoh0019czmsc9khznar"}	2026-06-11 05:12:08.043
cmq91jc0d001gczmshp6aafqi	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq91hyoh0019czmsc9khznar"}	2026-06-11 05:12:08.077
cmq91kt080002p2msj4ac55vc	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq91kt030001p2msmst53ogh", "automationLevel": 1}	2026-06-11 05:13:16.76
cmq91lruc0003p2ms9sn96zrq	task	cmq8vterw000w0xms74u219q3	task.completed	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "detectedBy": "idle fallback (no marker after 11m)"}	2026-06-11 05:14:01.916
cmq91lsqc0005p2msj417geb3	task	cmq8vtrwi000y0xmscdmrqzyd	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-11 05:14:03.06
cmq91lstm0006p2msn5glmx71	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq91kt030001p2msmst53ogh"}	2026-06-11 05:14:03.178
cmq91lsv90008p2msmy06m749	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq91kt030001p2msmst53ogh"}	2026-06-11 05:14:03.237
cmq91n20c000ap2mssbwwg92p	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq91n1zv0009p2msz7pe7wvv", "automationLevel": 1}	2026-06-11 05:15:01.74
cmq91ocb1000bp2msicqoqbe5	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq91n1zv0009p2msz7pe7wvv"}	2026-06-11 05:16:01.741
cmq91ocdn000dp2mspwxlsorq	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq91n1zv0009p2msz7pe7wvv"}	2026-06-11 05:16:01.835
cmq91pmwu000ip2mswim0nklv	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq91pmwp000hp2mswgkpv73m", "automationLevel": 1}	2026-06-11 05:17:02.142
cmq91qwrw000jp2mspbyuvlgr	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq91pmwp000hp2mswgkpv73m"}	2026-06-11 05:18:01.58
cmq91qwv7000lp2msf7uvch37	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq91pmwp000hp2mswgkpv73m"}	2026-06-11 05:18:01.699
cmq91s71q000np2ms5ar16yvi	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq91s716000mp2msgyzm1vqk", "automationLevel": 1}	2026-06-11 05:19:01.55
cmq91thft000op2msmbjzohgz	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq91s716000mp2msgyzm1vqk"}	2026-06-11 05:20:01.673
cmq91thkg000qp2mspte8o17u	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq91s716000mp2msgyzm1vqk"}	2026-06-11 05:20:01.846
cmq91urgp000sp2ms22dvajgt	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq91urgk000rp2msps38cd8k", "automationLevel": 1}	2026-06-11 05:21:01.321
cmq91w226000wp2mse54mwqc8	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq91urgk000rp2msps38cd8k"}	2026-06-11 05:22:01.71
cmq91w233000yp2msux5dpedm	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq91urgk000rp2msps38cd8k"}	2026-06-11 05:22:01.743
cmq91xc700010p2msexg3ylsx	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq91xc6u000zp2msm9lztmjn", "automationLevel": 1}	2026-06-11 05:23:01.5
cmq91ymhe0011p2mslyugy3kr	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq91xc6u000zp2msm9lztmjn"}	2026-06-11 05:24:01.491
cmq91ymlt0013p2msfvclc3jn	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq91xc6u000zp2msm9lztmjn"}	2026-06-11 05:24:01.649
cmq91zx4d0015p2ms7vzm5h4f	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq91zx440014p2mse1ybo6pg", "automationLevel": 1}	2026-06-11 05:25:01.933
cmq9217an0016p2msglfj9sjh	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq91zx440014p2mse1ybo6pg"}	2026-06-11 05:26:01.787
cmq9217gs0018p2mselyil5lt	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq91zx440014p2mse1ybo6pg"}	2026-06-11 05:26:01.996
cmq922igr001dp2ms5qq5jd0n	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq922igm001cp2msq20pn21a", "automationLevel": 1}	2026-06-11 05:27:02.907
cmq923sk1001ep2msnig0op11	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq922igm001cp2msq20pn21a"}	2026-06-11 05:28:02.641
cmq923snl001gp2ms9xccpnxt	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq922igm001cp2msq20pn21a"}	2026-06-11 05:28:02.769
cmq92525p001ip2msyeja58oh	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq925258001hp2mso8oe00r2", "automationLevel": 1}	2026-06-11 05:29:01.741
cmq926djs001jp2mses2125iw	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq925258001hp2mso8oe00r2"}	2026-06-11 05:30:03.161
cmq926dnf001lp2ms9lt6zp9z	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq925258001hp2mso8oe00r2"}	2026-06-11 05:30:03.291
cmq927nm6001np2mslax3l3vi	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq927nls001mp2mstpgu7x4d", "automationLevel": 1}	2026-06-11 05:31:02.862
cmq928y3g001rp2msh1kas0dr	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq927nls001mp2mstpgu7x4d"}	2026-06-11 05:32:03.1
cmq928y9d001tp2mskm5n25xt	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq927nls001mp2mstpgu7x4d"}	2026-06-11 05:32:03.313
cmq92a858001vp2ms8o2dn8du	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq92a84i001up2msi8pwmcny", "automationLevel": 1}	2026-06-11 05:33:02.78
cmq92bhhh001wp2ms03n57auj	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq92a84i001up2msi8pwmcny"}	2026-06-11 05:34:01.541
cmq92bhlc001yp2ms3p4g50di	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq92a84i001up2msi8pwmcny"}	2026-06-11 05:34:01.68
cmq92cruk0020p2mss2o5hlwf	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq92crub001zp2mscwioenvz", "automationLevel": 1}	2026-06-11 05:35:01.628
cmq92djiv0002e8msezfrpk3h	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq92crub001zp2mscwioenvz"}	2026-06-11 05:35:37.495
cmq92djku0004e8msw10oehp5	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq92crub001zp2mscwioenvz"}	2026-06-11 05:35:37.567
cmq92ehvi0006e8mslmcmiih5	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq92ehvf0005e8mstv4hkkh9", "automationLevel": 1}	2026-06-11 05:36:22.014
cmq92fs4p0007e8msydxh58vs	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq92ehvf0005e8mstv4hkkh9"}	2026-06-11 05:37:21.961
cmq92fs5x0009e8ms1qro629w	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq92ehvf0005e8mstv4hkkh9"}	2026-06-11 05:37:22.005
cmq92h2f8000be8ms877qn57x	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq92h2f5000ae8msdc8wsgmr", "automationLevel": 1}	2026-06-11 05:38:21.956
cmq92id0o000fe8ms7qm7tezw	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq92h2f5000ae8msdc8wsgmr"}	2026-06-11 05:39:22.344
cmq92id23000he8mscfyrxa48	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq92h2f5000ae8msdc8wsgmr"}	2026-06-11 05:39:22.395
cmq92jmyx000je8ms5fcnhamq	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq92jmyv000ie8ms9wsg5t64", "automationLevel": 1}	2026-06-11 05:40:21.897
cmq92kxft000ke8ms5qvd0dg3	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq92jmyv000ie8ms9wsg5t64"}	2026-06-11 05:41:22.121
cmq92kxh2000me8msufbidkzo	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq92jmyv000ie8ms9wsg5t64"}	2026-06-11 05:41:22.166
cmq92m7mv000oe8msnu3h6tzg	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq92m7ms000ne8msgiu02wmz", "automationLevel": 1}	2026-06-11 05:42:21.991
cmq92nhx3000pe8ms6zlf0qmn	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq92m7ms000ne8msgiu02wmz"}	2026-06-11 05:43:21.975
cmq92nhyt000re8msxkt1odsl	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq92m7ms000ne8msgiu02wmz"}	2026-06-11 05:43:22.037
cmq92osbz000we8msw74rjus3	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq92osbv000ve8msrp51rf5m", "automationLevel": 1}	2026-06-11 05:44:22.127
cmq92q2it000xe8mskkpnzff7	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq92osbv000ve8msrp51rf5m"}	2026-06-11 05:45:21.989
cmq92q2k9000ze8mskkuszk03	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq92osbv000ve8msrp51rf5m"}	2026-06-11 05:45:22.041
cmq92rcps0011e8mstym55wjl	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq92rcpq0010e8ms1g3v7mem", "automationLevel": 1}	2026-06-11 05:46:21.857
cmq92smzc0012e8ms2s81ovo1	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq92rcpq0010e8ms1g3v7mem"}	2026-06-11 05:47:21.816
cmq92sn0k0014e8mspl5ycg50	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq92rcpq0010e8ms1g3v7mem"}	2026-06-11 05:47:21.86
cmq92txd60016e8msa4epzjj8	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq92txd30015e8msvd6phr7w", "automationLevel": 1}	2026-06-11 05:48:21.93
cmq92v7v4001ae8mslahvwwnw	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq92txd30015e8msvd6phr7w"}	2026-06-11 05:49:22.192
cmq92v7x0001ce8mspwijgxyb	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq92txd30015e8msvd6phr7w"}	2026-06-11 05:49:22.26
cmq92wi04001ee8msqn0euvta	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq92wi02001de8msmmkfw085", "automationLevel": 1}	2026-06-11 05:50:21.988
cmq92xs9w001fe8ms31s2k50r	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq92wi02001de8msmmkfw085"}	2026-06-11 05:51:21.956
cmq92xsb0001he8ms1eyiks5u	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq92wi02001de8msmmkfw085"}	2026-06-11 05:51:21.996
cmq92z2j2001je8ms1i4qurl2	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq92z2j0001ie8msrk0vxzpz", "automationLevel": 1}	2026-06-11 05:52:21.902
cmq930cve001ke8msp6kb5h3c	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq92z2j0001ie8msrk0vxzpz"}	2026-06-11 05:53:21.962
cmq930cwi001me8ms0ifv23h9	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq92z2j0001ie8msrk0vxzpz"}	2026-06-11 05:53:22.002
cmq931nab001re8ms47dr15p4	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq931na8001qe8ms2fe8466e", "automationLevel": 1}	2026-06-11 05:54:22.115
cmq932xgm001se8ms51aq1ukm	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq931na8001qe8ms2fe8466e"}	2026-06-11 05:55:21.958
cmq932xhv001ue8msqap51zko	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq931na8001qe8ms2fe8466e"}	2026-06-11 05:55:22.003
cmq9347qm001we8msx1r1xezj	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq9347qj001ve8ms0q0ixpow", "automationLevel": 1}	2026-06-11 05:56:21.934
cmq935i2t001xe8msi5f2qmlh	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq9347qj001ve8ms0q0ixpow"}	2026-06-11 05:57:21.989
cmq935i40001ze8ms83giq1pz	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq9347qj001ve8ms0q0ixpow"}	2026-06-11 05:57:22.032
cmq936sbz0021e8ms8frrv70i	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq936sbx0020e8ms1lil2sa2", "automationLevel": 1}	2026-06-11 05:58:21.935
cmq9382so0025e8msxybn9w0d	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq936sbx0020e8ms1lil2sa2"}	2026-06-11 05:59:22.152
cmq9382ua0027e8msqwc7pscc	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq936sbx0020e8ms1lil2sa2"}	2026-06-11 05:59:22.21
cmq939cym0029e8ms01aa7end	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq939cyj0028e8ms310h9hm4", "automationLevel": 1}	2026-06-11 06:00:21.982
cmq93anaq002ae8msqkvc4vvr	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq939cyj0028e8ms310h9hm4"}	2026-06-11 06:01:22.034
cmq93anbw002ce8ms2nl9jyl9	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq939cyj0028e8ms310h9hm4"}	2026-06-11 06:01:22.076
cmq93bxix002ee8msdpd05371	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq93bxiv002de8mse277n5yz", "automationLevel": 1}	2026-06-11 06:02:21.945
cmq93d7sk002fe8msrsauoiaw	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq93bxiv002de8mse277n5yz"}	2026-06-11 06:03:21.908
cmq93d7tr002he8mszhhliv8q	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq93bxiv002de8mse277n5yz"}	2026-06-11 06:03:21.951
cmq93eiaj002me8msgzphkvg4	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq93eiag002le8msuyy6x2mz", "automationLevel": 1}	2026-06-11 06:04:22.172
cmq93fsd1002ne8msft0h3jdt	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq93eiag002le8msuyy6x2mz"}	2026-06-11 06:05:21.877
cmq93fsef002pe8ms0xa2n38r	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq93eiag002le8msuyy6x2mz"}	2026-06-11 06:05:21.927
cmq93h2oh002re8msf1cu2gij	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq93h2oe002qe8mstbb4kz6h", "automationLevel": 1}	2026-06-11 06:06:21.905
cmq93id3c002te8msce4tt193	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq93h2oe002qe8mstbb4kz6h"}	2026-06-11 06:07:22.056
cmq93id4v002ve8mso4zfz49w	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq93h2oe002qe8mstbb4kz6h"}	2026-06-11 06:07:22.111
cmq93jnb40030e8msmvkw6zqd	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq93jnb1002ze8msjeltm384", "automationLevel": 1}	2026-06-11 06:08:21.952
cmq93kxsu0034e8msbs0vg9m6	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq93jnb1002ze8msjeltm384"}	2026-06-11 06:09:22.206
cmq93kxud0036e8ms31td21kx	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq93jnb1002ze8msjeltm384"}	2026-06-11 06:09:22.261
cmq93m7vg0038e8mswcljxdvi	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq93m7ve0037e8mslep6o6jr", "automationLevel": 1}	2026-06-11 06:10:21.916
cmq93ni3v0039e8ms0zs8gkmf	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq93m7ve0037e8mslep6o6jr"}	2026-06-11 06:11:21.835
cmq93ni51003be8msiz9imrv9	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq93m7ve0037e8mslep6o6jr"}	2026-06-11 06:11:21.877
cmq93osgi003de8mskv2ei7n5	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq93osgg003ce8msjkcu67uc", "automationLevel": 1}	2026-06-11 06:12:21.906
cmq93q2rh003ee8msvhmuw0ly	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq93osgg003ce8msjkcu67uc"}	2026-06-11 06:13:21.917
cmq93q2sp003ge8msni9qpz2u	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq93osgg003ce8msjkcu67uc"}	2026-06-11 06:13:21.961
cmq93rd86003le8msvkasjdjt	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq93rd82003ke8ms9jm5awn5", "automationLevel": 1}	2026-06-11 06:14:22.134
cmq93snbl003me8msvb8mglls	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq93rd82003ke8ms9jm5awn5"}	2026-06-11 06:15:21.873
cmq93snct003oe8ms4b0f3gna	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq93rd82003ke8ms9jm5awn5"}	2026-06-11 06:15:21.917
cmq93txnw003qe8msxd3bzxsl	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq93txnu003pe8msbt3tmyyu", "automationLevel": 1}	2026-06-11 06:16:21.932
cmq93v7zq003re8msjg3mg6s6	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq93txnu003pe8msbt3tmyyu"}	2026-06-11 06:17:21.974
cmq93v80u003te8msgz6ovp8p	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq93txnu003pe8msbt3tmyyu"}	2026-06-11 06:17:22.014
cmq93widd003ve8msj2pdenyo	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq93widb003ue8mszkgp8s6o", "automationLevel": 1}	2026-06-11 06:18:22.081
cmq93xsu7003ze8mspyogixfx	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq93widb003ue8mszkgp8s6o"}	2026-06-11 06:19:22.303
cmq93xsvr0041e8msxpjtrnpg	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq93widb003ue8mszkgp8s6o"}	2026-06-11 06:19:22.359
cmq93z2vr0043e8ms5236lv8w	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq93z2vp0042e8msyk3iiill", "automationLevel": 1}	2026-06-11 06:20:21.975
cmq940dbj0044e8msvp2cyxdj	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq93z2vp0042e8msyk3iiill"}	2026-06-11 06:21:22.159
cmq940dco0046e8mssxzvkzit	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq93z2vp0042e8msyk3iiill"}	2026-06-11 06:21:22.2
cmq941nkz0048e8mssssfokib	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq941nkx0047e8mspkf727wf", "automationLevel": 1}	2026-06-11 06:22:22.115
cmq942xut0049e8mstcj76630	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq941nkx0047e8mspkf727wf"}	2026-06-11 06:23:22.085
cmq942xvx004be8msr7be2j41	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq941nkx0047e8mspkf727wf"}	2026-06-11 06:23:22.125
cmq9448b9004ge8msm9qadwm1	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq9448b5004fe8mschkbsoli", "automationLevel": 1}	2026-06-11 06:24:22.293
cmq945ii2004he8mscv16dnce	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq9448b5004fe8mschkbsoli"}	2026-06-11 06:25:22.154
cmq945ijd004je8msjo6l5lg9	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq9448b5004fe8mschkbsoli"}	2026-06-11 06:25:22.201
cmq946sug004le8msgvg6l2zf	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq946sue004ke8mszj7sh7vk", "automationLevel": 1}	2026-06-11 06:26:22.216
cmq948335004me8mshvdqj9ds	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq946sue004ke8mszj7sh7vk"}	2026-06-11 06:27:22.145
cmq94834d004oe8mswsmwavrx	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq946sue004ke8mszj7sh7vk"}	2026-06-11 06:27:22.189
cmq949del004qe8msirg86cja	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq949dei004pe8msjq94k0bg", "automationLevel": 1}	2026-06-11 06:28:22.173
cmq94anva004ue8msfvjbboff	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq949dei004pe8msjq94k0bg"}	2026-06-11 06:29:22.39
cmq94anwx004we8msi2haq2st	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq949dei004pe8msjq94k0bg"}	2026-06-11 06:29:22.449
cmq94by0q004ye8msp4836z5x	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq94by0n004xe8mspet4wex8", "automationLevel": 1}	2026-06-11 06:30:22.202
cmq94d8cb004ze8mse6cdr6tk	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq94by0n004xe8mspet4wex8"}	2026-06-11 06:31:22.235
cmq94d8dh0051e8msqdwsy1by	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq94by0n004xe8mspet4wex8"}	2026-06-11 06:31:22.277
cmq94eiml0053e8msmjoe877v	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq94eimj0052e8msk0ku724g", "automationLevel": 1}	2026-06-11 06:32:22.221
cmq94ft0k0054e8mskrwji2j7	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq94eimj0052e8msk0ku724g"}	2026-06-11 06:33:22.34
cmq94ft1q0056e8msozly4oo2	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq94eimj0052e8msk0ku724g"}	2026-06-11 06:33:22.382
cmq94h3ee005be8msj89gzvap	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq94h3e9005ae8mslnd3dzva", "automationLevel": 1}	2026-06-11 06:34:22.454
cmq94idnw005ce8msoffbytj9	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq94h3e9005ae8mslnd3dzva"}	2026-06-11 06:35:22.412
cmq94idqn005ee8mswfkbun8e	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq94h3e9005ae8mslnd3dzva"}	2026-06-11 06:35:22.511
cmq94jnwv005ge8ms1qgpeavx	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq94jnwr005fe8mszyt44xdp", "automationLevel": 1}	2026-06-11 06:36:22.351
cmq94ky82005he8ms70mkgnz0	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq94jnwr005fe8mszyt44xdp"}	2026-06-11 06:37:22.37
cmq94ky98005je8msykqiaf1s	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq94jnwr005fe8mszyt44xdp"}	2026-06-11 06:37:22.412
cmq94m8hu005le8msbitmcqq4	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq94m8hs005ke8mscu22r9pb", "automationLevel": 1}	2026-06-11 06:38:22.338
cmq94nj0g005pe8msgx7lt5e5	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq94m8hs005ke8mscu22r9pb"}	2026-06-11 06:39:22.624
cmq94nj1y005re8ms2z1q51no	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq94m8hs005ke8mscu22r9pb"}	2026-06-11 06:39:22.678
cmq94ot4i005te8ms7yf0dzhd	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq94ot4e005se8msudgq7bro", "automationLevel": 1}	2026-06-11 06:40:22.386
cmq94q3d9005ue8msxqknqymz	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq94ot4e005se8msudgq7bro"}	2026-06-11 06:41:22.317
cmq94q3ee005we8msr5rf3w27	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq94ot4e005se8msudgq7bro"}	2026-06-11 06:41:22.358
cmq94rdso005ye8ms1nyrn7ee	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq94rdsl005xe8mst2cxqjnv", "automationLevel": 1}	2026-06-11 06:42:22.488
cmq94so26005ze8msxei2n3hd	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq94rdsl005xe8mst2cxqjnv"}	2026-06-11 06:43:22.446
cmq94so3a0061e8mszt27ur6t	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq94rdsl005xe8mst2cxqjnv"}	2026-06-11 06:43:22.486
cmq94tyjk0066e8msmz2v1mx3	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq94tyjh0065e8ms7zx1gm2f", "automationLevel": 1}	2026-06-11 06:44:22.688
cmq94v8no0067e8mscm6gtmty	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq94tyjh0065e8ms7zx1gm2f"}	2026-06-11 06:45:22.452
cmq94v8oy0069e8mscw0ab5y4	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq94tyjh0065e8ms7zx1gm2f"}	2026-06-11 06:45:22.498
cmq94wj15006be8msr3jftz2r	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq94wj13006ae8msdeaxlhro", "automationLevel": 1}	2026-06-11 06:46:22.553
cmq94xta2006ce8mstzgq4tpm	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq94wj13006ae8msdeaxlhro"}	2026-06-11 06:47:22.49
cmq94xtbh006ee8msuls3aky6	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq94wj13006ae8msdeaxlhro"}	2026-06-11 06:47:22.541
cmq94z3j4006ge8msue5fekoi	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq94z3j2006fe8ms12yu7eka", "automationLevel": 1}	2026-06-11 06:48:22.432
cmq950e2n006le8msnlhji2sy	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq94z3j2006fe8ms12yu7eka"}	2026-06-11 06:49:22.751
cmq950e3z006ne8msy6uwqjmx	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "ssh_failed: tmux session 'claude' not found.", "cycleId": "cmq94z3j2006fe8ms12yu7eka"}	2026-06-11 06:49:22.799
cmq950ylk006pe8msa362sqjo	task	cmq950yl4006oe8ms8awk8aj6	task.created	user	{"title": "Code review: WorkerAI", "status": "pending", "priority": "P2", "taskType": "review", "projectId": "cmq6ldsxs0000mm5uuxbgs1s8", "templateId": "cmq8dvpw4000m0xnw7g2e16a8", "fromTemplate": "Code Review"}	2026-06-11 06:49:49.352
cmq951opb006re8ms8s1k0xdf	task	cmq8vu63200160xmsftpfjjtx	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-11 06:50:23.183
cmq951oq3006te8ms19ls3f9g	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq951oq0006se8msn8k95rpx", "automationLevel": 1}	2026-06-11 06:50:23.211
cmq952yis006we8ms2hdosrfa	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq951oq0006se8msn8k95rpx"}	2026-06-11 06:51:22.564
cmq952yja006ye8msc5lxb203	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq951oq0006se8msn8k95rpx"}	2026-06-11 06:51:22.582
cmq9548wh0071e8mspiv41oih	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq9548we0070e8msf5v8ks6v", "automationLevel": 1}	2026-06-11 06:52:22.673
cmq955j500073e8msgvr25ye4	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq9548we0070e8msf5v8ks6v"}	2026-06-11 06:53:22.596
cmq955j5g0075e8ms8jtcy4kl	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq9548we0070e8msf5v8ks6v"}	2026-06-11 06:53:22.612
cmq956tw2007ae8msh4v288km	task	cmq8vtryv00100xmsjp3bvgo3	task.dispatched	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "session": "claude-agent-1"}	2026-06-11 06:54:23.186
cmq956u71007fe8msoiqpno1m	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq956u6v007ee8mslyx8o9hl", "automationLevel": 1}	2026-06-11 06:54:23.581
cmq9588ap007ge8mso19727tt	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq956u6v007ee8mslyx8o9hl"}	2026-06-11 06:55:28.513
cmq9588bu007ie8ms8p4vi7fn	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq956u6v007ee8mslyx8o9hl"}	2026-06-11 06:55:28.554
cmq959e4e007je8msx7xxkpr3	task	cmq8vu63200160xmsftpfjjtx	task.completed	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "detectedBy": "idle fallback (no marker after 6m)"}	2026-06-11 06:56:22.72
cmq959ekb007le8ms914ixi4y	task	cmq8vu64700180xmsprc9twqh	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-11 06:56:23.291
cmq959el5007ne8mst2tb7u5n	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq959el1007me8msfx347s6z", "automationLevel": 1}	2026-06-11 06:56:23.321
cmq95aobl007oe8mswfj3qmrm	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq959el1007me8msfx347s6z"}	2026-06-11 06:57:22.593
cmq95aoca007qe8msprqpqp8i	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.failed	system	{"error": "server_busy", "cycleId": "cmq959el1007me8msfx347s6z"}	2026-06-11 06:57:22.618
cmq95cgq300025i5u9fukxxqp	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.started	system	{"cycleId": "cmq95cgpw00015i5u0c73o3tt", "automationLevel": 1}	2026-06-11 06:58:46.059
cmq95e6vt0000o25u0njw5z9t	task	cmq8vtryv00100xmsjp3bvgo3	task.completed	poller	{"agentId": "cmq6w5d940000525uus1ckhga", "detectedBy": "idle fallback (no marker after 6m)"}	2026-06-11 07:00:06.638
cmq95e7ci0002o25u10a5gfq9	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq95cgpw00015i5u0c73o3tt"}	2026-06-11 07:00:07.218
cmq95f83p0004o25uji5y5on4	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq95cgpw00015i5u0c73o3tt"}	2026-06-11 07:00:54.853
cmq95i98g0001wc5uqnn9tbpd	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq95cgpw00015i5u0c73o3tt"}	2026-06-11 07:03:16.288
cmq95iq500003wc5uva6vcls0	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq95cgpw00015i5u0c73o3tt"}	2026-06-11 07:03:38.196
cmq95k2bu0005wc5upmfendof	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq95cgpw00015i5u0c73o3tt"}	2026-06-11 07:04:40.65
cmq95ldyz0007wc5ufwq5wu1k	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq95cgpw00015i5u0c73o3tt"}	2026-06-11 07:05:42.395
cmq95mqe9000cwc5u1iv5zlxc	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq95cgpw00015i5u0c73o3tt"}	2026-06-11 07:06:45.153
cmq95nyjk000ewc5uvi6tyf8e	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq95cgpw00015i5u0c73o3tt"}	2026-06-11 07:07:42.368
cmq95sgeu0001el5ujctkxjke	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq95cgpw00015i5u0c73o3tt"}	2026-06-11 07:11:12.15
cmq95teg90003el5ufbyjgle3	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq95cgpw00015i5u0c73o3tt"}	2026-06-11 07:11:56.265
cmq95tvhb0000hz5um1xt170r	task	cmq8vu64700180xmsprc9twqh	task.completed	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "detectedBy": "idle fallback (no marker after 16m)"}	2026-06-11 07:12:18.34
cmq95tw0i0002hz5uadiprowx	task	cmq8vud7c001a0xmsat6b7ywk	task.dispatched	poller	{"agentId": "cmq6wcl430001525urn13fvcx", "session": "claude-agent-2"}	2026-06-11 07:12:19.026
cmq95tw5q0004hz5u2wkuq41f	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq95cgpw00015i5u0c73o3tt"}	2026-06-11 07:12:19.214
cmq95uote0005el5u6jddeebs	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq95cgpw00015i5u0c73o3tt"}	2026-06-11 07:12:56.354
cmq95vz210007el5ujnt2dssq	project	cmq6ldsxs0000mm5uuxbgs1s8	improvement_cycle.scanning	system	{"cycleId": "cmq95cgpw00015i5u0c73o3tt"}	2026-06-11 07:13:56.281
\.


--
-- TOC entry 3797 (class 0 OID 16634)
-- Dependencies: 219
-- Data for Name: DailyReport; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."DailyReport" (id, date, "completedCount", "failedCount", "runningCount", "pendingCount", "reportText", "topProjectId", "topProjectName", "createdAt", "queuedCount", "retriedCount", "timedOutCount", "recoveryCount", "avgExecutionMinutes", "activeServerCount", "activeAgentCount", "generatedBy", "periodStart", "periodEnd") FROM stdin;
cmq6qp22z00040xlay4aimtha	2026-06-09 14:33:06.978	3	0	1	5	# Daily Report — Tue Jun 09 2026\n\n## Completed Today\n- [WorkerAI] [TICKET-001] 60-Second Poller Makes Sequential SSH Calls for All Servers — No Parallelism\n- [WorkerAI] Tasks monitor by system\n- [WorkerAI] Add Project Info into the Claude prompt\n\n## Currently Running\n- [WorkerAI] [TICKET-002] Missing E2E Tests for Core User Workflows\n\n## Failed Today\nNone\n\n## Recommended Next Tasks\n- [P1] [WorkerAI] [TICKET-001] Arbitrary Command Execution via /api/servers/[id]/exec with No Safety Net\n- [P1] [WorkerAI] [TICKET-001] Race Condition: Simultaneous Task Dispatches Can Send Multiple Tasks to One Claude Session\n- [P1] [WorkerAI] [TICKET-001] Task Status Endpoint Accepts Any Arbitrary String as Status\n- [P1] [WorkerAI] [TICKET-001] No Authentication or Authorization on Any Endpoint\n- [P1] [WorkerAI] [TICKET-001] Review Endpoint Sends Prompt to Claude During Potentially Active Task Execution\n\n## Highest Priority Project Tomorrow\nWorkerAI (P1)\n	cmq6ldsxs0000mm5uuxbgs1s8	WorkerAI	2026-06-09 14:33:07.019	0	0	0	0	\N	0	0	manual	\N	\N
cmq6qpxwq00080xla5giz7cn7	2026-06-09 14:33:48.246	3	0	1	5	# Daily Report — Tue Jun 09 2026\n\n## Completed Today\n- [WorkerAI] [TICKET-001] 60-Second Poller Makes Sequential SSH Calls for All Servers — No Parallelism\n- [WorkerAI] Tasks monitor by system\n- [WorkerAI] Add Project Info into the Claude prompt\n\n## Currently Running\n- [WorkerAI] [TICKET-002] Missing E2E Tests for Core User Workflows\n\n## Failed Today\nNone\n\n## Recommended Next Tasks\n- [P1] [WorkerAI] [TICKET-001] Race Condition: Simultaneous Task Dispatches Can Send Multiple Tasks to One Claude Session\n- [P1] [WorkerAI] [TICKET-001] Review Endpoint Sends Prompt to Claude During Potentially Active Task Execution\n- [P1] [WorkerAI] [TICKET-001] Task Status Endpoint Accepts Any Arbitrary String as Status\n- [P1] [WorkerAI] [TICKET-001] No Authentication or Authorization on Any Endpoint\n- [P1] [WorkerAI] [TICKET-003] SSH Key Path Stored in Database — Path Traversal / Arbitrary Key Read Risk\n\n## Highest Priority Project Tomorrow\nWorkerAI (P1)\n	cmq6ldsxs0000mm5uuxbgs1s8	WorkerAI	2026-06-09 14:33:48.266	0	0	0	0	\N	0	0	manual	\N	\N
cmq6qqfer000c0xlaxzon5mjd	2026-06-09 14:34:10.939	3	0	1	5	# Daily Report — Tue Jun 09 2026\n\n## Completed Today\n- [WorkerAI] [TICKET-001] 60-Second Poller Makes Sequential SSH Calls for All Servers — No Parallelism\n- [WorkerAI] Tasks monitor by system\n- [WorkerAI] Add Project Info into the Claude prompt\n\n## Currently Running\n- [WorkerAI] [TICKET-002] Missing E2E Tests for Core User Workflows\n\n## Failed Today\nNone\n\n## Recommended Next Tasks\n- [P1] [WorkerAI] [TICKET-001] Race Condition: Simultaneous Task Dispatches Can Send Multiple Tasks to One Claude Session\n- [P1] [WorkerAI] [TICKET-001] Review Endpoint Sends Prompt to Claude During Potentially Active Task Execution\n- [P1] [WorkerAI] [TICKET-001] Task Status Endpoint Accepts Any Arbitrary String as Status\n- [P1] [WorkerAI] [TICKET-001] No Authentication or Authorization on Any Endpoint\n- [P1] [WorkerAI] [TICKET-003] SSH Key Path Stored in Database — Path Traversal / Arbitrary Key Read Risk\n\n## Highest Priority Project Tomorrow\nWorkerAI (P1)\n	cmq6ldsxs0000mm5uuxbgs1s8	WorkerAI	2026-06-09 14:34:10.947	0	0	0	0	\N	0	0	manual	\N	\N
cmq6qy991000h0xla2pwbrqpa	2026-06-09 14:40:16.191	4	0	1	5	# Daily Report — Tue Jun 09 2026\n\n## Completed Today\n- [WorkerAI] [TICKET-001] 60-Second Poller Makes Sequential SSH Calls for All Servers — No Parallelism\n- [WorkerAI] Tasks monitor by system\n- [WorkerAI] [TICKET-002] Missing E2E Tests for Core User Workflows\n- [WorkerAI] Add Project Info into the Claude prompt\n\n## Currently Running\n- [WorkerAI] [TICKET-001] Arbitrary Command Execution via /api/servers/[id]/exec with No Safety Net\n\n## Failed Today\nNone\n\n## Recommended Next Tasks\n- [P1] [WorkerAI] [TICKET-001] Race Condition: Simultaneous Task Dispatches Can Send Multiple Tasks to One Claude Session\n- [P1] [WorkerAI] [TICKET-001] Review Endpoint Sends Prompt to Claude During Potentially Active Task Execution\n- [P1] [WorkerAI] [TICKET-001] Task Status Endpoint Accepts Any Arbitrary String as Status\n- [P1] [WorkerAI] [TICKET-001] No Authentication or Authorization on Any Endpoint\n- [P1] [WorkerAI] [TICKET-003] SSH Key Path Stored in Database — Path Traversal / Arbitrary Key Read Risk\n\n## Highest Priority Project Tomorrow\nWorkerAI (P1)\n	cmq6ldsxs0000mm5uuxbgs1s8	WorkerAI	2026-06-09 14:40:16.213	0	0	0	0	\N	0	0	manual	\N	\N
cmq6rdqtg000n0xlapreotbfh	2026-06-09 14:52:18.799	6	0	1	5	# Daily Report — Tue Jun 09 2026\n\n## Completed Today\n- [WorkerAI] [TICKET-001] 60-Second Poller Makes Sequential SSH Calls for All Servers — No Parallelism\n- [WorkerAI] [TICKET-001] Arbitrary Command Execution via /api/servers/[id]/exec with No Safety Net\n- [WorkerAI] Tasks monitor by system\n- [WorkerAI] [TICKET-002] Missing E2E Tests for Core User Workflows\n- [WorkerAI] [TICKET-002] Zero Tests Exist — No Test Framework Configured\n- [WorkerAI] Add Project Info into the Claude prompt\n\n## Currently Running\n- [WorkerAI] [TICKET-001] No Authentication or Authorization on Any Endpoint\n\n## Failed Today\nNone\n\n## Recommended Next Tasks\n- [P2] [WorkerAI] [TICKET-001] USAGE_THRESHOLD Constant Duplicated Across Three Files\n- [P2] [WorkerAI] [TICKET-001] No Error Handling on Most API Routes — Unhandled Exceptions Return 500 with Stack Traces\n- [P2] [WorkerAI] [TICKET-001] No Input Validation on PUT /api/tasks/[id] — Any Field Can Be Set to Any Value\n- [P2] [WorkerAI] [TICKET-001] WebSocket Server Has No Connection Limit or Per-IP Rate Limit\n- [P2] [WorkerAI] [TICKET-001] No Database Indexes on High-Frequency Query Columns\n\n## Highest Priority Project Tomorrow\nWorkerAI (P1)\n	cmq6ldsxs0000mm5uuxbgs1s8	WorkerAI	2026-06-09 14:52:18.82	0	0	0	0	\N	0	0	manual	\N	\N
cmq7nrebm0000td5udffgfx0a	2026-06-10 05:58:43.5	1	0	1	5	# Daily Report — Wed Jun 10 2026\n\n## Completed Today\n- [WorkerAI] [TICKET-002] Missing Unit Tests for detectClaudeIdle Pane Pattern Matching\n\n## Currently Running\n- [WorkerAI] [TICKET-002] Missing Unit Tests for parseUTCResetTime / extractSection / parseUsage\n\n## Failed Today\nNone\n\n## Recommended Next Tasks\n- [P2] [WorkerAI] [TICKET-001] Completion Detection Is a Fragile Heuristic — False Positives Mark Tasks Complete Prematurely\n- [P2] [WorkerAI] [TICKET-001] WebSocket Server Has No Connection Limit or Per-IP Rate Limit\n- [P2] [WorkerAI] [TICKET-002] Missing Integration Tests for Task State Machine Transitions\n- [P2] [WorkerAI] [TICKET-002] Missing API Route Tests for Input Validation Edge Cases\n- [P2] [WorkerAI] [TICKET-003] WebSocket Origin Check Relaxed Without Security Review Documentation\n\n## Highest Priority Project Tomorrow\nWorkerAI (P1)\n	cmq6ldsxs0000mm5uuxbgs1s8	WorkerAI	2026-06-10 05:58:43.522	0	0	0	0	\N	0	0	manual	\N	\N
cmq8sjtt000890xnwyolzi2sb	2026-06-11 01:00:34.463	0	0	0	0	# Daily Report — Thu, 11 Jun 2026\n\n## Completed Today\nNone\n\n## Currently Running\nNone\n\n## Failed Today\nNone\n\n## Recommended Next Tasks\nNone\n\n## Highest Priority Project Tomorrow\nWorkerAI (P1)\n\n## Infrastructure\nActive Servers: 0 | Active Agents: 2\nAvg Execution: N/A | Timeouts: 0 | Retried: 0 | Recoveries: 0\n	cmq6ldsxs0000mm5uuxbgs1s8	WorkerAI	2026-06-11 01:00:34.596	0	0	0	0	\N	0	2	auto	2026-06-11 00:00:00	2026-06-11 23:59:59.999
cmq8zaoz0004g0xms08ibcax2	2026-06-11 04:09:25.656	9	0	1	5	# Daily Report — Thu, 11 Jun 2026\n\n## Completed Today\n- [WorkerAI] Implement webhook notifications for task completion and failure\n- [WorkerAI] Add WebSocket auto-reconnect with exponential backoff in terminal\n- [WorkerAI] Add task export to CSV and JSON from tasks list page\n- [WorkerAI] Add bulk task operations: multi-select, bulk assign, bulk archive\n- [WorkerAI] Build task dependency DAG visualization on project detail page\n- [WorkerAI] Fix production build: resolve ssh2 / Turbopack incompatibility\n- [WorkerAI] Set up GitHub Actions CI/CD pipeline (lint, unit tests, E2E)\n- [WorkerAI] Fix tmux rate-limit false positive in fetchClaudeUsageViaTmux\n- [WorkerAI] Implement SSH connection pool to eliminate per-request handshake overhead\n\n## Currently Running\n- [WorkerAI] Expand Playwright E2E test suite to cover all major page flows\n\n## Failed Today\nNone\n\n## Recommended Next Tasks\n- [P3] [WorkerAI] Implement time-based scheduled task dispatch (run task at specific datetime)\n- [P3] [WorkerAI] Track actual Claude API cost per execution and surface cost analytics\n- [P3] [WorkerAI] Add docker-compose.yml for one-command local development setup\n- [P3] [WorkerAI] Improve mobile responsiveness: collapsible sidebar, responsive tables\n- [P3] [WorkerAI] Enable improvement cycle automation (level 1) for WorkerAI project\n\n## Highest Priority Project Tomorrow\nWorkerAI (P1)\n\n## Infrastructure\nActive Servers: 0 | Active Agents: 2\nAvg Execution: 8.9m | Timeouts: 0 | Retried: 0 | Recoveries: 0\n	cmq6ldsxs0000mm5uuxbgs1s8	WorkerAI	2026-06-11 04:09:25.74	2	0	0	0	8.9	0	2	manual	2026-06-11 00:00:00	2026-06-11 23:59:59.999
cmq8zap0b004h0xmsgc3vh8x6	2026-06-11 04:09:25.771	9	0	1	5	# Daily Report — Thu, 11 Jun 2026\n\n## Completed Today\n- [WorkerAI] Implement webhook notifications for task completion and failure\n- [WorkerAI] Add WebSocket auto-reconnect with exponential backoff in terminal\n- [WorkerAI] Add task export to CSV and JSON from tasks list page\n- [WorkerAI] Add bulk task operations: multi-select, bulk assign, bulk archive\n- [WorkerAI] Build task dependency DAG visualization on project detail page\n- [WorkerAI] Fix production build: resolve ssh2 / Turbopack incompatibility\n- [WorkerAI] Set up GitHub Actions CI/CD pipeline (lint, unit tests, E2E)\n- [WorkerAI] Fix tmux rate-limit false positive in fetchClaudeUsageViaTmux\n- [WorkerAI] Implement SSH connection pool to eliminate per-request handshake overhead\n\n## Currently Running\n- [WorkerAI] Expand Playwright E2E test suite to cover all major page flows\n\n## Failed Today\nNone\n\n## Recommended Next Tasks\n- [P3] [WorkerAI] Implement time-based scheduled task dispatch (run task at specific datetime)\n- [P3] [WorkerAI] Track actual Claude API cost per execution and surface cost analytics\n- [P3] [WorkerAI] Add docker-compose.yml for one-command local development setup\n- [P3] [WorkerAI] Improve mobile responsiveness: collapsible sidebar, responsive tables\n- [P3] [WorkerAI] Enable improvement cycle automation (level 1) for WorkerAI project\n\n## Highest Priority Project Tomorrow\nWorkerAI (P1)\n\n## Infrastructure\nActive Servers: 0 | Active Agents: 2\nAvg Execution: 8.9m | Timeouts: 0 | Retried: 0 | Recoveries: 0\n	cmq6ldsxs0000mm5uuxbgs1s8	WorkerAI	2026-06-11 04:09:25.787	2	0	0	0	8.9	0	2	manual	2026-06-11 00:00:00	2026-06-11 23:59:59.999
\.


--
-- TOC entry 3811 (class 0 OID 41391)
-- Dependencies: 233
-- Data for Name: DebtItem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."DebtItem" (id, "projectId", title, description, severity, category, status, evidence, "resolvedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 3796 (class 0 OID 16625)
-- Dependencies: 218
-- Data for Name: ExecutionLog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ExecutionLog" (id, "taskId", "startedAt", "finishedAt", status, "logText", "errorMessage", "outputSummary", "createdAt", "failureReason", "retryNumber", "archivedAt", "durationMs", "exitReason", "paneCapture", "searchVector", "actualCostUsd", "tokenCount", "usageSnapshotPct") FROM stdin;
cmq6lfieo0002mm5uawk2b2fs	cmq6lf9l60001mm5ug1mh1nrv	2026-06-09 12:05:43.499	2026-06-09 12:06:16.314	completed	Auto-sent to Claude on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 12:05:43.536	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6lgxkl0003mm5uu897vgz7	cmq6lf9l60001mm5ug1mh1nrv	2026-06-09 12:06:49.841	\N	running	Auto-started from queue on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 12:06:49.846	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6lic800004mm5uxm8fvkhy	cmq6lf9l60001mm5ug1mh1nrv	2026-06-09 12:07:55.483	\N	running	Auto-started from queue on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 12:07:55.488	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6ljipi0005mm5uvwkv68rf	cmq6lf9l60001mm5ug1mh1nrv	2026-06-09 12:08:50.544	2026-06-09 12:09:54.196	completed	Auto-started from queue on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 12:08:50.55	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6lvhhe0007mm5uanz13vya	cmq6lva180006mm5uvbfoz4ny	2026-06-09 12:18:08.82	\N	running	Auto-sent to Claude on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 12:18:08.835	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6ox54u00010xo99fw4pmiu	cmq6m90vq0016mm5u76nppdev	2026-06-09 13:43:24.957	2026-06-09 13:44:24.201	completed	Auto-started from queue on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 13:43:25.001	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6p2wf800030xo954m0b8au	cmq6p2r9300020xo94g6m6o2f	2026-06-09 13:47:53.609	2026-06-09 13:49:54.337	completed	Auto-sent to Claude on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 13:47:53.636	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6p6ssh00050xo9um14o7ay	cmq6m6q38000kmm5u8589hds7	2026-06-09 13:50:55.549	2026-06-09 13:52:56.337	completed	Auto-sent to Claude on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 13:50:55.553	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6pq0tb00000xoacy07l26s	cmq6m6qj7000mmm5u94teogfw	2026-06-09 14:05:52.393	2026-06-09 14:08:53.315	completed	Auto-sent to Claude on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 14:05:52.415	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6pxogv00010xoao1rpgvb5	cmq6p2r9300020xo94g6m6o2f	2026-06-09 14:11:49.66	2026-06-09 14:13:50.343	completed	Sent to Claude on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 14:11:49.663	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6qkff400000xladhhoi7e5	cmq6m76b3000vmm5uu2bc8n96	2026-06-09 14:29:30.999	2026-06-09 14:34:53.837	completed	Auto-sent to Claude on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 14:29:31.024	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6qrd40000d0xla7jknqu7h	cmq6m5wux0009mm5uko31be41	2026-06-09 14:34:54.62	2026-06-09 14:40:53.894	completed	Auto-started from queue on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 14:34:54.624	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6qz2ve000i0xla26tzgq0g	cmq6m74ve000pmm5uakasldu2	2026-06-09 14:40:54.6	2026-06-09 14:47:58.632	completed	Auto-started from queue on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 14:40:54.602	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6r86m1000j0xlae0pe4ukb	cmq6m5wlu0008mm5uzcl07jv6	2026-06-09 14:47:59.35	2026-06-09 14:52:58.701	completed	Auto-started from queue on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 14:47:59.354	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6rem5u000o0xlaovp3svcd	cmq6m5xda000amm5uxzhtzg6n	2026-06-09 14:52:59.44	2026-06-09 15:02:53.863	completed	Auto-started from queue on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 14:52:59.442	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6rrde3000p0xlafjaj6fg8	cmq6m5xlc000bmm5uhz1aobxd	2026-06-09 15:02:54.6	2026-06-09 15:04:53.933	completed	Auto-started from queue on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 15:02:54.603	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6rty2n000q0xlakrkvmt5n	cmq6m5xtg000cmm5upzh1ok64	2026-06-09 15:04:54.716	2026-06-09 15:05:58.641	completed	Auto-started from queue on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 15:04:54.719	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6rvbym000r0xla827o77f3	cmq6m7iqb000wmm5uoopyzxx3	2026-06-09 15:05:59.37	2026-06-09 15:10:53.853	completed	Auto-started from queue on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 15:05:59.374	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6s1nql000s0xla3fs723m6	cmq6m7j8u000ymm5u3g2bh0ei	2026-06-09 15:10:54.568	2026-06-09 15:17:53.915	completed	Auto-started from queue on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 15:10:54.573	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6sanv8000t0xlaguaurmuf	cmq6m6bw1000fmm5u33lzsu35	2026-06-09 15:17:54.64	2026-06-09 15:18:53.814	completed	Auto-started from queue on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 15:17:54.644	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6sby31000u0xla9mei4re6	cmq6m7j0m000xmm5urxlubhyt	2026-06-09 15:18:54.53	2026-06-09 15:45:54.337	completed	Auto-started from queue on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 15:18:54.542	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6taoic000v0xlari6wsnl6	cmq6m6qbg000lmm5uksvqux41	2026-06-09 15:45:55.09	2026-06-09 15:49:54.182	completed	Auto-started from queue on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 15:45:55.096	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6tftk4000w0xlaax2sibx7	cmq6m6cc3000hmm5u15815k2d	2026-06-09 15:49:54.912	2026-06-09 15:53:54.276	completed	Auto-started from queue on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 15:49:54.918	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6uddbw00140xla1yreic6r	cmq6m6bfx000dmm5u3fo0qsrc	2026-06-09 16:16:00.184	2026-06-09 16:18:54.723	completed	Auto-started from queue on server "AWS Worker1" (13.54.210.68) — mode: full_autonomous	\N	\N	2026-06-09 16:16:00.188	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6y2amc00010wnwy5b9nuru	cmq6m6qrc000nmm5ulaczx3ue	2026-06-09 17:59:21.92	2026-06-09 18:33:24.758	completed	Sent to agent "agent-1" (claude-agent-1) on server "AWS Worker1" — mode: full_autonomous	\N	\N	2026-06-09 17:59:21.924	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq6y1viy00000wnwb9uwz18t	cmq6m7kk80012mm5utf9wefme	2026-06-09 17:59:02.341	2026-06-09 18:33:24.789	completed	Sent to agent "agent-2" (claude-agent-2) on server "AWS Worker1" — mode: full_autonomous	\N	\N	2026-06-09 17:59:02.363	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7007mm00020xnwvsqeawyo	cmq6m6qrc000nmm5ulaczx3ue	2026-06-09 18:53:43.96	2026-06-09 19:19:07.989	completed	Sent to agent "agent-2" (claude-agent-2) on server "AWS Worker1" — mode: full_autonomous	\N	\N	2026-06-09 18:53:43.966	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq70wwdk0000vs5u55zuvgbk	cmq6m7kk80012mm5utf9wefme	2026-06-09 19:19:09.018	2026-06-09 19:23:05.283	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-09 19:19:09.032	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq712msq00030xnwugmcnvr2	cmq6m6c43000gmm5uqnod2pta	2026-06-09 19:23:36.549	2026-06-09 19:29:05.37	completed	Auto-sent to agent "agent-2" (claude-agent-2) on server "AWS Worker1"	\N	\N	2026-06-09 19:23:36.554	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq713bey00040xnw6r4vvpr0	cmq6m6bnw000emm5uakgculj4	2026-06-09 19:24:08.454	2026-06-09 19:29:05.377	completed	Auto-sent to agent "agent-1" (claude-agent-1) on server "AWS Worker1"	\N	\N	2026-06-09 19:24:08.458	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7jspgk00060xnwdmbcwwfy	cmq6m75n7000smm5uvi8ucla8	2026-06-10 04:07:46.14	2026-06-10 04:11:16.402	completed	Sent to agent "agent-2" (claude-agent-2) on server "AWS Worker1" — mode: full_autonomous	\N	\N	2026-06-10 04:07:46.148	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7l11lp0000js5u7rvb70gw	cmq6m756a000qmm5u69kjv3na	2026-06-10 04:42:14.74	2026-06-10 06:03:04.25	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 04:42:14.749	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7o2tyj0003td5ubueb4lfb	cmq7o2b6j0002td5utqrl0mgu	2026-06-10 06:07:37.001	2026-06-10 06:15:04.201	completed	Auto-sent to agent "agent-2" (claude-agent-2) on server "AWS Worker1"	\N	\N	2026-06-10 06:07:37.003	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7ocfgu0004td5uoug4hky2	cmq6m6ckd000imm5ux3td3azi	2026-06-10 06:15:04.78	2026-06-10 06:28:26	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 06:15:04.782	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7otm1o00000xo1fjuv029i	cmq6m75v2000tmm5uh9etij1n	2026-06-10 06:28:26.441	\N	running	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 06:28:26.461	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7qfsxl00000xmipqh1zccs	cmq6m75v2000tmm5uh9etij1n	2026-06-10 07:13:41.428	2026-06-10 07:13:56.034	completed	Sent to agent "agent-2" (claude-agent-2) on server "AWS Worker1" — mode: full_autonomous	\N	\N	2026-06-10 07:13:41.433	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7qg4jx00010xmighuaghh4	cmq6m6cs9000jmm5utxsvadki	2026-06-10 07:13:56.485	2026-06-10 07:14:55.95	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 07:13:56.493	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7qhes100020xmiv5bprb2s	cmq6m7jqa000zmm5uorui4n8v	2026-06-10 07:14:56.4	2026-06-10 07:15:55.959	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 07:14:56.401	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7qip2y00030xmiyvv3fldg	cmq6m7k170010mm5uzmbmja58	2026-06-10 07:15:56.41	2026-06-10 07:17:00.203	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 07:15:56.41	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7qk2oq00040xmifjoh4klp	cmq6m8zx40013mm5u211k8k6y	2026-06-10 07:17:00.697	\N	running	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 07:17:00.698	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7s3g3000000xmgh98xxaz3	cmq6m6cs9000jmm5utxsvadki	2026-06-10 08:00:04.107	2026-06-10 08:26:05.128	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 08:00:04.14	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7s6c2500010xmggfusvatz	cmq6tl7wz000x0xlaa48zwz9i	2026-06-10 08:02:18.892	2026-06-10 08:26:05.133	completed	Sent to agent "agent-1" (claude-agent-1) on server "AWS Worker1" — mode: full_autonomous	\N	\N	2026-06-10 08:02:18.893	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7t0x1h0000t35uneestzto	cmq6m7jqa000zmm5uorui4n8v	2026-06-10 08:26:05.758	2026-06-10 08:31:12.685	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 08:26:05.766	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7t9qyi00012l5u5zfefom9	cmq6m75f9000rmm5up1lujvdh	2026-06-10 08:32:57.785	\N	running	Auto-started from queue on agent "agent-1" — mode: full_autonomous	\N	\N	2026-06-10 08:32:57.786	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7t7icz00002l5u9zezlpl7	cmq6m7k170010mm5uzmbmja58	2026-06-10 08:31:13.327	2026-06-10 08:37:01.545	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 08:31:13.331	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7tezsg00022l5uzt0xtgr8	cmq6m8zx40013mm5u211k8k6y	2026-06-10 08:37:02.512	2026-06-10 08:47:30.546	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 08:37:02.512	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7tsgu900000xqrng4gqb1c	cmq6m75f9000rmm5up1lujvdh	2026-06-10 08:47:31.132	2026-06-10 08:53:16.97	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 08:47:31.14	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7tzw3f00010xqrnh57pisj	cmq6m7kb20011mm5u4gjgmbm3	2026-06-10 08:53:17.498	2026-06-10 08:59:16.982	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 08:53:17.499	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7u7lvq00020xqr4ctygnv7	cmq6m90ns0015mm5u5zp5zjwn	2026-06-10 08:59:17.509	2026-06-10 09:09:17.117	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 08:59:17.51	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq7ukgy100030xqrzcaw5045	cmq6m6qzh000omm5u6prv3v1z	2026-06-10 09:09:17.641	2026-06-10 09:15:16.979	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 09:09:17.645	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq803apx0000sm5uc8t6qmfz	cmq801l1z0004p35uz19utqpy	2026-06-10 11:43:54.072	2026-06-10 11:52:46.061	completed	Auto-sent to agent "agent-1" (claude-agent-1) on server "AWS Worker1"	\N	\N	2026-06-10 11:43:54.117	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq80epn60001sm5u29qboyq5	cmq801kq60000p35uw6lst3ro	2026-06-10 11:52:46.673	2026-06-10 11:58:46.046	completed	Auto-started from queue on agent "agent-1" — mode: full_autonomous	\N	\N	2026-06-10 11:52:46.674	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq80mfep0002sm5uwq3tsd5v	cmq801l170001p35uxhm9nigd	2026-06-10 11:58:46.655	2026-06-10 12:04:28.218	completed	Auto-started from queue on agent "agent-1" — mode: full_autonomous	\N	\N	2026-06-10 11:58:46.657	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq80trfv0000fy5ury96fos9	cmq801l1h0002p35uvfsbrex0	2026-06-10 12:04:28.837	2026-06-10 12:09:31.69	completed	Auto-started from queue on agent "agent-1" — mode: full_autonomous	\N	\N	2026-06-10 12:04:28.843	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq80w2zt0001fy5ul6zw3ez9	cmq801l2y0009p35ubjvn4tnh	2026-06-10 12:06:17.128	2026-06-10 12:17:16.224	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 12:06:17.129	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq8109lz0000n75ul52th6v2	cmq801l1t0003p35u42mljvny	2026-06-10 12:09:32.322	2026-06-10 12:18:16.097	completed	Auto-started from queue on agent "agent-1" — mode: full_autonomous	\N	\N	2026-06-10 12:09:32.327	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq81a84v0004n75ulpfsjdfj	cmq801l35000ap35ul2ionidc	2026-06-10 12:17:16.973	2026-06-10 12:26:56.228	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 12:17:16.975	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq81mnl50003qr5uxtfo5uij	cmq801l2j0006p35ur2otynp8	2026-06-10 12:26:56.861	2026-06-10 12:32:56.001	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 12:26:56.873	\N	0	\N	\N	\N	\N	\N	\N	\N	\N
cmq81ud6j0007qr5uxh6iqzas	cmq801l3a000bp35uthvxo7l1	2026-06-10 12:32:56.635	2026-06-10 12:40:55.976	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 12:32:56.635	\N	0	\N	\N	\N	\N	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'full':11 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq83mbv700040xpec8yrlmnn	cmq801l2u0008p35u5fkgy43k	2026-06-10 13:22:40.91	2026-06-10 13:28:19.625	completed	Auto-sent to agent "agent-1" (claude-agent-1) on server "AWS Worker1"	\N	\N	2026-06-10 13:22:40.915	\N	0	\N	338715	idle_fallback	0pm (UTC)\n\n✻ Crunched for 0s\n\n────────────────────────────────────────────────────────────────────────────────\n❯ exit\n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle)\n         ✘ Auto-update failed: no write permission to npm prefix · Run /doctor\n                                                              ● high · /effort\n\nResume this session with:\nclaude --resume de892695-c702-4e89-b277-491ff6025b17\n[ec2-user@ip-172-31-23-229 ~]$ HOME=/home/ec2-user/claude-agents/agent-1 claude\n--dangerously-skip-permissions\n ▐▛███▜▌   Claude Code v2.1.169\n▝▜█████▛▘  Sonnet 4.6 · Claude Pro\n  ▘▘ ▝▝    /home/ec2-user\n\n   Fable 5 is now available with the latest version of Claude Code! Run "claude\n   update" to update to v2.1.170+\n\n❯ /usage\n\n────────────────────────────────────────────────────────────────────────────────\n  Settings  Status   Config   Usage   Stats\n\n  Session\n\n  Total cost:            $0.0000\n  Total duration (API):  0s\n  Total duration (wall): 21s\n  Total code changes:    0 lines added, 0 lines removed\n  Usage:                 0 input, 0 output, 0 cache read, 0 cache write\n\n  Current session\n  ██████████████████████████████████████████████████ 100% used\n  Resets 3:50pm (UTC)\n\n  Current week (all models)\n  ██████████                                         20% used\n ▐▛███▜▌   Claude Code v2.1.169\n▝▜█████▛▘  Sonnet 4.6 · Claude Pro\n  ▘▘ ▝▝    /home/ec2-user\n\n   Fable 5 is now available with the latest version of Claude Code! Run "claude\n   update" to update to v2.1.170+\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents\n         ✘ Auto-update failed: no write permission to npm prefix · Run /doctor\n                                                              ● high · /effort	'-1':7 '1':11 'agent':5,6,10 'auto':2 'auto-s':1 'aw':14 'claud':9 'claude-ag':8 'fallback':17 'idl':16 'sent':3 'server':13 'worker1':15	\N	\N	\N
cmq83tlmz000c0xpe7rh1y725	cmq801l250005p35u91238dex	2026-06-10 13:28:20.17	2026-06-10 14:30:15.714	failed	Auto-started from queue on agent "agent-1" — mode: full_autonomous	Zombie task: no progress for 31min — auto-failed	\N	2026-06-10 13:28:20.171	\N	0	\N	\N	\N	\N	'-1':9 '31min':18 'agent':7,8 'auto':2,20 'auto-fail':19 'auto-start':1 'autonom':12 'fail':21 'full':11 'mode':10 'progress':16 'queue':5 'start':3 'task':14 'zombi':13	\N	\N	\N
cmq86o4c70001lt5u6m5g9rt7	cmq801l2p0007p35ubbze322d	2026-06-10 14:48:03.317	2026-06-10 14:54:02.652	completed	Auto-started from queue on agent "agent-1" — mode: full_autonomous	\N	\N	2026-06-10 14:48:03.32	\N	0	\N	359335	idle_fallback	log dismissed\n\n❯ /usage\n\n────────────────────────────────────────────────────────────────────────────────\n  Settings  Status   Config   Usage   Stats\n\n  Session\n\n  Total cost:            $0.0000\n  Total duration (API):  0s\n  Total duration (wall): 4m 25s\n  Total code changes:    0 lines added, 0 lines removed\n  Usage:                 0 input, 0 output, 0 cache read, 0 cache write\n\n  Current session\n  ██████████████████████████████████████████████████ 100% used\n  Resets 3:50pm (UTC)\n\n  Current week (all models)\n  ██████████                                         20% used\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n\n────────────────────────────────────────────────────────────────────────────────\n  Settings  Status   Config   Usage   Stats\n\n  Session\n\n  Total cost:            $0.0000\n  Total duration (API):  0s\n  Total duration (wall): 5m 25s\n  Total code changes:    0 lines added, 0 lines removed\n  Usage:                 0 input, 0 output, 0 cache read, 0 cache write\n\n  Current session\n  ██████████████████████████████████████████████████ 100% used\n  Resets 3:50pm (UTC)\n\n  Current week (all models)\n  ██████████                                         20% used\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents\n         ✘ Auto-update failed: no write permission to npm prefix · Run /doctor\n                                                              ● high · /effort	'-1':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq88yk71001cpw5uh5nfa258	cmq801l2u0008p35u5fkgy43k	2026-06-10 15:52:09.649	2026-06-10 15:58:08.981	completed	Auto-started from queue on agent "agent-1" — mode: full_autonomous	\N	\N	2026-06-10 15:52:09.661	\N	0	\N	359332	idle_fallback	che read, 0 cache write\n  ($0.0009)\n     claude-sonnet-4-6:  394 input, 11.3k output, 2.4m cache read, 60.9k cache\n  write ($1.12)\n\n  What's contributing to your limits usage?\n  Approximate, based on local sessions on this machine — does not include\n  other devices or claude.ai\n\n  app/_components/TaskDetailPanel.tsx: extended ServerOption with capacity\n  fields and appended · XX% cap to each server in the assignment dropdown.\n\n  [WORKERAI_RESULT]\n  taskId: cmq801l2u0008p35u5fkgy43k\n  status: completed\n  nonce: e9fc89bc-7d5d-4b2e-a4ed-37b76fa639ed\n  [/WORKERAI_RESULT]\n\n✻ Brewed for 4m 16s\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n\n────────────────────────────────────────────────────────────────────────────────\n  Settings  Status   Config   Usage   Stats\n\n  Session\n\n  Total cost:            $1.12\n  Total duration (API):  3m 43s\n  Total duration (wall): 6m 51s\n  Total code changes:    236 lines added, 2 lines removed\n  Usage by model:\n      claude-haiku-4-5:  871 input, 14 output, 0 cache read, 0 cache write\n  ($0.0009)\n     claude-sonnet-4-6:  394 input, 11.3k output, 2.4m cache read, 60.9k cache\n  write ($1.12)\n\n  What's contributing to your limits usage?\n  Approximate, based on local sessions on this machine — does not include\n  other devices or claude.ai\n\n  [WORKERAI_RESULT]\n  taskId: cmq801l2u0008p35u5fkgy43k\n  status: completed\n  nonce: e9fc89bc-7d5d-4b2e-a4ed-37b76fa639ed\n  [/WORKERAI_RESULT]\n\n✻ Brewed for 4m 16s\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents\n         ✘ Auto-update failed: no write permission to npm prefix · Run /doctor\n                                                              ● high · /effort	'-1':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq896a3f001mpw5uzlecadqf	cmq801l3f000cp35usrt9i0zy	2026-06-10 15:58:09.818	2026-06-10 16:04:19.799	completed	Auto-started from queue on agent "agent-1" — mode: full_autonomous	\N	\N	2026-06-10 15:58:09.819	\N	0	\N	369981	idle_fallback	 template picker → variable form → live\n  preview → creates task.\n  - Nav.tsx — "Templates" link added.\n  - projects/[id]/page.tsx — "From Template" button opens modal pre-seeded with\n  the project ID.\n  - tasks/page.tsx — "From Template" button with project picker step (skipped\n  when only one project).\n\n  [WORKERAI_RESULT]\n  taskId: cmq801l3f000cp35usrt9i0zy\n  status: completed\n  nonce: aa690311-7e70-4840-8d2d-d034ee349bc0\n  [/WORKERAI_RESULT]\n\n✻ Worked for 5m 12s\n\n❯ /usage\n\n────────────────────────────────────────────────────────────────────────────────\n  Settings  Status   Config   Usage   Stats\n\n  Session\n\n  Total cost:            $3.03\n  Total duration (API):  8m 29s\n  Total duration (wall): 13m 2s\n  Total code changes:    1178 lines added, 8 lines removed\n  Usage by model:\n      claude-haiku-4-5:  871 input, 14 output, 0 cache read, 0 cache write\n  ($0.0009)\n     claude-sonnet-4-6:  786 input, 29.3k output, 6.7m cache read, 151.0k\n  cache write ($3.03)\n\n  Current session\n  ██████▌                                            13% used\n  Resets 8:50pm (UTC)\n\n  Current week (all models)\n  ███████████                                        22% used\n  - Nav.tsx — "Templates" link added.\n  - projects/[id]/page.tsx — "From Template" button opens modal pre-seeded with\n  the project ID.\n  - tasks/page.tsx — "From Template" button with project picker step (skipped\n  when only one project).\n\n  [WORKERAI_RESULT]\n  taskId: cmq801l3f000cp35usrt9i0zy\n  status: completed\n  nonce: aa690311-7e70-4840-8d2d-d034ee349bc0\n  [/WORKERAI_RESULT]\n\n✻ Worked for 5m 12s\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents\n         ✘ Auto-update failed: no write permission to npm prefix · Run /doctor\n                                                              ● high · /effort	'-1':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq89k05s00056c5uy83g10cz	cmq801l3k000dp35uluceb7un	2026-06-10 16:08:50.109	\N	running	Auto-sent to agent "agent-1" (claude-agent-1) on server "AWS Worker1"	\N	\N	2026-06-10 16:08:50.128	\N	0	\N	\N	\N	\N	'-1':7 '1':11 'agent':5,6,10 'auto':2 'auto-s':1 'aw':14 'claud':9 'claude-ag':8 'sent':3 'server':13 'worker1':15	\N	\N	\N
cmq89o64800096c5uzl4wlivy	cmq801l3k000dp35uluceb7un	2026-06-10 16:12:04.472	2026-06-10 16:20:03.866	completed	Auto-started from queue on agent "agent-1" — mode: full_autonomous	\N	\N	2026-06-10 16:12:04.472	\N	0	\N	479394	idle_fallback	s/daily/page.tsx): Extended stat grid with\n  queued/timed-out/retried/avg-exec cards; "Auto" badge on auto-generated\n  reports in both the history sidebar and the detail header.\n\n  Dashboard (app/dashboard/page.tsx): New "Today's Report" widget showing 6\n  metrics with an "Auto" badge; links to the full reports page; gracefully\n  hidden while loading.\n\n  [WORKERAI_RESULT]\n  taskId: cmq801l3k000dp35uluceb7un\n  status: completed\n  nonce: 1392cd93-d686-4d8a-b60f-02656b854066\n  [/WORKERAI_RESULT]\n\n✻ Cooked for 2m 19s\n\n❯ /usage\n\n────────────────────────────────────────────────────────────────────────────────\n  Settings  Status   Config   Usage   Stats\n\n  Session\n\n  Total cost:            $1.55\n  Total duration (API):  4m 51s\n  Total duration (wall): 8m 7s\n  Total code changes:    396 lines added, 108 lines removed\n  Usage by model:\n      claude-haiku-4-5:  859 input, 15 output, 0 cache read, 0 cache write\n  ($0.0009)\n     claude-sonnet-4-6:  402 input, 16.8k output, 2.9m cache read, 118.5k\n  cache write ($1.55)\n\n  What's contributing to your limits usage?\n  Approximate, based on local sessions on this machine — does not include\n  other devices or claude.ai\n\n  reports in both the history sidebar and the detail header.\n\n  Dashboard (app/dashboard/page.tsx): New "Today's Report" widget showing 6\n  metrics with an "Auto" badge; links to the full reports page; gracefully\n  hidden while loading.\n\n  [WORKERAI_RESULT]\n  taskId: cmq801l3k000dp35uluceb7un\n  status: completed\n  nonce: 1392cd93-d686-4d8a-b60f-02656b854066\n  [/WORKERAI_RESULT]\n\n✻ Cooked for 2m 19s\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents\n         ✘ Auto-update failed: no write permission to npm prefix · Run /doctor\n                                                              ● high · /effort	'-1':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8diocx00000xnwvtix9y2a	cmq801l3p000ep35u17l9fnsv	2026-06-10 17:59:46.633	2026-06-10 18:05:32.216	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 17:59:46.643	\N	0	\N	345583	idle_fallback	not app-level loops).\n  UI: /analytics page with completion bar chart, failure rate trend, duration\n  trend, KPI summary cards.\n  </task_description>\n\n  Complete this task now.\n\n  When you have fully completed the task, output this exact completion block\n  (no surrounding text; each field on its own line):\n\n  [WORKERAI_RESULT]\n  taskId: cmq801l3p000ep35u17l9fnsv\n  status: completed\n  nonce: 4c0b97a8-c1a6-4764-a652-13239b2b8267\n  [/WORKERAI_RESULT]\n  ⎿  You've hit your session limit · resets 7:10pm (UTC)\n\n✻ Churned for 0s\n                                                               ● high · /effort\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8dq3hb000e0xnwe14yio6p	cmq801l250005p35u91238dex	2026-06-10 18:05:32.83	\N	running	Auto-started from queue on agent "agent-1" — mode: full_autonomous	\N	\N	2026-06-10 18:05:32.831	\N	0	\N	\N	\N	\N	'-1':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'full':11 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8dwiy1000s0xnwsnn57d0t	cmq801l3p000ep35u17l9fnsv	2026-06-10 18:10:32.808	2026-06-10 18:18:32.239	completed	Auto-started from queue on agent "agent-1" — mode: full_autonomous	\N	\N	2026-06-10 18:10:32.809	\N	0	\N	479431	idle_fallback	 Config   Usage   Stats\n\n  Session\n\n  Total cost:            $1.26\n\n  DB — Added WeeklyAnalytics model with all required metric fields (weekStart unique index), migrated.\n\n  Service (lib/weekly-analytics-service.ts) — computeWeekAnalytics() uses a single $queryRaw with percentile_cont(0.5) and percentile_cont(0.95) for p50/p95;\n  parallel subqueries for all 12 counters from ExecutionLog, Task, AuditEvent, and RecoveryLog. generateWeeklyAnalytics() upserts the record.\n\n  API routes:\n  - GET /api/analytics/weekly — last 12 weeks\n  - POST /api/analytics/weekly — compute prior week on demand\n  - GET /api/analytics/weekly/[weekStart] — specific week by date\n  - GET /api/analytics/summary — rolling 30-day KPIs with completion rate and review pass rate\n\n  Scheduler (instrumentation.node.ts) — runWeeklyAnalyticsIfNeeded() fires on Monday at or after 1 AM UTC, once per calendar week, guarded by\n  globalThis._lastWeeklyAnalyticsDate.\n\n  UI (/analytics) — KPI summary cards (12 metrics including completion rate and review pass rate), SVG bar chart (task completion), SVG line chart (failure\n  trends), SVG line chart (p50/p95/avg duration), nav link added.\n\n  [WORKERAI_RESULT]\n  taskId: cmq801l3p000ep35u17l9fnsv\n  status: completed\n  nonce: 4b0c31e0-01f7-4a12-928d-13a59e44bc27\n  [/WORKERAI_RESULT]\n\n✻ Crunched for 7m 43s\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────\n❯ \n─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents                        ✘ Auto-update failed: no write permission to npm prefix · Run /doctor\n                                                                                                                                           ● high · /effort	'-1':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8e6tea000z0xnwi7v2wrm4	cmq801l250005p35u91238dex	2026-06-10 18:18:32.913	2026-06-10 18:24:32.068	completed	Auto-started from queue on agent "agent-1" — mode: full_autonomous	\N	\N	2026-06-10 18:18:32.914	\N	0	\N	359155	idle_fallback	────────────────────────────────────────────────────────────────────────\n  Settings  Status   Config   Usage   Stats\n\n  Session\n\n  Total cost:            $2.42\n\n  Service (lib/task-dependency.ts) — addDependency() with iterative DFS cycle detection (returns "cycle" 409-ready), increments blockedByCount only for\n  non-complete prerequisites. removeDependency() decrements if the removed prereq was still blocking. unblockDependents() decrements all direct dependents\n  and auto-advances to queued any that reach 0 and have an assigned server/agent.\n\n  API routes:\n  - GET /api/tasks/[id]/dependencies — returns { prerequisites, dependents }\n  - POST /api/tasks/[id]/dependencies — adds edge, returns 409 on cycle or duplicate, 400 on self-reference\n  - DELETE /api/tasks/[id]/dependencies/[depId] — removes edge, 204 on success\n\n  Scheduler — unblockDependents() called after every server-direct and agent task completion in the poller, and after the check-completion API route marks a\n  task done.\n\n  Queue advance — Both findFirst calls in the poller now include blockedByCount: 0 so blocked tasks are never dispatched.\n\n  [WORKERAI_RESULT]\n  taskId: cmq801l250005p35u91238dex\n  status: completed\n  nonce: cb25ab3f-b594-4b75-811d-67630f247e98\n  [/WORKERAI_RESULT]\n\n✻ Baked for 4m 15s\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────\n❯ \n─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents                        ✘ Auto-update failed: no write permission to npm prefix · Run /doctor\n                                                                                                                                           ● high · /effort	'-1':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8g1llo00200xnwnjk85kgx	cmq801l3t000fp35uph6q5drr	2026-06-10 19:10:28.763	2026-06-10 19:16:32.603	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 19:10:28.764	\N	0	\N	363840	idle_fallback	Ran 1 shell command\n\n● TypeScript compiles cleanly. Now let me verify the migration was applied\n  correctly and check the Nav to confirm the analytics link is present:\n\n  Read 1 file\n  ⎿  Interrupted · What should Claude do instead?\n\n❯ HOME=/home/ec2-user/claude-agents/agent-2 claude\n  --dangerously-skip-permissions\n  /usage/usage\n\n  Ran 1 shell command\n\n● How is Claude doing this session? (optional)\n  1: Bad    2: Fine   3: Good   0: Dismiss\n          ✘ Auto-update failed: no write permission to npm prefix · Run /doctor\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8g9er900260xnweiunqrjz	cmq801l48000gp35upcewu3fv	2026-06-10 19:16:33.141	2026-06-10 19:22:28.373	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 19:16:33.141	\N	0	\N	355232	idle_fallback	- POST /api/projects/[id]/scan (body: { scanType, serverId })\n  - GET /api/projects/[id]/scans (last 20 scans for project)\n  - GET /api/project-scans/[id]\n  - PUT /api/projects/[id] now accepts autoScanEnabled and scanFrequencyDays\n\n  Scheduler (instrumentation.node.ts step 12): runProjectScansIfNeeded() runs\n  daily at 2 AM UTC, guarded by _lastProjectScanDate\n\n  [WORKERAI_RESULT]\n  taskId: cmq801l48000gp35upcewu3fv\n  status: completed\n  nonce: 87e95994-74c0-4924-911a-b72fc2726f6b\n  [/WORKERAI_RESULT]\n\n✻ Baked for 3m 37s\n\n● How is Claude doing this session? (optional)\n  1: Bad    2: Fine   3: Good   0: Dismiss\n                                                               ● high · /effort\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8gh19h002c0xnwcg9upb4e	cmq801l4b000hp35u6q21s4je	2026-06-10 19:22:28.901	2026-06-10 19:28:28.464	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 19:22:28.901	\N	0	\N	359563	idle_fallback	- Severity-coloured cards (critical=red border, high=orange, medium=amber,\n  low=zinc)\n  - Status/severity filters\n  - "Status" button to update debt item status via modal\n  - "Create Task" button to create a maintenance task linked to the debt item\n  - "Run Debt Scan" modal with server picker\n  - 8-week open debt trend sparkline chart\n\n  [WORKERAI_RESULT]\n  taskId: cmq801l4b000hp35u6q21s4je\n  status: completed\n  nonce: 437a99f0-68c2-44ef-8878-6c2a51fac30a\n  [/WORKERAI_RESULT]\n\n✻ Sautéed for 5m 14s\n\n● How is Claude doing this session? (optional)\n  1: Bad    2: Fine   3: Good   0: Dismiss\n                                                          8% until auto-compact\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8gor40002i0xnw13qad7vv	cmq801l4i000jp35uipdtjawc	2026-06-10 19:28:28.991	2026-06-10 19:41:32.843	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-10 19:28:28.992	\N	0	\N	783852	idle_fallback	- `GET /api/improvement-cycles/[id]` — get single cycle with project info\n  - `POST /api/improvement-cycles/[id]/approve` — approve awaiting_approval\n  cycle\n  - `POST /api/improvement-cycles/[id]/cancel` — cancel any active cycle\n\n  **Project settings**: `PUT /api/projects/[id]` now accepts\n  `improvementAutomationLevel` (0–3, clamped) and `cycleFrequencyDays` (min 1)\n\n  **Poller** (`instrumentation.node.ts`): Step 13 calls\n  `advanceImprovementCycles()` then `startDueImprovementCycles()` every 60s tick\n\n  TypeScript: zero errors (`npx tsc --noEmit` clean)\n  [/WORKERAI_RESULT]\n\n✻ Crunched for 12m 17s\n\n● How is Claude doing this session? (optional)\n  1: Bad    2: Fine   3: Good   0: Dismiss\n                                                               ● high · /effort\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8jz3oj00460xnwizf52ebt	cmq801l4f000ip35ubcwhnamd	2026-06-10 21:00:30.69	2026-06-10 21:07:34.48	completed	Auto-started from queue on agent "agent-1" — mode: full_autonomous	\N	\N	2026-06-10 21:00:30.691	\N	0	\N	423790	idle_fallback	\n  Session\n\n  Total cost:            $5.23\n  suggestions relation on Project. Migrated.\n\n  Service (lib/suggestion-service.ts) — generateSuggestionsFromScan() (cap 10, de-dupes by title), generateSuggestionFromDebt() (de-dupes by sourceId +\n  title), generateSuggestionsForProject() (manual trigger, combines scan + debt), approveSuggestion() (creates Task in transaction), rejectSuggestion() (with\n  optional note).\n\n  Hooks — generateSuggestionsFromScan fires after scan completes in project-scan-service.ts; generateSuggestionFromDebt fires on each new debt item created\n  in debt-scan-service.ts.\n\n  API routes — GET /api/projects/[id]/suggestions, POST /api/projects/[id]/generate-suggestions, PUT /api/suggestions/[id] (edit before approving), POST\n  /api/suggestions/[id]/approve, POST /api/suggestions/[id]/reject.\n\n  UI — SuggestionsTab component with approve/reject/edit per-item flows, bulk approve/reject with checkboxes, and a "Generate Suggestions" button. Integrated\n  as a third tab on the project detail page with an amber badge showing pending count.\n\n  [WORKERAI_RESULT]\n  taskId: cmq801l4f000ip35ubcwhnamd\n  status: completed\n  nonce: 91e66938-775a-4f89-a84f-49cbc31b5d56\n  [/WORKERAI_RESULT]\n\n✻ Cogitated for 6m 19s\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n● How is Claude doing this session? (optional)\n  1: Bad    2: Fine   3: Good   0: Dismiss\n\n─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────\n❯ \n─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents                        ✘ Auto-update failed: no write permission to npm prefix · Run /doctor\n                                                                                                                                           ● high · /effort	'-1':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8w20xn001g0xms98pp8g0p	cmq8vrq5y00090xmsgixurzts	2026-06-11 02:38:42.488	\N	running	Auto-sent to agent "agent-1" (claude-agent-1) on server "AWS Worker1"	\N	\N	2026-06-11 02:38:42.491	\N	0	\N	\N	\N	\N	'-1':7 '1':11 'agent':5,6,10 'auto':2 'auto-s':1 'aw':14 'claud':9 'claude-ag':8 'sent':3 'server':13 'worker1':15	\N	\N	\N
cmq8w270x001j0xms3y6cnw9j	cmq8vrq4d00070xmsbohb72sq	2026-06-11 02:38:50.384	2026-06-11 02:46:24.35	completed	Auto-sent to agent "agent-2" (claude-agent-2) on server "AWS Worker1"	\N	\N	2026-06-11 02:38:50.385	\N	0	\N	453966	idle_fallback	omponents/Nav.tsx",".env.example"],"hook_points":["instrumentation.node.ts:629\n  — server-direct task timeout → task.failed","instrumentation.node.ts:722 —\n  server-direct task completion → task.completed","instrumentation.node.ts:901 —\n  agent task timeout → task.failed","instrumentation.node.ts:995 — agent task\n  completion → task.completed","lib/zombie-detection.ts:88 — zombie auto-fail →\n  task.failed","app/api/tasks/[id]/status/route.ts:43 — manual status update to\n  completed/failed"],"features":["HMAC-SHA256 request signing\n  (X-Webhook-Signature header)","Discord webhook auto-detect → rich\n  embeds","Slack webhook auto-detect → block-kit layout","DB config\n  (SystemConfig) with env var fallback","Admin UI: Admin → Notifications with\n  URL input, masked secret, test-fire button, payload reference","POST\n  /api/webhooks/test for live test delivery","All deliveries fire-and-forget —\n  never block the main execution path"],"typescript_errors":0}}\n\n✻ Churned for 7m 21s\n\n● How is Claude doing this session? (optional)\n  1: Bad    2: Fine   3: Good   0: Dismiss\n                                                               ● high · /effort\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents	'-2':7 '2':11 'agent':5,6,10 'auto':2 'auto-s':1 'aw':14 'claud':9 'claude-ag':8 'fallback':17 'idl':16 'sent':3 'server':13 'worker1':15	\N	\N	\N
cmq8wbxrz001w0xmsax03d8yu	cmq8vsnbo000d0xmsrr2fbhca	2026-06-11 02:46:24.958	2026-06-11 02:51:28.559	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-11 02:46:24.959	\N	0	\N	303601	idle_fallback	playwright test headless; uploads test-results/ on failure\n\n  All jobs use actions/setup-node@v4 with cache: npm keyed on package-lock.json\n  hash (the built-in behavior of that action).\n\n  README.md — CI badge added at the top pointing to the workflow on GitHub\n  Actions.\n\n  [WORKERAI_RESULT]\n  taskId: cmq8vsnbo000d0xmsrr2fbhca\n  status: completed\n  nonce: 2d981641-140e-4f40-9a8a-555a0cf9f73d\n  [/WORKERAI_RESULT]\n\n✻ Cooked for 1m 14s\n\n● How is Claude doing this session? (optional)\n  1: Bad    2: Fine   3: Good   0: Dismiss\n                                                               ● high · /effort\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8wiggj00220xmsybfaflbl	cmq8vt0jo000o0xms5jqwfipu	2026-06-11 02:51:29.107	2026-06-11 02:57:28.593	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-11 02:51:29.107	\N	0	\N	359486	idle_fallback	│ Concurrent deduplication   │  concurrent getConnection() calls await    │\n  │                            │ the same Promise<Client>                   │\n  └────────────────────────────┴────────────────────────────────────────────┘\n\n  TypeScript check passes cleanly. The single failing unit test\n  (usage-parser.test.ts:186) is a pre-existing issue unrelated to SSH or this\n  task.\n\n  [WORKERAI_RESULT]\n  taskId: cmq8vt0jo000o0xms5jqwfipu\n  status: completed\n  nonce: 6a84db3d-c0ba-4cf3-a390-9e13063f1243\n  [/WORKERAI_RESULT]\n\n✻ Worked for 56s\n\n● How is Claude doing this session? (optional)\n  1: Bad    2: Fine   3: Good   0: Dismiss\n                                                               ● high · /effort\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8wq699002b0xmsnz3pn948	cmq8vteoe000s0xms4o0opkg6	2026-06-11 02:57:29.133	2026-06-11 03:03:28.574	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-11 02:57:29.133	\N	0	\N	359441	idle_fallback	a clear error message returned if the client check was insufficient\n\n  Modified files\n  - app/projects/[id]/page.tsx — added "graph" to the tab union, "Dependency\n  Graph" tab button, and <DependencyGraph projectId={id} /> render\n  - app/_components/TaskDetailPanel.tsx — added <DependencyManager taskId={id}\n  projectId={task.project.id} /> before the Execution Controls section\n\n  [WORKERAI_RESULT]\n  taskId: cmq8vteoe000s0xms4o0opkg6\n  status: completed\n  nonce: a2d40d1b-b8a7-4cd9-8119-dbd946729513\n  [/WORKERAI_RESULT]\n\n✻ Churned for 5m 11s\n\n● How is Claude doing this session? (optional)\n  1: Bad    2: Fine   3: Good   0: Dismiss\n                                                               ● high · /effort\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8y9hq000360xms7b7r21bz	cmq8vt0il000m0xms72cipceo	2026-06-11 03:40:30.072	2026-06-11 03:46:24.734	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-11 03:40:30.076	\N	0	\N	354662	idle_fallback	4 s → … → 30 s, max 8 retries).\n  - loadTask(attempt?) — catches fetch network errors and retries with backoff;\n  resets pollConnState to "ok" on success.\n  - Completion poller — replaced setInterval with recursive setTimeout; on HTTP\n  error retries immediately with backoff instead of waiting 30 s.\n  - Connection status badge in task header: amber "Reconnecting…" pill with\n  pulse dot while retrying, red "Offline" pill after exhausting retries.\n\n  [WORKERAI_RESULT]\n  taskId: cmq8vt0il000m0xms72cipceo\n  status: completed\n  nonce: b6c9f778-2def-4115-a458-a07135b10375\n  [/WORKERAI_RESULT]\n\n✻ Worked for 4m 40s\n\n● How is Claude doing this session? (optional)\n  1: Bad    2: Fine   3: Good   0: Dismiss\n                                                               ● high · /effort\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8yh3y2003f0xms4bsuce9q	cmq8vsncr000f0xmsks224km2	2026-06-11 03:46:25.465	2026-06-11 03:51:29.121	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-11 03:46:25.466	\N	0	\N	303656	idle_fallback	- Export modal with:\n    - CSV/JSON radio selector with descriptions\n    - Status filter dropdown (pre-filled from current view)\n    - Project filter dropdown (pre-filled from current view, only shown when\n  projects exist)\n    - Live preview count ("Exporting 12 of 45 tasks (filtered)")\n    - Cancel + "Download CSV/JSON" buttons (Download disabled when count is 0)\n\n  [WORKERAI_RESULT]\n  taskId: cmq8vsncr000f0xmsks224km2\n  status: completed\n  nonce: 2b6f87f9-f2d9-40ed-a93e-26d3217c3dd3\n  [/WORKERAI_RESULT]\n\n✻ Brewed for 2m 1s\n\n● How is Claude doing this session? (optional)\n  1: Bad    2: Fine   3: Good   0: Dismiss\n                                                               ● high · /effort\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8ynmnm003l0xmsr9atd91q	cmq8vt0ld000q0xms01l89pp0	2026-06-11 03:51:29.65	\N	running	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-11 03:51:29.65	\N	0	\N	\N	\N	\N	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'full':11 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8y6wmg00340xms7cgdt4go	cmq8vrbrn00050xmsc3knzsma	2026-06-11 03:38:29.415	2026-06-11 04:05:29.347	completed	Auto-started from queue on agent "agent-1" — mode: full_autonomous	\N	\N	2026-06-11 03:38:29.416	\N	0	\N	1619932	idle_fallback	t, 14.3m cache read, 642.5k\n  cache write ($7.73)\n\n  Current session\n  ████████████████▌                                  33% used\n  Resets 6:50am (UTC)\n\n  Current week (all models)\n  ██                                                 4% used\n  "known limitation" entry and the now-fixed rate-limit false-positive entry\n  (fixed in the previous task) from CLAUDE.md.\n\n  [WORKERAI_RESULT]\n  taskId: cmq8vrbrn00050xmsc3knzsma\n  status: completed\n  nonce: 1337e459-63f5-4a69-aa4c-dae61812a845\n  [/WORKERAI_RESULT]\n\n✻ Churned for 5m 51s\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n\n────────────────────────────────────────────────────────────────────────────────\n  Settings  Status   Config   Usage   Stats\n\n  Session\n\n  Total cost:            $7.73\n  Total duration (API):  19m 57s\n  Total duration (wall): 9h 55m 0s\n  Total code changes:    2066 lines added, 7 lines removed\n  Usage by model:\n      claude-haiku-4-5:  900 input, 14 output, 0 cache read, 0 cache write\n  ($0.0010)\n     claude-sonnet-4-6:  1.6k input, 68.6k output, 14.3m cache read, 642.5k\n  cache write ($7.73)\n\n  Current session\n  ████████████████▌                                  33% used\n  Resets 6:50am (UTC)\n\n  Current week (all models)\n  ██                                                 4% used\n  [WORKERAI_RESULT]\n  taskId: cmq8vrbrn00050xmsc3knzsma\n  status: completed\n  nonce: 1337e459-63f5-4a69-aa4c-dae61812a845\n  [/WORKERAI_RESULT]\n\n✻ Churned for 5m 51s\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n● How is Claude doing this session? (optional)\n  1: Bad    2: Fine   3: Good   0: Dismiss\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents\n         ✘ Auto-update failed: no write permission to npm prefix · Run /doctor\n                                                              ● high · /effort	'-1':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8z5mze003x0xms95kfqlu9	cmq8vs37n000b0xmsnu2oqier	2026-06-11 04:05:29.882	2026-06-11 04:22:29.366	completed	Auto-started from queue on agent "agent-1" — mode: full_autonomous	\N	\N	2026-06-11 04:05:29.882	\N	0	\N	1019484	idle_fallback	───────────────────────────────────────────────\n  Settings  Status   Config   Usage   Stats\n\n  Session\n\n  Total cost:            $0.0000\n  Total duration (API):  0s\n  Total duration (wall): 4s\n  Total code changes:    0 lines added, 0 lines removed\n  Usage:                 0 input, 0 output, 0 cache read, 0 cache write\n\n  Current session\n  ███████████████████████████▌                       55% used\n  Resets 6:50am (UTC)\n\n  Current week (all models)\n  ███                                                6% used\n ▐▛███▜▌   Claude Code v2.1.169\n▝▜█████▛▘  Sonnet 4.6 · Claude Pro\n  ▘▘ ▝▝    /home/ec2-user\n\n   Fable 5 is now available with the latest version of Claude Code! Run "claude\n   update" to update to v2.1.170+\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n\n────────────────────────────────────────────────────────────────────────────────\n  Settings  Status   Config   Usage   Stats\n\n  Session\n\n  Total cost:            $0.0000\n  Total duration (API):  0s\n  Total duration (wall): 30s\n  Total code changes:    0 lines added, 0 lines removed\n  Usage:                 0 input, 0 output, 0 cache read, 0 cache write\n\n  Current session\n  ███████████████████████████▌                       55% used\n  Resets 6:50am (UTC)\n\n  Current week (all models)\n  ███                                                6% used\n ▐▛███▜▌   Claude Code v2.1.169\n▝▜█████▛▘  Sonnet 4.6 · Claude Pro\n  ▘▘ ▝▝    /home/ec2-user\n\n   Fable 5 is now available with the latest version of Claude Code! Run "claude\n   update" to update to v2.1.170+\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n─────────────────────────────────────────────────────���──────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents\n         ✘ Auto-update failed: no write permission to npm prefix · Run /doctor\n                                                              ● high · /effort	'-1':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8zri1t004v0xms6oim3c5d	cmq8vsnes000h0xms0j94euut	2026-06-11 04:22:29.92	\N	running	Auto-started from queue on agent "agent-1" — mode: full_autonomous	\N	\N	2026-06-11 04:22:29.921	\N	0	\N	\N	\N	\N	'-1':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'full':11 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8zssdg004x0xms39m62csa	cmq8vsnes000h0xms0j94euut	2026-06-11 04:23:29.955	\N	running	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-11 04:23:29.956	\N	0	\N	\N	\N	\N	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'full':11 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq8zz7wo00550xmsz8gg801c	cmq8vteq2000u0xmsrzxq2w1t	2026-06-11 04:28:30.024	\N	running	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-11 04:28:30.024	\N	0	\N	\N	\N	\N	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'full':11 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq906xqu005a0xmsnpizynnf	cmq8vts0p00120xms50ew2d47	2026-06-11 04:34:30.102	\N	running	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-11 04:34:30.104	\N	0	\N	\N	\N	\N	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'full':11 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq90dd2m005f0xmso3199b8g	cmq8vu61w00140xms13kqf5dy	2026-06-11 04:39:29.902	2026-06-11 05:01:52.67	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	Enabled improvement cycle automation level 1 for WorkerAI project. Added automation level UI control (4 levels: Disabled/Semi-auto/Assisted/Fully-autonomous) with confirmation dialog on project detail page. Added trigger-cycle API endpoint (POST /api/projects/:id/trigger-cycle). Built and deployed all changes. Project configured: improvementAutomationLevel=1, scanFrequencyDays=7, cycleFrequencyDays=14. Cycles will run automatically every 14 days.	2026-06-11 04:39:29.902	\N	0	\N	\N	\N	\N	'-2':9 '/api/projects':44 '1':18,54 '14':58,64 '4':27 '7':56 'ad':22,37 'agent':7,8 'api':41 'auto':2 'auto-start':1 'autom':16,23 'automat':62 'autonom':12 'built':46 'chang':50 'configur':52 'confirm':31 'control':26 'cycl':15,40,59 'cyclefrequencyday':57 'day':65 'deploy':48 'detail':35 'dialog':32 'disabled/semi-auto/assisted/fully-autonomous':29 'enabl':13 'endpoint':42 'everi':63 'full':11 'id/trigger-cycle':45 'improv':14 'improvementautomationlevel':53 'level':17,24,28 'mode':10 'page':36 'post':43 'project':21,34,51 'queue':5 'run':61 'scanfrequencyday':55 'start':3 'trigger':39 'trigger-cycl':38 'ui':25 'workerai':20	\N	\N	\N
cmq917r9e000kczms2p9hbdem	cmq8vterw000w0xms74u219q3	2026-06-11 05:03:07.964	2026-06-11 05:14:01.809	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-11 05:03:07.97	\N	0	\N	653845	idle_fallback	Task detail page (TaskDetailPanel.tsx): Added a "Schedule Run" section visible\n  when the task is pending or has a schedule set:\n  - No schedule: shows a datetime-local picker + "Set Schedule" button\n  - Schedule set: shows formatted date/time with a "Cancel schedule" link\n\n  Task list page (tasks/page.tsx): Shows a blue clock icon with formatted time\n  in the task metadata line for tasks with scheduledFor set.\n\n  [WORKERAI_RESULT]\n  taskId: cmq8vterw000w0xms74u219q3\n  status: completed\n  nonce: 933a9b50-bf97-467b-9cc6-abb5fc5a93a7\n  [/WORKERAI_RESULT]\n\n✻ Churned for 10m 35s\n\n● How is Claude doing this session? (optional)\n  1: Bad    2: Fine   3: Good   0: Dismiss\n                                                               ● high · /effort\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq91lspm0004p2mszpdpalsy	cmq8vtrwi000y0xmscdmrqzyd	2026-06-11 05:14:03.031	\N	running	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-11 05:14:03.034	\N	0	\N	\N	\N	\N	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'full':11 'mode':10 'queue':5 'start':3	\N	\N	\N
cmq951one006qe8msgypud8gh	cmq8vu63200160xmsftpfjjtx	2026-06-11 06:50:23.107	2026-06-11 06:56:22.658	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-11 06:50:23.114	\N	0	\N	359551	idle_fallback	Ran 1 shell command\n\n● 19 files updated. Now let me also update the PriorityBadge.tsx component since\n  it also uses color classes:\n\n  Read 1 file\n  ⎿  Interrupted · What should Claude do instead?\n\n❯ HOME=/home/ec2-user/claude-agents/agent-2 claude\n  --dangerously-skip-permissions\n  /usage/usage\n\n  Ran 1 shell command\n  ⎿  Interrupted · What should Claude do instead?\n\n● How is Claude doing this session? (optional)\n  1: Bad    2: Fine   3: Good   0: Dismiss\n                                         new task? /clear to save 119.1k tokens\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	0
cmq956tvp0079e8mshnll9c22	cmq8vtryv00100xmsjp3bvgo3	2026-06-11 06:54:23.173	2026-06-11 07:00:06.288	completed	Auto-started from queue on agent "agent-1" — mode: full_autonomous	\N	\N	2026-06-11 06:54:23.173	\N	0	\N	343115	idle_fallback	ch was being dismissed based\n  on the earlier output).\n\n  Did you want me to:\n  1. Continue the interrupted task (creating docker-compose.yml for the WorkerAI\n  project)\n  2. Stop — leave the task incomplete\n\n  The task was partway through — I had gathered all the context needed (read\n  .env.example, package.json, Dockerfile, README.md) and was about to create the\n  docker-compose.yml file.\n\n✻ Crunched for 12s\n\n❯ /usage\n\n────────────────────────────────────────────────────────────────────────────────\n  Settings  Status   Config   Usage   Stats\n\n  Session\n\n  Total cost:            $0.1546\n  Total duration (API):  38s\n  Total duration (wall): 6m 25s\n  Total code changes:    0 lines added, 0 lines removed\n  Usage by model:\n      claude-haiku-4-5:  805 input, 16 output, 0 cache read, 0 cache write\n  ($0.0009)\n     claude-sonnet-4-6:  354 input, 1.7k output, 178.3k cache read, 19.7k\n  cache write ($0.1537)\n\n  Current session\n  ██▌                                                5% used\n  Resets 11:50am (UTC)\n\n  Current week (all models)\n  █████▌                                             11% used\n  usage/settings dialog in the Claude Code UI (which was being dismissed based\n  on the earlier output).\n\n  Did you want me to:\n  1. Continue the interrupted task (creating docker-compose.yml for the WorkerAI\n  project)\n  2. Stop — leave the task incomplete\n\n  The task was partway through — I had gathered all the context needed (read\n  .env.example, package.json, Dockerfile, README.md) and was about to create the\n  docker-compose.yml file.\n\n✻ Crunched for 12s\n\n❯ /usage\n  ⎿  Settings dialog dismissed\n\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents\n         ✘ Auto-update failed: no write permission to npm prefix · Run /doctor\n                                                              ● high · /effort	'-1':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	0
cmq959ek0007ke8ms81h1a4g3	cmq8vu64700180xmsprc9twqh	2026-06-11 06:56:23.279	2026-06-11 07:12:18.19	completed	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-11 06:56:23.282	\N	0	\N	954911	idle_fallback	- app/_components/Nav.tsx — added "Shortcuts" help button in footer (with ?\n  badge), opens KeyboardShortcutsModal\n  - app/_components/GlobalSearch.tsx — added inputRef + workerai:focus-search\n  listener so / focuses the search bar\n  - app/tasks/page.tsx — J/K cursor navigation through the task list (violet\n  ring highlight), Enter opens detail, N opens the new task form (via\n  workerai:new-task event)\n\n  [WORKERAI_RESULT]\n  taskId: cmq8vu64700180xmsprc9twqh\n  status: completed\n  nonce: 0bc406b5-c2e4-4685-828d-d001925836fe\n  [/WORKERAI_RESULT]\n\n✻ Baked for 14m 59s\n\n● How is Claude doing this session? (optional)\n  1: Bad    2: Fine   3: Good   0: Dismiss\n                                                          8% until auto-compact\n────────────────────────────────────────────────────────────────────────────────\n❯ \n────────────────────────────────────────────────────────────────────────────────\n  ⏵⏵ bypass permissions on (shift+tab to cycle) · ← for agents	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'fallback':14 'full':11 'idl':13 'mode':10 'queue':5 'start':3	\N	\N	7
cmq95tw000001hz5u45y0bmym	cmq8vud7c001a0xmsat6b7ywk	2026-06-11 07:12:19.005	\N	running	Auto-started from queue on agent "agent-2" — mode: full_autonomous	\N	\N	2026-06-11 07:12:19.009	\N	0	\N	\N	\N	\N	'-2':9 'agent':7,8 'auto':2 'auto-start':1 'autonom':12 'full':11 'mode':10 'queue':5 'start':3	\N	\N	15
\.


--
-- TOC entry 3812 (class 0 OID 42367)
-- Dependencies: 234
-- Data for Name: ImprovementCycle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ImprovementCycle" (id, "projectId", status, "automationLevel", "scanId", "tasksCreated", "tasksExecuted", "tasksReviewed", "suggestionsGenerated", "suggestionsApproved", "cycleError", "startedAt", "completedAt", "nextCycleAt", "createdAt", "updatedAt") FROM stdin;
cmq92txd30015e8msvd6phr7w	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:48:21.924	2026-06-11 05:49:22.258	\N	2026-06-11 05:48:21.927	2026-06-11 05:49:22.258
cmq90j85q005k0xms4anaj2ze	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 04:44:03.464	2026-06-11 04:44:29.547	\N	2026-06-11 04:44:03.47	2026-06-11 04:44:29.548
cmq911j4w0000czmsvhtai8y3	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 04:58:17.49	2026-06-11 04:58:23.53	\N	2026-06-11 04:58:17.504	2026-06-11 04:58:23.531
cmq92wi02001de8msmmkfw085	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:50:21.984	2026-06-11 05:51:21.993	\N	2026-06-11 05:50:21.986	2026-06-11 05:51:21.993
cmq912lpm0007czmst2iyfbpk	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 04:59:07.494	2026-06-11 05:00:07.964	\N	2026-06-11 04:59:07.498	2026-06-11 05:00:07.964
cmq92z2j0001ie8msrk0vxzpz	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:52:21.898	2026-06-11 05:53:21.999	\N	2026-06-11 05:52:21.9	2026-06-11 05:53:21.999
cmq9156h3000cczms3ofgnnw3	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:01:07.716	2026-06-11 05:02:07.893	\N	2026-06-11 05:01:07.719	2026-06-11 05:02:07.893
cmq917rag000mczms7g3spca7	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 05:03:08.004	2026-06-11 05:04:07.455	\N	2026-06-11 05:03:08.008	2026-06-11 05:04:07.456
cmq931na8001qe8ms2fe8466e	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:54:22.109	2026-06-11 05:55:22	\N	2026-06-11 05:54:22.112	2026-06-11 05:55:22.001
cmq91abn2000rczmscsunqv10	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 05:05:07.69	2026-06-11 05:06:07.911	\N	2026-06-11 05:05:07.694	2026-06-11 05:06:07.911
cmq9347qj001ve8ms0q0ixpow	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:56:21.929	2026-06-11 05:57:22.029	\N	2026-06-11 05:56:21.931	2026-06-11 05:57:22.03
cmq91cwq6000zczmsb22y41ft	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 05:07:08.33	2026-06-11 05:08:08.204	\N	2026-06-11 05:07:08.334	2026-06-11 05:08:08.205
cmq91fgux0014czmsfsl1lafg	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 05:09:07.73	2026-06-11 05:10:08.096	\N	2026-06-11 05:09:07.737	2026-06-11 05:10:08.096
cmq936sbx0020e8ms1lil2sa2	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:58:21.93	2026-06-11 05:59:22.207	\N	2026-06-11 05:58:21.933	2026-06-11 05:59:22.208
cmq91hyoh0019czmsc9khznar	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 05:11:04.133	2026-06-11 05:12:08.072	\N	2026-06-11 05:11:04.146	2026-06-11 05:12:08.072
cmq939cyj0028e8ms310h9hm4	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:00:21.976	2026-06-11 06:01:22.074	\N	2026-06-11 06:00:21.979	2026-06-11 06:01:22.074
cmq91kt030001p2msmst53ogh	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 05:13:16.749	2026-06-11 05:14:03.228	\N	2026-06-11 05:13:16.755	2026-06-11 05:14:03.23
cmq91n1zv0009p2msz7pe7wvv	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 05:15:01.707	2026-06-11 05:16:01.83	\N	2026-06-11 05:15:01.723	2026-06-11 05:16:01.831
cmq93bxiv002de8mse277n5yz	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:02:21.941	2026-06-11 06:03:21.948	\N	2026-06-11 06:02:21.943	2026-06-11 06:03:21.948
cmq91pmwp000hp2mswgkpv73m	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 05:17:02.127	2026-06-11 05:18:01.684	\N	2026-06-11 05:17:02.137	2026-06-11 05:18:01.685
cmq93eiag002le8msuyy6x2mz	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:04:22.166	2026-06-11 06:05:21.924	\N	2026-06-11 06:04:22.168	2026-06-11 06:05:21.925
cmq91s716000mp2msgyzm1vqk	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 05:19:01.527	2026-06-11 05:20:01.796	\N	2026-06-11 05:19:01.53	2026-06-11 05:20:01.797
cmq91urgk000rp2msps38cd8k	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 05:21:01.31	2026-06-11 05:22:01.736	\N	2026-06-11 05:21:01.316	2026-06-11 05:22:01.736
cmq93h2oe002qe8mstbb4kz6h	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:06:21.9	2026-06-11 06:07:22.108	\N	2026-06-11 06:06:21.902	2026-06-11 06:07:22.108
cmq91xc6u000zp2msm9lztmjn	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 05:23:01.49	2026-06-11 05:24:01.639	\N	2026-06-11 05:23:01.495	2026-06-11 05:24:01.64
cmq93jnb1002ze8msjeltm384	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:08:21.947	2026-06-11 06:09:22.258	\N	2026-06-11 06:08:21.949	2026-06-11 06:09:22.258
cmq91zx440014p2mse1ybo6pg	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 05:25:01.92	2026-06-11 05:26:01.977	\N	2026-06-11 05:25:01.929	2026-06-11 05:26:01.984
cmq922igm001cp2msq20pn21a	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 05:27:02.897	2026-06-11 05:28:02.751	\N	2026-06-11 05:27:02.902	2026-06-11 05:28:02.753
cmq93m7ve0037e8mslep6o6jr	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:10:21.911	2026-06-11 06:11:21.874	\N	2026-06-11 06:10:21.914	2026-06-11 06:11:21.874
cmq925258001hp2mso8oe00r2	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 05:29:01.716	2026-06-11 05:30:03.287	\N	2026-06-11 05:29:01.727	2026-06-11 05:30:03.287
cmq93osgg003ce8msjkcu67uc	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:12:21.902	2026-06-11 06:13:21.957	\N	2026-06-11 06:12:21.904	2026-06-11 06:13:21.957
cmq927nls001mp2mstpgu7x4d	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 05:31:02.824	2026-06-11 05:32:03.301	\N	2026-06-11 05:31:02.849	2026-06-11 05:32:03.304
cmq92a84i001up2msi8pwmcny	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 05:33:02.709	2026-06-11 05:34:01.659	\N	2026-06-11 05:33:02.755	2026-06-11 05:34:01.664
cmq93rd82003ke8ms9jm5awn5	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:14:22.128	2026-06-11 06:15:21.914	\N	2026-06-11 06:14:22.13	2026-06-11 06:15:21.914
cmq92crub001zp2mscwioenvz	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:35:01.614	2026-06-11 05:35:37.562	\N	2026-06-11 05:35:01.619	2026-06-11 05:35:37.563
cmq93txnu003pe8msbt3tmyyu	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:16:21.928	2026-06-11 06:17:22.012	\N	2026-06-11 06:16:21.93	2026-06-11 06:17:22.012
cmq92ehvf0005e8mstv4hkkh9	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:36:22.008	2026-06-11 05:37:22.002	\N	2026-06-11 05:36:22.011	2026-06-11 05:37:22.002
cmq92h2f5000ae8msdc8wsgmr	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:38:21.951	2026-06-11 05:39:22.391	\N	2026-06-11 05:38:21.953	2026-06-11 05:39:22.392
cmq93widb003ue8mszkgp8s6o	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:18:22.077	2026-06-11 06:19:22.357	\N	2026-06-11 06:18:22.079	2026-06-11 06:19:22.357
cmq92jmyv000ie8ms9wsg5t64	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:40:21.892	2026-06-11 05:41:22.163	\N	2026-06-11 05:40:21.895	2026-06-11 05:41:22.164
cmq92m7ms000ne8msgiu02wmz	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:42:21.986	2026-06-11 05:43:22.034	\N	2026-06-11 05:42:21.988	2026-06-11 05:43:22.034
cmq92osbv000ve8msrp51rf5m	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:44:22.121	2026-06-11 05:45:22.038	\N	2026-06-11 05:44:22.123	2026-06-11 05:45:22.038
cmq92rcpq0010e8ms1g3v7mem	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:46:21.851	2026-06-11 05:47:21.857	\N	2026-06-11 05:46:21.854	2026-06-11 05:47:21.858
cmq93z2vp0042e8msyk3iiill	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:20:21.971	2026-06-11 06:21:22.198	\N	2026-06-11 06:20:21.973	2026-06-11 06:21:22.198
cmq951oq0006se8msn8k95rpx	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 06:50:23.206	2026-06-11 06:51:22.58	\N	2026-06-11 06:50:23.208	2026-06-11 06:51:22.58
cmq941nkx0047e8mspkf727wf	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:22:22.111	2026-06-11 06:23:22.123	\N	2026-06-11 06:22:22.113	2026-06-11 06:23:22.123
cmq9548we0070e8msf5v8ks6v	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 06:52:22.668	2026-06-11 06:53:22.609	\N	2026-06-11 06:52:22.67	2026-06-11 06:53:22.609
cmq9448b5004fe8mschkbsoli	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:24:22.287	2026-06-11 06:25:22.198	\N	2026-06-11 06:24:22.289	2026-06-11 06:25:22.199
cmq956u6v007ee8mslyx8o9hl	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 06:54:23.573	2026-06-11 06:55:28.551	\N	2026-06-11 06:54:23.575	2026-06-11 06:55:28.551
cmq946sue004ke8mszj7sh7vk	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:26:22.212	2026-06-11 06:27:22.186	\N	2026-06-11 06:26:22.214	2026-06-11 06:27:22.186
cmq959el1007me8msfx347s6z	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	server_busy	2026-06-11 06:56:23.31	2026-06-11 06:57:22.616	\N	2026-06-11 06:56:23.317	2026-06-11 06:57:22.616
cmq949dei004pe8msjq94k0bg	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:28:22.167	2026-06-11 06:29:22.447	\N	2026-06-11 06:28:22.17	2026-06-11 06:29:22.447
cmq94by0n004xe8mspet4wex8	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:30:22.197	2026-06-11 06:31:22.274	\N	2026-06-11 06:30:22.199	2026-06-11 06:31:22.275
cmq94eimj0052e8msk0ku724g	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:32:22.217	2026-06-11 06:33:22.379	\N	2026-06-11 06:32:22.219	2026-06-11 06:33:22.38
cmq94h3e9005ae8mslnd3dzva	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:34:22.447	2026-06-11 06:35:22.508	\N	2026-06-11 06:34:22.449	2026-06-11 06:35:22.508
cmq94jnwr005fe8mszyt44xdp	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:36:22.341	2026-06-11 06:37:22.41	\N	2026-06-11 06:36:22.348	2026-06-11 06:37:22.41
cmq94m8hs005ke8mscu22r9pb	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:38:22.333	2026-06-11 06:39:22.676	\N	2026-06-11 06:38:22.336	2026-06-11 06:39:22.676
cmq94ot4e005se8msudgq7bro	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:40:22.38	2026-06-11 06:41:22.353	\N	2026-06-11 06:40:22.382	2026-06-11 06:41:22.354
cmq94rdsl005xe8mst2cxqjnv	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:42:22.482	2026-06-11 06:43:22.483	\N	2026-06-11 06:42:22.485	2026-06-11 06:43:22.483
cmq94tyjh0065e8ms7zx1gm2f	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:44:22.684	2026-06-11 06:45:22.495	\N	2026-06-11 06:44:22.685	2026-06-11 06:45:22.495
cmq94wj13006ae8msdeaxlhro	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:46:22.549	2026-06-11 06:47:22.531	\N	2026-06-11 06:46:22.551	2026-06-11 06:47:22.531
cmq94z3j2006fe8ms12yu7eka	cmq6ldsxs0000mm5uuxbgs1s8	failed	1	\N	0	0	0	0	0	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:48:22.426	2026-06-11 06:49:22.797	\N	2026-06-11 06:48:22.43	2026-06-11 06:49:22.797
cmq95cgpw00015i5u0c73o3tt	cmq6ldsxs0000mm5uuxbgs1s8	idle	1	\N	0	0	0	0	0	\N	2026-06-11 06:58:46.044	\N	\N	2026-06-11 06:58:46.052	2026-06-11 07:13:56.305
\.


--
-- TOC entry 3815 (class 0 OID 44590)
-- Dependencies: 237
-- Data for Name: MonthlyReport; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MonthlyReport" (id, "monthStart", "completedCount", "failedCount", "runningCount", "pendingCount", "queuedCount", "retriedCount", "timedOutCount", "recoveryCount", "avgExecutionMinutes", "activeServerCount", "activeAgentCount", "agentUtilisation", "topCompletedTasks", "generatedBy", "reportText", "createdAt") FROM stdin;
\.


--
-- TOC entry 3794 (class 0 OID 16603)
-- Dependencies: 216
-- Data for Name: Project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Project" (id, name, description, priority, status, "createdAt", "updatedAt", "completedTasks", "completionPct", "estimatedCompletionAt", "failedTasks", "pendingTasks", "progressUpdatedAt", "runningTasks", "totalTasks", "autoReviewEnabled", "autoScanEnabled", "lastScannedAt", "scanFrequencyDays", "cycleFrequencyDays", "improvementAutomationLevel", "lastImprovementCycleAt", "nextImprovementCycleAt") FROM stdin;
cmq6ldsxs0000mm5uuxbgs1s8	WorkerAI		P1	active	2026-06-09 12:04:23.872	2026-06-11 07:12:18.358	76	92.6829268292683	2026-06-11 20:28:05.724	0	6	2026-06-11 07:12:18.356	0	82	f	t	\N	7	14	1	\N	2026-06-11 04:58:16.486
\.


--
-- TOC entry 3810 (class 0 OID 40509)
-- Dependencies: 232
-- Data for Name: ProjectScan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProjectScan" (id, "projectId", "scanType", status, findings, "findingsCount", "scannedTaskCount", "runOnServerId", "startedAt", "completedAt", "errorMessage", "createdAt") FROM stdin;
cmq90js9m005n0xmskgll81f0	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 04:44:29.521	2026-06-11 04:44:29.541	server_busy	2026-06-11 04:44:29.53
cmq911noo0002czmsjtbqsn21	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 04:58:23.382	2026-06-11 04:58:23.411	server_busy	2026-06-11 04:58:23.4
cmq911nrr0004czmsbozzdmlw	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 04:58:23.511	2026-06-11 04:58:23.522	server_busy	2026-06-11 04:58:23.511
cmq913wcp000aczmsdh4pxml2	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:00:07.944	2026-06-11 05:00:07.954	server_busy	2026-06-11 05:00:07.945
cmq916guz000iczms76l7ure8	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:02:07.834	2026-06-11 05:02:07.888	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:02:07.835
cmq91915h000pczmsxo9po081	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:04:07.444	2026-06-11 05:04:07.449	server_busy	2026-06-11 05:04:07.445
cmq91bm3f000uczmswmra2anj	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:06:07.899	2026-06-11 05:06:07.906	server_busy	2026-06-11 05:06:07.899
cmq91e6wq0012czms765ab49t	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:08:08.185	2026-06-11 05:08:08.198	server_busy	2026-06-11 05:08:08.186
cmq91grer0017czmsj6muey7e	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:10:08.067	2026-06-11 05:10:08.088	server_busy	2026-06-11 05:10:08.067
cmq91jbzp001fczmsgt8uwjz6	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:12:08.052	2026-06-11 05:12:08.065	server_busy	2026-06-11 05:12:08.053
cmq91kszh0000p2msztmhwk9a	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:13:16.728	2026-06-11 05:13:16.739	server_busy	2026-06-11 05:13:16.733
cmq91lsug0007p2mslnwodrrm	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:14:03.207	2026-06-11 05:14:03.218	server_busy	2026-06-11 05:14:03.208
cmq91occ2000cp2ms1ouuylwm	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:16:01.777	2026-06-11 05:16:01.806	server_busy	2026-06-11 05:16:01.778
cmq91qwt4000kp2ms6cwss0vn	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:18:01.623	2026-06-11 05:18:01.648	server_busy	2026-06-11 05:18:01.624
cmq91thic000pp2msulq9djsg	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:20:01.764	2026-06-11 05:20:01.783	server_busy	2026-06-11 05:20:01.765
cmq91w22h000xp2ms77fruwsr	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:22:01.721	2026-06-11 05:22:01.73	server_busy	2026-06-11 05:22:01.722
cmq91ymk50012p2msfzc9ddp1	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:24:01.571	2026-06-11 05:24:01.617	server_busy	2026-06-11 05:24:01.589
cmq9217dm0017p2msqrhve846	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:26:01.88	2026-06-11 05:26:01.95	server_busy	2026-06-11 05:26:01.882
cmq923slh001fp2mswz1rzevv	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:28:02.692	2026-06-11 05:28:02.73	server_busy	2026-06-11 05:28:02.693
cmq926dlp001kp2ms657ekc9o	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:30:03.224	2026-06-11 05:30:03.275	server_busy	2026-06-11 05:30:03.23
cmq928y6u001sp2msd9aea5qv	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:32:03.218	2026-06-11 05:32:03.269	server_busy	2026-06-11 05:32:03.222
cmq92bhiz001xp2ms24efuf8g	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:34:01.592	2026-06-11 05:34:01.63	server_busy	2026-06-11 05:34:01.597
cmq92djh60001e8ms7wc33uhm	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:35:37.43	2026-06-11 05:35:37.476	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:35:37.434
cmq92djje0003e8msa85izxck	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:35:37.513	2026-06-11 05:35:37.554	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:35:37.514
cmq92fs4w0008e8msvwses3au	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:37:21.968	2026-06-11 05:37:21.997	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:37:21.968
cmq92id10000ge8msu4241h55	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:39:22.355	2026-06-11 05:39:22.387	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:39:22.356
cmq92kxg1000le8msbqyfnyvc	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:41:22.129	2026-06-11 05:41:22.159	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:41:22.129
cmq92nhxd000qe8msuz0sh29i	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:43:21.985	2026-06-11 05:43:22.029	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:43:21.985
cmq92q2j1000ye8mshwh9qoxs	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:45:21.996	2026-06-11 05:45:22.034	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:45:21.997
cmq92smzj0013e8msiydmedaw	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:47:21.823	2026-06-11 05:47:21.852	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:47:21.823
cmq92v7vc001be8msmcn7zyn6	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:49:22.2	2026-06-11 05:49:22.253	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:49:22.2
cmq92xsa2001ge8ms2o8gxhl0	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:51:21.962	2026-06-11 05:51:21.989	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:51:21.962
cmq930cvk001le8msn67cgx2j	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:53:21.968	2026-06-11 05:53:21.995	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:53:21.968
cmq932xgv001te8mshfg7fi7b	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:55:21.967	2026-06-11 05:55:21.996	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:55:21.967
cmq935i2z001ye8ms1w726etx	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:57:21.995	2026-06-11 05:57:22.025	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:57:21.995
cmq9382sw0026e8msesa6rib5	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 05:59:22.16	2026-06-11 05:59:22.204	ssh_failed: tmux session 'claude' not found.	2026-06-11 05:59:22.16
cmq93anay002be8ms96cvqrg4	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:01:22.042	2026-06-11 06:01:22.07	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:01:22.042
cmq93d7ss002ge8msxddwveyv	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:03:21.915	2026-06-11 06:03:21.945	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:03:21.916
cmq952yj0006xe8msfqngve5m	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:51:22.571	2026-06-11 06:51:22.575	server_busy	2026-06-11 06:51:22.572
cmq93fsdc002oe8msu0h1ubf2	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:05:21.887	2026-06-11 06:05:21.919	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:05:21.888
cmq93id3i002ue8msiclquj7p	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:07:22.062	2026-06-11 06:07:22.104	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:07:22.062
cmq955j570074e8msghim2cju	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:53:22.603	2026-06-11 06:53:22.606	server_busy	2026-06-11 06:53:22.603
cmq93kxt50035e8mscc45zmbd	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:09:22.216	2026-06-11 06:09:22.254	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:09:22.217
cmq93ni42003ae8ms96w6byyo	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:11:21.842	2026-06-11 06:11:21.87	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:11:21.842
cmq9588b8007he8msgdn3fty1	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:55:28.531	2026-06-11 06:55:28.546	server_busy	2026-06-11 06:55:28.532
cmq93q2rp003fe8ms2izjhqsu	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:13:21.925	2026-06-11 06:13:21.953	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:13:21.925
cmq93snbt003ne8msuy028kmw	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:15:21.881	2026-06-11 06:15:21.911	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:15:21.881
cmq95aobz007pe8msbiedqqx7	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:57:22.607	2026-06-11 06:57:22.611	server_busy	2026-06-11 06:57:22.607
cmq93v7zw003se8ms1k8d6bxr	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:17:21.98	2026-06-11 06:17:22.008	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:17:21.98
cmq93xsug0040e8msj5cpxc1m	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:19:22.311	2026-06-11 06:19:22.353	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:19:22.312
cmq95cgoy00005i5ury3x1148	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:58:46.014	2026-06-11 06:58:46.034	server_busy	2026-06-11 06:58:46.018
cmq940dbq0045e8msk0b9ci7e	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:21:22.166	2026-06-11 06:21:22.194	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:21:22.166
cmq942xuz004ae8msa6hehf1r	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:23:22.091	2026-06-11 06:23:22.119	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:23:22.091
cmq95e7a00001o25uk0gm21dm	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 07:00:07.106	2026-06-11 07:00:07.15	server_busy	2026-06-11 07:00:07.128
cmq945ii9004ie8msbxpkmk87	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:25:22.161	2026-06-11 06:25:22.194	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:25:22.161
cmq94833c004ne8mstsala4uc	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:27:22.152	2026-06-11 06:27:22.181	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:27:22.152
cmq95e7eu0003o25uhg1bcbkz	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 07:00:07.301	2026-06-11 07:00:07.314	server_busy	2026-06-11 07:00:07.302
cmq94anvj004ve8msscotr1am	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:29:22.399	2026-06-11 06:29:22.443	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:29:22.399
cmq94d8ch0050e8msy1vgmz2y	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:31:22.241	2026-06-11 06:31:22.271	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:31:22.241
cmq95f84h0005o25ue378mva0	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 07:00:54.88	2026-06-11 07:00:54.902	server_busy	2026-06-11 07:00:54.881
cmq94ft0r0055e8msmcgwt6to	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:33:22.346	2026-06-11 06:33:22.375	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:33:22.347
cmq94ido9005de8msjx5b9rj6	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:35:22.425	2026-06-11 06:35:22.503	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:35:22.425
cmq95i8ui0000wc5uplzsu9p9	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 07:03:15.77	2026-06-11 07:03:15.914	server_busy	2026-06-11 07:03:15.786
cmq94ky89005ie8msvmbh2767	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:37:22.377	2026-06-11 06:37:22.406	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:37:22.377
cmq94nj0w005qe8ms99fh1c4l	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:39:22.635	2026-06-11 06:39:22.672	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:39:22.64
cmq95i9de0002wc5u4gcvfze9	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 07:03:16.466	2026-06-11 07:03:16.482	server_busy	2026-06-11 07:03:16.467
cmq94q3de005ve8mskz4dduot	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:41:22.322	2026-06-11 06:41:22.35	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:41:22.322
cmq94so2b0060e8mswwww20i5	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:43:22.451	2026-06-11 06:43:22.478	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:43:22.451
cmq95iq6p0004wc5umgvay4st	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 07:03:38.257	2026-06-11 07:03:38.297	server_busy	2026-06-11 07:03:38.258
cmq94v8nx0068e8msqwqyn3fm	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:45:22.46	2026-06-11 06:45:22.491	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:45:22.461
cmq94xta9006de8msduld29j8	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:47:22.496	2026-06-11 06:47:22.527	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:47:22.497
cmq95k2cm0006wc5uwu84a6af	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 07:04:40.678	2026-06-11 07:04:40.696	server_busy	2026-06-11 07:04:40.678
cmq950e2w006me8ms6ji5l34l	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 06:49:22.76	2026-06-11 06:49:22.793	ssh_failed: tmux session 'claude' not found.	2026-06-11 06:49:22.76
cmq95le080008wc5uxa881e4k	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 07:05:42.438	2026-06-11 07:05:42.452	server_busy	2026-06-11 07:05:42.44
cmq95mqex000dwc5umvq8m3vo	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 07:06:45.177	2026-06-11 07:06:45.194	server_busy	2026-06-11 07:06:45.178
cmq95nyoe000fwc5u36bgvlda	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 07:07:42.541	2026-06-11 07:07:42.601	server_busy	2026-06-11 07:07:42.542
cmq95sgdc0000el5uz2rue5fr	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 07:11:12.078	2026-06-11 07:11:12.112	server_busy	2026-06-11 07:11:12.096
cmq95sgg40002el5u8wiusrnr	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 07:11:12.195	2026-06-11 07:11:12.243	server_busy	2026-06-11 07:11:12.196
cmq95tegh0004el5u7oqtynop	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 07:11:56.273	2026-06-11 07:11:56.278	server_busy	2026-06-11 07:11:56.273
cmq95tw430003hz5uzps19100	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 07:12:19.137	2026-06-11 07:12:19.162	server_busy	2026-06-11 07:12:19.155
cmq95tw6l0005hz5uw6ii5xzu	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 07:12:19.245	2026-06-11 07:12:19.25	server_busy	2026-06-11 07:12:19.245
cmq95uotw0006el5uyk8c82rq	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 07:12:56.372	2026-06-11 07:12:56.379	server_busy	2026-06-11 07:12:56.372
cmq95vz2e0008el5ummg27eog	cmq6ldsxs0000mm5uuxbgs1s8	gap_analysis	failed	[]	0	50	cmq6ke2xl0000s25u4a8i94ta	2026-06-11 07:13:56.294	2026-06-11 07:13:56.3	server_busy	2026-06-11 07:13:56.294
\.


--
-- TOC entry 3802 (class 0 OID 28145)
-- Dependencies: 224
-- Data for Name: RecoveryLog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."RecoveryLog" (id, "serverId", "agentId", "triggeredBy", success, command, "errorMessage", "createdAt") FROM stdin;
cmq828bx00000m05u56030tvy	\N	cmq6w5d940000525uus1ckhga	manual	t	HOME=/home/ec2-user/claude-agents/agent-1 claude --dangerously-skip-permissions	\N	2026-06-10 12:43:48.18
cmq828s020001m05uejyc6fww	\N	cmq6w5d940000525uus1ckhga	manual	t	HOME=/home/ec2-user/claude-agents/agent-1 claude --dangerously-skip-permissions	\N	2026-06-10 12:44:09.026
cmq8doirc000b0xnwsejr9moa	\N	cmq6w5d940000525uus1ckhga	manual	t	HOME=/home/ec2-user/claude-agents/agent-1 claude --dangerously-skip-permissions	\N	2026-06-10 18:04:19.32
cmq8dw9nc000r0xnwulj85hqw	\N	cmq6w5d940000525uus1ckhga	manual	t	HOME=/home/ec2-user/claude-agents/agent-1 claude --dangerously-skip-permissions	\N	2026-06-10 18:10:20.76
cmq955soh0076e8msvb48y555	\N	cmq6w5d940000525uus1ckhga	manual	t	HOME=/home/ec2-user/claude-agents/agent-1 claude --dangerously-skip-permissions	\N	2026-06-11 06:53:34.961
\.


--
-- TOC entry 3804 (class 0 OID 29167)
-- Dependencies: 226
-- Data for Name: ScheduledResume; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ScheduledResume" (id, "resourceType", "resourceId", "resumeAt", triggered, "createdAt", "updatedAt") FROM stdin;
cmq89zqbl000q6c5uqnuf4na6	agent	cmq6wcl430001525urn13fvcx	2026-06-11 06:55:00	t	2026-06-10 16:21:03.91	2026-06-11 06:55:14.075
cmq87htfy000apw5usr4zwtaj	agent	cmq6w5d940000525uus1ckhga	2026-06-11 06:55:00	t	2026-06-10 15:11:08.878	2026-06-11 06:55:14.075
\.


--
-- TOC entry 3798 (class 0 OID 16671)
-- Dependencies: 220
-- Data for Name: Server; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Server" (id, name, host, username, port, "sshKeyPath", status, "lastCheckedAt", "createdAt", "updatedAt", "claudeSessionPct", "claudeSessionResets", "claudeUsageFetchedAt", "claudeUsageRaw", "claudeWeekPct", "claudeWeekResets", "claudeSessionResetsAt", "claudeWeekResetsAt", "claudePermissionMode", "tmuxSession", "defaultTaskTimeoutMinutes", "consecutiveFailures", "healthScore", "lastHealthCheckAt", "autoRecovery", "lastRecoveryAt", "maxRecoveryAttempts", "recoveryAttempts", "autoPauseEnabled", "pausedAt", "pausedDueToUsage", "capacityScore", "activeTaskCount", "maxConcurrentTasks", "capacityUpdatedAt") FROM stdin;
cmq6ke2xl0000s25u4a8i94ta	AWS Worker1	13.54.210.68	ec2-user	22	~/.ssh/WorkerAI.pem	failed	2026-06-10 12:06:41.381	2026-06-09 11:36:37.209	2026-06-11 07:14:21.383	0	10 June, 8:20 am (Sydney)	2026-06-11 07:14:21.381	╭─── Claude Code v2.1.169 ─────────────────────────────────────────────────────╮\n▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔\n   Settings  Status   Config   Usage   Stats\n\n   Session\n\n   Total cost:            $0.0000\n   Total duration (API):  0s\n   Total duration (wall): 22s\n   Total code changes:    0 lines added, 0 lines removed\n   Usage:                 0 input, 0 output, 0 cache read, 0 cache write\n\n   Current session\n                                                      0% used\n   Resets 10:20pm (UTC)\n\n   Current week (all models)\n   ████████████▌                                      25% used\n   Resets Jun 15, 9am (UTC)\n\n   Usage credits\n   Usage credits are off · /usage-credits to turn them on	25	15 June, 7:00 pm (Sydney)	2026-06-09 22:20:00	2026-06-15 09:00:00	full_autonomous	claude	\N	0	100	2026-06-11 07:06:45.098	f	\N	3	0	t	\N	f	84.5	1	10	2026-06-11 07:14:20.751
\.


--
-- TOC entry 3799 (class 0 OID 16681)
-- Dependencies: 221
-- Data for Name: ServerCommandLog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ServerCommandLog" (id, "serverId", command, status, output, "errorMessage", "startedAt", "finishedAt", "createdAt") FROM stdin;
cmq6khicw0001s25u6m0ab81t	cmq6ke2xl0000s25u4a8i94ta	whoami	success	Connected. Remote user: ec2-user	\N	2026-06-09 11:39:16.793	2026-06-09 11:39:17.165	2026-06-09 11:39:17.168
cmq6ofuzi00000wtd71fopfhw	cmq6ke2xl0000s25u4a8i94ta	whoami	failed	\N	Cannot read SSH key at "/root/.ssh/WorkerAI.pem". Check that the path exists and is readable.	2026-06-09 13:29:58.663	2026-06-09 13:29:58.68	2026-06-09 13:29:58.686
cmq6og9d800010wtdxamk83ta	cmq6ke2xl0000s25u4a8i94ta	whoami	failed	\N	Cannot read SSH key at "/root/.ssh/WorkerAI.pem". Check that the path exists and is readable.	2026-06-09 13:30:17.32	2026-06-09 13:30:17.323	2026-06-09 13:30:17.324
cmq6omwhz00000xo9a1jih30k	cmq6ke2xl0000s25u4a8i94ta	whoami	success	Connected. Remote user: ec2-user	\N	2026-06-09 13:35:26.974	2026-06-09 13:35:27.234	2026-06-09 13:35:27.24
cmq6p57jr00040xo9ybku3y0l	cmq6ke2xl0000s25u4a8i94ta	df -h	success	Filesystem        Size  Used Avail Use% Mounted on\ndevtmpfs          4.0M     0  4.0M   0% /dev\ntmpfs             957M     0  957M   0% /dev/shm\ntmpfs             383M  676K  382M   1% /run\n/dev/nvme0n1p1     16G   12G  4.6G  72% /\ntmpfs             957M  2.6M  955M   1% /tmp\n/dev/nvme0n1p128   10M  1.3M  8.7M  13% /boot/efi\ntmpfs             192M     0  192M   0% /run/user/1000\n	\N	2026-06-09 13:49:41.16	2026-06-09 13:49:41.366	2026-06-09 13:49:41.367
cmq6ts9sp000y0xla2p4ra3x8	cmq6ke2xl0000s25u4a8i94ta	df -h	success	Filesystem        Size  Used Avail Use% Mounted on\ndevtmpfs          4.0M     0  4.0M   0% /dev\ntmpfs             957M     0  957M   0% /dev/shm\ntmpfs             383M  672K  383M   1% /run\n/dev/nvme0n1p1     16G   12G  4.7G  72% /\ntmpfs             957M  4.7M  952M   1% /tmp\n/dev/nvme0n1p128   10M  1.3M  8.7M  13% /boot/efi\ntmpfs             192M     0  192M   0% /run/user/1000\n	\N	2026-06-09 15:59:35.636	2026-06-09 15:59:35.832	2026-06-09 15:59:35.833
cmq6tshgk000z0xlak1gtc413	cmq6ke2xl0000s25u4a8i94ta	whoami	success	ec2-user\n	\N	2026-06-09 15:59:45.554	2026-06-09 15:59:45.764	2026-06-09 15:59:45.764
cmq6tsiu100100xla15cq3xxt	cmq6ke2xl0000s25u4a8i94ta	hostname	success	ip-172-31-23-229.ap-southeast-2.compute.internal\n	\N	2026-06-09 15:59:47.339	2026-06-09 15:59:47.545	2026-06-09 15:59:47.545
cmq6tsknx00110xlapl8dant2	cmq6ke2xl0000s25u4a8i94ta	uptime	success	 15:59:49 up  2:52,  4 users,  load average: 0.00, 0.14, 0.18\n	\N	2026-06-09 15:59:49.663	2026-06-09 15:59:49.916	2026-06-09 15:59:49.917
cmq6tsn3w00120xlavdjrii4h	cmq6ke2xl0000s25u4a8i94ta	df -h	success	Filesystem        Size  Used Avail Use% Mounted on\ndevtmpfs          4.0M     0  4.0M   0% /dev\ntmpfs             957M     0  957M   0% /dev/shm\ntmpfs             383M  680K  382M   1% /run\n/dev/nvme0n1p1     16G   12G  4.7G  72% /\ntmpfs             957M  4.7M  952M   1% /tmp\n/dev/nvme0n1p128   10M  1.3M  8.7M  13% /boot/efi\ntmpfs             192M     0  192M   0% /run/user/1000\n	\N	2026-06-09 15:59:52.842	2026-06-09 15:59:53.083	2026-06-09 15:59:53.084
cmq6tspfh00130xla0ouz6545	cmq6ke2xl0000s25u4a8i94ta	free -m	success	               total        used        free      shared  buff/cache   available\nMem:            1913        1076         415          18         421         650\nSwap:              0           0           0\n	\N	2026-06-09 15:59:55.857	2026-06-09 15:59:56.092	2026-06-09 15:59:56.093
cmq6ze9cb00000xnws1fp469t	cmq6ke2xl0000s25u4a8i94ta	whoami	success	Connected. Remote user: ec2-user	\N	2026-06-09 18:36:39.526	2026-06-09 18:36:39.744	2026-06-09 18:36:39.758
cmq6zhrkp00010xnwnin8hv23	cmq6ke2xl0000s25u4a8i94ta	whoami	success	Connected. Remote user: ec2-user	\N	2026-06-09 18:39:23.087	2026-06-09 18:39:23.353	2026-06-09 18:39:23.357
cmq71481v00050xnw8usb6zh3	cmq6ke2xl0000s25u4a8i94ta	whoami	success	Connected. Remote user: ec2-user	\N	2026-06-09 19:24:50.507	2026-06-09 19:24:50.755	2026-06-09 19:24:50.755
cmq7nt52f0001td5uwq8m6mxu	cmq6ke2xl0000s25u4a8i94ta	whoami	success	Connected. Remote user: ec2-user	\N	2026-06-10 06:00:04.649	2026-06-10 06:00:04.833	2026-06-10 06:00:04.839
cmq7qnx1a00050xmixtuwtwrd	cmq6ke2xl0000s25u4a8i94ta	whoami	success	Connected. Remote user: ec2-user	\N	2026-06-10 07:19:59.963	2026-06-10 07:19:59.996	2026-06-10 07:19:59.998
cmq80wlq00002fy5ujv8t15sf	cmq6ke2xl0000s25u4a8i94ta	whoami	success	Connected. Remote user: ec2-user	\N	2026-06-10 12:06:41.261	2026-06-10 12:06:41.398	2026-06-10 12:06:41.4
\.


--
-- TOC entry 3803 (class 0 OID 28656)
-- Dependencies: 225
-- Data for Name: SystemConfig; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SystemConfig" (key, value, "updatedAt") FROM stdin;
\.


--
-- TOC entry 3795 (class 0 OID 16613)
-- Dependencies: 217
-- Data for Name: Task; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Task" (id, "projectId", title, description, priority, status, "estimatedCostLevel", "taskType", "resultSummary", "nextAction", "createdAt", "updatedAt", "serverId", "agentId", "completionNonce", "tmuxOutputOffset", "taskTmuxSession", "timeoutMinutes", "lastProgressAt", "stallDetectedAt", "lastFailReason", "maxRetries", "retryAfter", "retryCount", "blockedByCount", "autoReviewEnabled", "reviewCompletedAt", "reviewScheduledAt", "reviewStartedAt", "reviewStatus", "reviewVerdictNotes", "scheduledFor") FROM stdin;
cmq6m75f9000rmm5up1lujvdh	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-002] Missing Integration Tests for Task State Machine Transitions	Valid status transitions are enforced only implicitly in route handlers. No tests verify that invalid transitions are blocked or that auto-advance logic fires correctly.	P2	completed	medium	coding	\N	\N	2026-06-09 12:27:13.077	2026-06-10 08:53:16.967	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	853bf5a3-79de-4fc9-86c6-7b436ca2b811	154	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq950yl4006oe8ms8awk8aj6	cmq6ldsxs0000mm5uuxbgs1s8	Code review: WorkerAI	Review the code in WorkerAI for correctness, readability, and adherence to project conventions.\n\nFocus areas:\n- Logic errors and edge cases\n- Code style and naming\n- Test coverage\n- Security concerns\n\n	P2	pending	low	review	\N	\N	2026-06-11 06:49:49.336	2026-06-11 06:49:49.336	\N	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6lf9l60001mm5ug1mh1nrv	cmq6ldsxs0000mm5uuxbgs1s8	git commit and git push	Read CLAUDE.md first and follow all project instructions.\n\nTask:\nReview the current git working tree and prepare commits from the existing changes.\n\nRequirements:\n\n1. Read CLAUDE.md before doing anything else.\n2. Run git status and inspect all current changes.\n3. Review the diffs and determine appropriate commit groupings based on the actual changes.\n4. Create clean git commits with meaningful commit messages.\n5. Do not create a branch.\n6. Do not create a PR.\n7. Do not include any Co-Authored-By lines.\n8. Do not include Claude attribution in commit messages.\n9. Verify the repository is in a clean state after committing.\n10. Push all commits directly to origin/main.\n\nSuggested workflow:\n\n* git status\n* git diff\n* git add <files>\n* git commit -m "<message>"\n* repeat as needed\n* git push origin main\n\nAfter completion, provide:\n\n* Commit hashes\n* Commit messages\n* Confirmation that the push to main succeeded\n* Final git status\n	P1	archived	medium	coding	\N	\N	2026-06-09 12:05:32.106	2026-06-09 12:16:58.193	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m6qj7000mmm5u94teogfw	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-001] 60-Second Poller Makes Sequential SSH Calls for All Servers — No Parallelism	The usage fetch loop is sequential. With 5 servers each taking 5-10s per tmux round-trip, a single poll cycle can take 25-50s. Use Promise.allSettled for parallel per-server checks.	P3	completed	low	coding	\N	\N	2026-06-09 12:26:53.779	2026-06-09 14:08:53.319	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m6bfx000dmm5u3fo0qsrc	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-001] No Database Indexes on High-Frequency Query Columns	The most common queries filter by task status, priority, serverId, and projectId. None of these columns have explicit indexes. Full sequential scans at 10k+ tasks will degrade the 60s poller into a bottleneck.	P2	completed	medium	maintenance	\N	\N	2026-06-09 12:26:34.221	2026-06-09 16:18:54.724	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m6bw1000fmm5u33lzsu35	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-001] /tmp/.claude_task Temp File Is a Race Condition Under Concurrent Sends	sendTaskToTmux writes to a fixed path /tmp/.claude_task. Two concurrent dispatches to the same server will overwrite each other. Use a unique temp file per invocation.	P2	completed	medium	coding	\N	\N	2026-06-09 12:26:34.801	2026-06-09 15:18:53.815	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m5xtg000cmm5upzh1ok64	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-001] Task Status Endpoint Accepts Any Arbitrary String as Status	PUT /api/tasks/[id]/status passes the status field directly to prisma.task.update with no validation against the TaskStatus enum. Clients can set status to any string, corrupting the DB and breaking queue filters.	P1	completed	medium	coding	\N	\N	2026-06-09 12:26:16.564	2026-06-09 15:05:58.644	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m5wux0009mm5uko31be41	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-001] Arbitrary Command Execution via /api/servers/[id]/exec with No Safety Net	The /exec route accepts any string command and runs it via SSH on the target server with no sanitization, no audit log review gate, and no confirmation. Only defense is the weakened origin check.	P1	completed	medium	review	\N	\N	2026-06-09 12:26:15.321	2026-06-09 14:40:53.896	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m5xda000amm5uxzhtzg6n	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-001] Race Condition: Simultaneous Task Dispatches Can Send Multiple Tasks to One Claude Session	The 60s poller, manual Run button, and auto-run in PUT /api/tasks/[id] all independently call sendTaskToTmux with no locking. Overlapping dispatches paste both prompts into the same Claude session, corrupting both tasks.	P1	completed	medium	coding	\N	\N	2026-06-09 12:26:15.982	2026-06-09 15:02:53.864	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m5wlu0008mm5uzcl07jv6	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-001] No Authentication or Authorization on Any Endpoint	Every API route is completely unauthenticated. Any process or person with network access to port 3000 can create/delete servers, read SSH key paths, run arbitrary SSH commands, and trigger Claude tasks.	P1	completed	medium	review	\N	\N	2026-06-09 12:26:14.994	2026-06-09 14:52:58.703	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m6qbg000lmm5uksvqux41	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-001] Server Command Logs Not Paginated — Loads Up to 100 Rows on Every Server Detail View	GET /api/servers/[id] hard-codes take: 50 on commandLogs and GET /api/servers/[id]/logs hard-codes take: 100. Lazy-load the logs tab on demand with cursor-based pagination.	P3	completed	low	coding	\N	\N	2026-06-09 12:26:53.5	2026-06-09 15:49:54.183	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m6cc3000hmm5u15815k2d	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-001] No Input Validation on PUT /api/tasks/[id] — Any Field Can Be Set to Any Value	The PUT handler destructures priority, estimatedCostLevel, taskType, status from request body and passes them directly to Prisma without enum validation.	P2	completed	medium	coding	\N	\N	2026-06-09 12:26:35.379	2026-06-09 15:53:54.276	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m6qrc000nmm5ulaczx3ue	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-001] claudeUsageRaw Stores Unbounded tmux Pane Output in the Database	Raw tmux pane capture (up to 2000 chars) stored in Server.claudeUsageRaw on every 60s poll. Cap to 500 chars or remove entirely and rely on parsed fields.	P3	completed	low	maintenance	\N	\N	2026-06-09 12:26:54.072	2026-06-09 19:19:07.986	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m6c43000gmm5uqnod2pta	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-001] No Error Handling on Most API Routes — Unhandled Exceptions Return 500 with Stack Traces	Most API routes have no try/catch around Prisma calls. DB connection loss returns raw 500 with stack traces that leak internal paths and schema details.	P2	completed	medium	coding	\N	\N	2026-06-09 12:26:35.091	2026-06-09 19:29:05.371	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m6bnw000emm5uakgculj4	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-001] USAGE_THRESHOLD Constant Duplicated Across Three Files	The value 90 is hard-coded in app/api/tasks/[id]/run/route.ts, app/api/tasks/[id]/route.ts, and instrumentation.node.ts. Extract to lib/constants.ts.	P2	completed	medium	maintenance	\N	\N	2026-06-09 12:26:34.508	2026-06-09 19:29:05.378	cmq6ke2xl0000s25u4a8i94ta	cmq6w5d940000525uus1ckhga	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m6ckd000imm5ux3td3azi	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-001] WebSocket Server Has No Connection Limit or Per-IP Rate Limit	ws-server.ts accepts unlimited concurrent WebSocket connections. Each opens an SSH connection to the target server. A scanner can open thousands of connections, exhausting SSH limits on worker servers.	P2	completed	medium	coding	\N	\N	2026-06-09 12:26:35.677	2026-06-10 06:28:25.998	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m7jqa000zmm5uorui4n8v	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-003] WebSocket Origin Check Relaxed Without Security Review Documentation	The recent change relaxed origin validation from localhost-only to same-hostname match. No security review was documented. Expands attack surface to all same-hostname origins.	P2	completed	medium	review	\N	\N	2026-06-09 12:27:31.618	2026-06-10 08:31:12.681	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	b60d523f-9644-4662-bd84-78cddaab18de	154	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m7k170010mm5uzmbmja58	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-003] No Rate Limiting on Any API Endpoint	All 20+ API endpoints have no rate limiting. /api/servers/[id]/claude-usage and /api/tasks/[id]/check-completion each open SSH connections on every call.	P2	completed	medium	coding	\N	\N	2026-06-09 12:27:32.011	2026-06-10 08:37:01.54	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	0f43c783-be1d-498c-a50d-f0734d2f5f34	154	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m90vq0016mm5u76nppdev	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-004] lib/ssh-claude.ts Is Dead Code — Remove to Reduce Confusion	lib/ssh-claude.ts is documented as 'Legacy PTY/exec approach — kept but not used'. It exports functions with similar names to the active lib, creating confusion. Delete it.	P3	archived	high	maintenance	\N	\N	2026-06-09 12:28:40.502	2026-06-09 13:44:40.322	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6lva180006mm5uvbfoz4ny	cmq6ldsxs0000mm5uuxbgs1s8	Tasks monitor by system	TICKET-001: Full Project Audit and Improvement Discovery\nObjective\n\nPerform a complete end-to-end audit of the current project and identify all potential improvements across architecture, code quality, testing, security, performance, maintainability, scalability, infrastructure, developer experience, and user experience.\n\nScope\n\nReview:\n\nSource code\nDatabase schema\nAPI design\nFrontend architecture\nBackend architecture\nInfrastructure configuration\nCI/CD workflows\nDocumentation\nEnvironment configuration\nDependencies\nMonitoring setup\nLogging setup\nRequired Analysis\n\nIdentify:\n\nBugs\nTechnical debt\nMissing features\nMissing validations\nMissing tests\nSecurity vulnerabilities\nScalability limitations\nPerformance bottlenecks\nUX issues\nReliability issues\nDeliverables\n\nGenerate a report containing:\n\nCritical Issues\n\nProblems that may cause:\n\nData loss\nSecurity risks\nService outages\nIncorrect functionality\nHigh Priority Improvements\n\nItems that significantly improve:\n\nStability\nMaintainability\nPerformance\nMedium Priority Improvements\n\nItems that improve:\n\nDeveloper experience\nCode quality\nUser experience\nEnhancement Opportunities\n\nSuggested new features that would increase product value.\n\nOutput Format\n\nFor every issue found create:\n\n{\n  "title": "",\n  "priority": "critical|high|medium|low",\n  "category": "",\n  "description": "",\n  "impact": "",\n  "recommended_solution": ""\n}\nTICKET-002: Automated Test Gap Analysis\nObjective\n\nAnalyze the entire project and discover missing tests.\n\nScope\n\nReview:\n\nAPI endpoints\nServices\nBusiness logic\nDatabase operations\nFrontend components\nAuthentication flows\nError handling\nTasks\n\nIdentify:\n\nMissing unit tests\nMissing integration tests\nMissing E2E tests\nMissing edge-case tests\nMissing regression tests\nDeliverables\n\nCreate testing tickets for each gap discovered.\n\nEstimate:\n\nRisk level\nImpact\nRecommended test type\nTICKET-003: Security Audit\nObjective\n\nAct as a senior application security engineer.\n\nPerform a complete security review.\n\nAnalyze\n\nAuthentication\n\nAuthorization\n\nRBAC\n\nSession management\n\nAPI security\n\nSecrets management\n\nEnvironment variables\n\nDependency vulnerabilities\n\nDatabase access controls\n\nFile upload functionality\n\nPrompt injection risks\n\nAI integration risks\n\nDeliverables\n\nCreate remediation tickets.\n\nCategorize findings:\n\nCritical\nHigh\nMedium\nLow\nTICKET-004: Architecture Review\nObjective\n\nAct as a Staff Software Architect.\n\nReview the current architecture and identify improvements.\n\nEvaluate\n\nCode organization\n\nService boundaries\n\nScalability\n\nModularity\n\nMaintainability\n\nTechnical debt\n\nMicroservice readiness\n\nCloud readiness\n\nDeliverables\n\nArchitecture improvement report.\n\nGenerate implementation tickets.\n\nTICKET-005: Performance Investigation\nObjective\n\nIdentify all performance bottlenecks.\n\nReview\n\nDatabase queries\n\nAPI response times\n\nFrontend rendering\n\nNetwork requests\n\nMemory usage\n\nCPU usage\n\nBackground jobs\n\nCaching opportunities\n\nDeliverables\n\nGenerate performance improvement tickets.\n\nTICKET-006: Infrastructure Assessment\nObjective\n\nAct as a Senior DevOps Engineer.\n\nReview infrastructure and deployment setup.\n\nAnalyze\n\nAWS resources\n\nDocker setup\n\nDeployment pipeline\n\nMonitoring\n\nLogging\n\nAlerting\n\nBackups\n\nRecovery process\n\nHigh availability\n\nCost optimization\n\nDeliverables\n\nGenerate infrastructure improvement tasks.\n\nTICKET-007: UX Review\nObjective\n\nAct as a Senior Product Designer.\n\nReview the product from a user's perspective.\n\nEvaluate\n\nNavigation\n\nDiscoverability\n\nWorkflow friction\n\nVisual hierarchy\n\nError messages\n\nLoading states\n\nEmpty states\n\nAccessibility\n\nDeliverables\n\nGenerate UX enhancement tickets.\n\nTICKET-008: AI Workflow Review\nObjective\n\nAnalyze all AI-related functionality.\n\nReview\n\nPrompt quality\n\nContext management\n\nToken efficiency\n\nFailure handling\n\nRetry logic\n\nModel selection\n\nCost optimization\n\nResponse quality\n\nHallucination prevention\n\nDeliverables\n\nGenerate AI optimization tickets.\n\nTICKET-009: Worker Efficiency Audit\nObjective\n\nAnalyze all workers and task execution patterns.\n\nReview\n\nExecution times\n\nFailure rates\n\nIdle time\n\nQueue efficiency\n\nResource usage\n\nRetry frequency\n\nTask duplication\n\nDeliverables\n\nCreate worker optimization tasks.\n\nTICKET-010: Self-Improvement Discovery\nObjective\n\nIdentify improvements that the project team may not have considered.\n\nThink like:\n\nCTO\nProduct Manager\nSenior Engineer\nQA Lead\nSecurity Engineer\nDevOps Engineer\nDeliverables\n\nGenerate at least 20 new tickets.\n\nInclude:\n\nDescription\nBusiness value\nTechnical value\nEstimated effort	P1	completed	high	coding	\N	\N	2026-06-09 12:17:59.18	2026-06-09 13:37:06.582	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m7kb20011mm5u4gjgmbm3	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-003] Database Credentials Hardcoded in .env — Verify Not in Git History	DATABASE_URL in .env contains plaintext credentials. Verify .env is in .gitignore and not in git history. Rotate password and use secrets management for any deployed environment.	P2	completed	medium	review	\N	\N	2026-06-09 12:27:32.366	2026-06-10 08:59:16.98	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	18933324-3568-42d8-af91-abbf89845d48	154	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m7iqb000wmm5uoopyzxx3	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-003] SSH Key Path Stored in Database — Path Traversal / Arbitrary Key Read Risk	sshKeyPath stored in Server table is passed directly to fs.readFileSync(). An attacker who can write to the DB via the unauthenticated PUT /api/servers/[id] endpoint can set sshKeyPath to any file on the host.	P1	completed	medium	review	\N	\N	2026-06-09 12:27:30.324	2026-06-09 15:10:53.854	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m90ns0015mm5u5zp5zjwn	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-004] Single tmux Session Per Server Is a Serialization Bottleneck — Only One Task at a Time	The entire execution model assumes exactly one 'claude' tmux session per server. Maximum throughput is one task per server. Support named tmux sessions per task (claude_taskId) for parallel execution.	P2	completed	high	coding	\N	\N	2026-06-09 12:28:40.216	2026-06-10 09:09:17.116	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	38637c33-07ec-4c53-a48b-8c49330d58f1	154	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m7j8u000ymm5u3g2bh0ei	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-003] Prompt Injection Risk in Task Description Sent to Claude Tmux	Task titles and descriptions are sent verbatim to the Claude CLI. A malicious description can override Claude behavior or instruct it to execute destructive commands, especially in full_autonomous mode.	P1	completed	medium	review	\N	\N	2026-06-09 12:27:30.99	2026-06-09 15:17:53.916	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m7j0m000xmm5urxlubhyt	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-003] No CSRF Protection on Mutating API Endpoints	All POST/PUT/DELETE endpoints have no CSRF protection. If session cookies are ever added without SameSite=Strict or a CSRF token, all endpoints will be vulnerable.	P2	completed	medium	review	\N	\N	2026-06-09 12:27:30.695	2026-06-09 15:45:54.339	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m76b3000vmm5uu2bc8n96	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-002] Missing E2E Tests for Core User Workflows	No end-to-end tests for: creating project/task, assigning server, viewing queue, generating daily report, or navigating the server terminal page.	P3	completed	medium	coding	\N	\N	2026-06-09 12:27:14.223	2026-06-09 14:34:53.852	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m762z000umm5uq9jyibfg	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-002] Missing Concurrency Tests for Simultaneous Task Dispatch Paths	The race condition between the 60s poller, manual run, and auto-run paths is untested. Simulate two concurrent dispatches and verify only one proceeds.	P2	paused	medium	coding	\N	\N	2026-06-09 12:27:13.931	2026-06-09 16:17:32.766	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m913r0017mm5u6hm7khsk	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-004] All Pages Are Client-Side useEffect Fetches — No Server-Side Rendering Benefits	Every page uses use client + useEffect + fetch, requiring 5 round-trips before showing data. For dashboard and task list, use RSC for initial data load, then hydrate for interactivity.	P3	paused	high	coding	\N	\N	2026-06-09 12:28:40.792	2026-06-09 16:17:38.169	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m90cu0014mm5u34bzm2ee	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-004] Poller and Next.js App Use Separate Prisma Client Instances	ws-server.ts creates its own PrismaClient + pg.Pool. instrumentation.node.ts and API routes use lib/prisma.ts singleton. This means 2-3 separate connection pools exist simultaneously.	P2	paused	high	maintenance	\N	\N	2026-06-09 12:28:39.822	2026-06-09 16:17:24.744	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m7kk80012mm5utf9wefme	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-003] ServerCommandLog Stores Full SSH Command Output Including Potentially Sensitive Data	Every SSH command and full stdout/stderr is stored in ServerCommandLog. Since /exec accepts arbitrary commands, outputs may contain secrets, private keys, or env vars.	P3	completed	medium	coding	\N	\N	2026-06-09 12:27:32.696	2026-06-09 19:23:05.286	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m75n7000smm5uvi8ucla8	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-002] Missing Unit Tests for detectClaudeIdle Pane Pattern Matching	Idle detection needs test fixtures covering: normal idle, sub-prompt dialogs, thinking state, rate limit message, auth required message, and mid-command output.	P2	completed	medium	coding	\N	\N	2026-06-09 12:27:13.363	2026-06-10 04:11:16.403	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m756a000qmm5u69kjv3na	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-002] Missing Unit Tests for parseUTCResetTime / extractSection / parseUsage	The Claude usage parser has complex time-parsing logic with edge cases: time-only vs date+time, am/pm, midnight/noon, year rollover, and advance-to-tomorrow logic. None of it is tested.	P2	completed	medium	coding	\N	\N	2026-06-09 12:27:12.754	2026-06-10 06:03:04.238	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m75v2000tmm5uh9etij1n	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-002] Missing API Route Tests for Input Validation Edge Cases	No tests for: missing required fields on POST /api/tasks, invalid enum values on PUT, arbitrary status strings on PUT /status, empty command on /exec, or missing serverId on WebSocket connect.	P2	completed	medium	coding	\N	\N	2026-06-09 12:27:13.646	2026-06-10 07:13:56.033	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m74ve000pmm5uakasldu2	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-002] Zero Tests Exist — No Test Framework Configured	The entire codebase has no test files, no test framework (Jest, Vitest, Playwright), and no test script in package.json. Add Vitest for unit/integration and Playwright for E2E. Define minimum coverage targets.	P1	completed	medium	coding	\N	\N	2026-06-09 12:27:12.362	2026-06-09 14:47:58.636	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m6qzh000omm5u6prv3v1z	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-001] No Confirmation Dialog Before Destructive DELETE Actions	Deleting a server (cascades to logs and nullifies tasks) and deleting a project (cascades to all tasks and execution logs) happen on a single button click with no confirmation modal.	P3	completed	low	coding	\N	\N	2026-06-09 12:26:54.365	2026-06-10 09:15:16.978	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	ae47fdff-6ba3-46e5-8b26-7ce8e8369c8f	154	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m5xlc000bmm5uhz1aobxd	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-001] Review Endpoint Sends Prompt to Claude During Potentially Active Task Execution	POST /api/tasks/[id]/review calls sendTaskToTmux into the same tmux session that may be running another task. Endpoint only checks the reviewed task is 'completed', not that the server session is idle.	P1	completed	medium	coding	\N	\N	2026-06-09 12:26:16.272	2026-06-09 15:04:53.934	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m6q38000kmm5u8589hds7	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-001] Daily Report Generation Produces Plain Text, Not AI-Generated Insights	POST /api/reports/daily generates a report by string-concatenating task titles with no AI involvement. Pipe assembled task data to Claude for structured insights, highlights, and blockers.	P3	paused	low	coding	\N	\N	2026-06-09 12:26:53.205	2026-06-09 13:53:10.396	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801l2u0008p35u5fkgy43k	cmq6ldsxs0000mm5uuxbgs1s8	Server Capacity Scoring	Score each server's available capacity using usage headroom, active task slots, and health. Update every poller cycle. Surface as a capacity bar on server cards and in the task assignment dropdown.\n\nCapacity formula:\n  usageHeadroom = (100 - max(sessionPct, weekPct)) * 0.5   // 0-50\n  taskSlotRoom  = (1 - activeTaskCount/maxConcurrentTasks) * 30  // 0-30\n  healthContrib = (healthScore ?? 50) * 0.2                // 0-20\n\nDB: Add capacityScore + activeTaskCount + maxConcurrentTasks (default 10) + capacityUpdatedAt to Server.\nAPI: GET /api/servers/capacity (all servers), GET /api/servers/[id]/capacity (detailed breakdown).\nScheduler: Compute and persist capacity for all servers at the start of each poller cycle.	P2	completed	medium	coding	\N	\N	2026-06-10 11:42:34.23	2026-06-10 15:58:09.134	cmq6ke2xl0000s25u4a8i94ta	cmq6w5d940000525uus1ckhga	e9fc89bc-7d5d-4b2e-a4ed-37b76fa639ed	1098	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6p2r9300020xo94g6m6o2f	cmq6ldsxs0000mm5uuxbgs1s8	Add Project Info into the Claude prompt	Read claude.md first, after if the system start to run prompt. Please also put Project name into the Prompt. it means you talk to Claude that this project name you should find it and after that move into it and do next job. If you finish revising, do commits by no co-author and push to main.	P1	completed	medium	coding	\N	\N	2026-06-09 13:47:46.935	2026-06-09 14:13:50.344	cmq6ke2xl0000s25u4a8i94ta	\N	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801l1t0003p35u42mljvny	cmq6ldsxs0000mm5uuxbgs1s8	Task Retry Engine	Automatically retry failed tasks according to configurable per-task policies: maxRetries count, delay schedule (2min → 5min → 10min capped), and failure reason filtering. Non-retryable reasons (task_not_dispatchable, no_resource) excluded.\n\nDB: Add retryCount + maxRetries + retryAfter + lastFailReason to Task; add retryNumber + failureReason to ExecutionLog.\nAPI: POST /api/tasks/[id]/retry (manual immediate retry), maxRetries accepted in PUT /api/tasks/[id].\nWorker: After writing failed status in task-service.ts — evaluate retry eligibility, reset to pending, increment counter, set retryAfter.\nQueue advance: skip tasks where retryAfter > now.	P1	completed	low	coding	\N	\N	2026-06-10 11:42:34.193	2026-06-10 12:18:16.093	cmq6ke2xl0000s25u4a8i94ta	cmq6w5d940000525uus1ckhga	97bbca07-b025-46cd-9381-c34fea13b3a0	1094	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801l250005p35u91238dex	cmq6ldsxs0000mm5uuxbgs1s8	Task Dependency System	Allow tasks to declare prerequisite tasks. Dependent tasks stay in pending until all prerequisites reach completed or archived. Use denormalized blockedByCount for fast queue filtering. Enforce DFS cycle detection on every new dependency edge before inserting.\n\nDB: Add TaskDependency junction model (taskId + dependsOnId, unique constraint), blockedByCount to Task.\nAPI: POST /api/tasks/[id]/dependencies (body: { dependsOnId }), DELETE /api/tasks/[id]/dependencies/[depId], GET /api/tasks/[id]/dependencies. Cycle detection returns 409.\nScheduler: After task completion — decrement blockedByCount on all dependents; auto-advance to queued when blockedByCount = 0.\nQueue advance: add blockedByCount: 0 filter to findFirst.	P2	completed	high	coding	\N	\N	2026-06-10 11:42:34.205	2026-06-10 18:24:32.073	cmq6ke2xl0000s25u4a8i94ta	cmq6w5d940000525uus1ckhga	cb25ab3f-b594-4b75-811d-67630f247e98	1105	\N	\N	2026-06-10 13:59:19.765	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801l2j0006p35ur2otynp8	cmq6ldsxs0000mm5uuxbgs1s8	Project Progress Calculation	Compute and store each project's completion percentage and task distribution in real time. Calculate a velocity-based ETA from tasks completed in the last 7 days.\n\nDB: Add completionPct + totalTasks + completedTasks + failedTasks + runningTasks + pendingTasks + progressUpdatedAt + estimatedCompletionAt to Project.\nAPI: GET /api/projects/[id] returns progress fields; POST /api/projects/[id]/recalculate; GET /api/projects/[id]/velocity.\nScheduler: recalculateProjectProgress(projectId) after every task status change; full reconciliation every 10 poller cycles to prevent drift.\nFormula: completionPct = (completedTasks + archivedTasks) / totalTasks * 100.	P2	completed	low	coding	\N	\N	2026-06-10 11:42:34.219	2026-06-10 12:32:55.998	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	d6da8549-bae0-4791-ab81-4df24d9cc120	159	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801l2p0007p35ubbze322d	cmq6ldsxs0000mm5uuxbgs1s8	Queue Prioritization Engine	Replace the simple priority+createdAt queue ordering with a multi-factor score. Recompute in bulk before each queue advance using a single SQL UPDATE with CASE WHEN.\n\nScore formula:\n  base = { P1:100, P2:75, P3:50, P4:25 }[priority]\n  ageBonus = min(50, hoursWaiting * 1)\n  costPenalty = { high:-10, medium:0, low:+5 }[estimatedCostLevel]\n  depPenalty = hasDependencies ? -15 : 0\n  affinityBonus = previouslyRunOnThisServer ? +15 : 0\n\nDB: Add queueScore + queueScoreUpdatedAt to Task.\nAPI: GET /api/queue adds queueScore field; GET /api/queue?serverId=X.\nScheduler: recomputeQueueScores(serverId) in _advanceServerQueue before findFirst; order by queueScore DESC.	P2	completed	medium	coding	\N	\N	2026-06-10 11:42:34.225	2026-06-10 14:54:02.663	cmq6ke2xl0000s25u4a8i94ta	cmq6w5d940000525uus1ckhga	02011bc2-9539-482d-ac95-271dfaa93aa4	1100	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m6cs9000jmm5utxsvadki	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-001] Completion Detection Is a Fragile Heuristic — False Positives Mark Tasks Complete Prematurely	detectClaudeIdle checks last 6 pane lines for '>' and absence of spinners. Sub-prompts like 'Create file? [y/n] >' trigger false completion, causing the next queued task to be sent mid-dialog.	P2	completed	medium	coding	\N	\N	2026-06-09 12:26:35.961	2026-06-10 08:26:05.122	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	1ab97e38-f844-4b54-9cef-4bc25d85550f	154	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6tl7wz000x0xlaa48zwz9i	cmq6ldsxs0000mm5uuxbgs1s8	Fix auth_required false positive on Claude usage refresh	## Problem\n\nWhen clicking "Refresh" on the Claude Usage panel (server detail page), users occasionally get:\n\n> auth_required: Claude CLI is not authenticated. SSH in and run `claude login`.\n\nThis is a false positive — Claude is actually authenticated, but the tmux pane happens to contain login-related text at the moment of capture.\n\n## Root Cause\n\nIn `lib/ssh-claude-tmux.ts`, `fetchClaudeUsageViaTmux()` does a pre-flight pane capture (step 2) and checks for auth-required text:\n\n```typescript\nif (/not\\s+logged\\s+in|please\\s+log\\s*in|run\\s+claude\\s+login/i.test(before)) {\n  return { success: false, status: "auth_required", ... };\n}\n```\n\nThis can be triggered by:\n1. **Token/session expiry** — Claude CLI shows a re-auth prompt in the tmux pane; the refresh catches it mid-prompt.\n2. **Stale pane content** — After a server reboot or tmux restart, the pane briefly shows startup/login text before Claude is fully initialized.\n3. **Transient network interruption** — Claude CLI drops and re-shows a login screen momentarily.\n\n## Desired Behaviour\n\n- If the pane shows auth-required text, retry the capture once or twice (with a short delay) before declaring `auth_required`.\n- Alternatively, after detecting `auth_required`, automatically attempt to re-launch Claude in the tmux session and retry, rather than surfacing the error immediately to the user.\n- At minimum, surface a more actionable message that distinguishes a transient glitch from a genuine de-authentication.\n\n## Files to Change\n\n- `lib/ssh-claude-tmux.ts` — add retry logic in `fetchClaudeUsageViaTmux()` around the auth check\n- `app/servers/[id]/page.tsx` — optionally auto-retry the refresh on `auth_required` once before showing the banner	P3	completed	low	coding	\N	\N	2026-06-09 15:54:06.803	2026-06-10 08:26:05.131	cmq6ke2xl0000s25u4a8i94ta	cmq6w5d940000525uus1ckhga	f1d29797-7d55-420d-afeb-b153b535955f	1121	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq7o2b6j0002td5utqrl0mgu	cmq6ldsxs0000mm5uuxbgs1s8	Display Claude Session and Weekly Reset Times on Agents Page	Please update the Agents page to show Claude usage reset times in the agents table.\n\nCurrent Agents page table columns include:\n\n* Agent\n* Status\n* Session\n* Week\n* Mode\n* Tasks\n* Details\n\nPlease enhance the `Session` and `Week` columns.\n\nRequirements:\n\n1. Session column\n\n   * Keep the existing session usage progress bar and percentage.\n   * Add a small secondary text below the bar showing the session reset time.\n   * Display format:\n     `Resets in 2h 15m`\n   * If unavailable, show:\n     `Reset unknown`\n\n2. Week column\n\n   * Keep the existing weekly usage progress bar and percentage.\n   * Add a small secondary text below the bar showing the weekly reset time.\n   * Display format:\n     `Resets in 3d 4h`\n   * If unavailable, show:\n     `Reset unknown`\n\n3. Data model / API\n\n   * Extend the Agents page usage data to include:\n\n     * `sessionResetAt`\n     * `weekResetAt`\n   * Use ISO datetime strings internally.\n   * Format the reset countdown only in the frontend.\n\n4. UI\n\n   * Keep the table compact.\n   * Use muted/small text for reset time.\n   * Do not change the overall layout of the Agents page.\n   * Make sure the reset text aligns nicely under each usage bar.\n\n5. Also update:\n\n   * TypeScript types\n   * mock/seed data\n   * API response mapping\n   * any existing tests related to Agents page usage rendering\n\n6. Validation\n\n   * Run lint and tests.\n   * Fix any issues found before committing.\n\n7. Commit and push\n\n   * Commit the changes directly.\n   * Do NOT add any co-author attribution.\n   * Push the branch to the remote repository.\n\nCommit message:\n\n`feat(agents): display session and weekly usage reset times`\n\nPR title:\n\n`Display Claude Session and Weekly Reset Times on Agents Page`\n\nAfter pushing, provide:\n\n* Changed files\n* Commit SHA\n* Branch name\n* Brief implementation summary\n* Screenshot of the updated Agents page	P1	completed	medium	coding	\N	\N	2026-06-10 06:07:12.667	2026-06-10 06:15:04.195	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	\N	\N	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq6m8zx40013mm5u211k8k6y	cmq6ldsxs0000mm5uuxbgs1s8	[TICKET-004] Business Logic Scattered Across API Route Handlers — No Service Layer	Task dispatch logic, usage threshold checks, idle detection, queue advancement, and auto-run decisions all live directly in API route files. Extract lib/task-service.ts with dispatchTask, checkAndAdvanceQueue, reviewTask.	P2	completed	high	coding	\N	\N	2026-06-09 12:28:39.257	2026-06-10 08:47:30.544	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	0814564d-4e02-4625-9663-63eaaeb58ff1	154	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vu63200160xmsftpfjjtx	cmq6ldsxs0000mm5uuxbgs1s8	Add dark mode support using Tailwind CSS v4 and system preference detection	The app is light-mode only. Tailwind CSS v4 supports dark mode via @media (prefers-color-scheme: dark) or a data-theme attribute. Implement: (1) add dark: variants to all pages and shared components (ui.tsx, Nav.tsx, StatusBadge.tsx), (2) define dark-mode token overrides in app/globals.css under @media (prefers-color-scheme: dark), (3) add a theme toggle button in the Nav sidebar footer that cycles light/dark/system, persisting the preference to localStorage, (4) ensure WCAG AA contrast is maintained in dark mode - use zinc-100 for primary text on zinc-900 backgrounds. The terminal page (xterm.js) already has its own dark theme - no changes needed there.	P3	completed	medium	coding	\N	\N	2026-06-11 02:32:35.918	2026-06-11 06:56:22.663	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	29894797-ec0d-4d61-88bb-93413cb86806	89	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vrq4d00070xmsbohb72sq	cmq6ldsxs0000mm5uuxbgs1s8	Implement webhook notifications for task completion and failure	There is currently zero notification mechanism when tasks complete or fail. An agent can finish a 2-hour job overnight and the operator has no idea until they manually check.\n\nImplementation:\n1. Add `WEBHOOK_URL` env var support (and optionally `WEBHOOK_SECRET` for HMAC signing).\n2. Create `lib/notification.ts` that POSTs a JSON payload `{ event, taskId, title, status, agentId, serverId, timestamp }` to the webhook URL.\n3. Call `emitNotification()` from the task status-update path: after any transition to `completed` or `failed` (in `lib/task-transitions.ts` or the poller).\n4. Add a Settings page (or extend the dashboard) with a webhook URL input + test-fire button.\n5. Optionally add Discord/Slack presets that format the payload as a rich embed.\n\nAcceptance: when a task transitions to completed/failed, an HTTP POST fires to the configured webhook URL with the task details. The notification fires for both manual runs and poller-driven completions.	P1	completed	medium	coding	\N	\N	2026-06-11 02:30:41.917	2026-06-11 02:46:24.365	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	ff94026c-7413-48b4-97d0-5b4ebc6d4121	98	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801l1h0002p35uvfsbrex0	cmq6ldsxs0000mm5uuxbgs1s8	Zombie Task Detection	Detect tasks stuck in running state with zero measurable progress beyond a configurable stall threshold. Compare current tmux pane line count against stored tmuxOutputOffset across two consecutive poller cycles before confirming. Auto-fail confirmed zombies and kill their per-task tmux session.\n\nDB: Add SystemConfig model (key/value pairs for thresholds), timeoutMinutes + lastProgressAt + stallDetectedAt to Task.\nAPI: GET /api/tasks?stalled=true, POST /api/tasks/[id]/force-fail, GET/PUT /api/admin/config.\nScheduler: detectZombieTasks() every poller cycle — two-cycle confirmation before failing.\nDefault thresholds: stall_threshold_minutes=30, confirm_cycles=2.	P1	completed	medium	coding	\N	\N	2026-06-10 11:42:34.181	2026-06-10 12:09:31.687	cmq6ke2xl0000s25u4a8i94ta	cmq6w5d940000525uus1ckhga	5c3ccb61-e6a1-4ed1-af00-2dccf5d5ddd7	1094	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801l3f000cp35usrt9i0zy	cmq6ldsxs0000mm5uuxbgs1s8	Task Template Library	Pre-defined reusable task templates with {{variable}} placeholder substitution. Ship 5 built-in templates: Code Review, Write Tests, Fix Bug, Update Documentation, Refactor. Operators can create custom templates. Built-in templates cannot be edited or deleted.\n\nDB: Add TaskTemplate model (name + category + taskType + estimatedCostLevel + priority + titleTemplate + descriptionTemplate + variables JSON + isBuiltIn + usageCount).\nAPI: GET/POST /api/task-templates, GET/PUT/DELETE /api/task-templates/[id], POST /api/task-templates/[id]/use (body: { projectId, variables }) returns created Task.\nVariable substitution: safe regex-based replacement — no eval or template engines.\nUI: /task-templates browse page; "Create from Template" modal with variable form on project/tasks pages.	P3	completed	low	coding	\N	\N	2026-06-10 11:42:34.251	2026-06-10 16:04:19.81	cmq6ke2xl0000s25u4a8i94ta	cmq6w5d940000525uus1ckhga	aa690311-7e70-4840-8d2d-d034ee349bc0	1094	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801l2y0009p35ubjvn4tnh	cmq6ldsxs0000mm5uuxbgs1s8	Usage-Based Auto Pause & Resume	When a server or agent hits the 90% usage threshold, create a ScheduledResume record targeting the exact quota reset time. A poller step fires the resume the moment that time arrives — eliminating 60+ wasted dispatch skip cycles per quota period.\n\nDB: Add ScheduledResume model (resourceType + resourceId + resumeAt + triggered); add pausedDueToUsage + pausedAt + autoPauseEnabled to Server and Agent.\nAPI: POST /api/servers/[id]/pause, POST /api/servers/[id]/resume, POST /api/agents/[id]/pause, POST /api/agents/[id]/resume, GET /api/scheduled-resumes.\nScheduler: On usage-blocked dispatch — upsert ScheduledResume; triggerDueResumes() step every cycle queries where resumeAt <= now AND triggered=false.\nUI: Resume countdown timer on server/agent cards and detail pages.	P2	completed	medium	coding	\N	\N	2026-06-10 11:42:34.235	2026-06-10 12:17:16.215	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	e81a46ac-ef05-4bd7-b9a8-cff4585751d1	159	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801l3p000ep35u17l9fnsv	cmq6ldsxs0000mm5uuxbgs1s8	Weekly Productivity Analytics	Aggregate weekly throughput, quality, performance, and infrastructure metrics into WeeklyAnalytics records. Use PostgreSQL percentile_cont() for p50/p95 execution time. Surface as charts on a new /analytics dashboard page.\n\nMetrics: tasksCompleted/Failed/Retried/TimedOut/Created, reviewsRun/Passed/Failed, avgExecutionMinutes + p50 + p95, workerRecoveries, dispatchFailures.\n\nDB: Add WeeklyAnalytics model (weekStart + weekEnd + metric counters); unique on weekStart.\nAPI: GET /api/analytics/weekly (last 12 weeks), GET /api/analytics/weekly/[weekStart], GET /api/analytics/summary (rolling 30-day KPIs).\nScheduler: Every Monday 1 AM UTC — compute prior-week analytics from ExecutionLog + AuditEvent using GROUP BY and window functions (single query, not app-level loops).\nUI: /analytics page with completion bar chart, failure rate trend, duration trend, KPI summary cards.	P3	completed	medium	coding	\N	\N	2026-06-10 11:42:34.261	2026-06-10 18:18:32.268	cmq6ke2xl0000s25u4a8i94ta	cmq6w5d940000525uus1ckhga	4b0c31e0-01f7-4a12-928d-13a59e44bc27	1096	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801l3t000fp35uph6q5drr	cmq6ldsxs0000mm5uuxbgs1s8	AI Task Reviewer	After a task completes, automatically queue it for a structured Claude quality review with a 5-minute grace delay. Gate progression to archived on a "done" verdict; reset to pending on "incomplete". Process max 3 reviews per poller cycle. Extends existing reviewTask() in task-service.ts to support agent sessions.\n\nDB: Add autoReviewEnabled to Project; add autoReviewEnabled + reviewStatus + reviewScheduledAt + reviewStartedAt + reviewCompletedAt + reviewVerdictNotes to Task.\nAPI: GET /api/tasks?reviewStatus=pending, POST /api/tasks/[id]/skip-review, PUT /api/projects/[id] accepts autoReviewEnabled.\nScheduler: After task completion with autoReviewEnabled=true — set reviewStatus=pending, reviewScheduledAt=now+5min. processReviewQueue() step: find due reviews, call reviewTask(), update reviewStatus.\nGuard: do not run review if server has other running tasks.	P3	completed	medium	coding	\N	\N	2026-06-10 11:42:34.265	2026-06-10 19:16:32.605	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	e310b461-45e9-4d45-ad90-b4223c715581	94	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801l48000gp35upcewu3fv	cmq6ldsxs0000mm5uuxbgs1s8	Project Improvement Scanner	Periodically compile all completed task summaries for a project and send them to Claude for gap analysis: unmet goals, coverage gaps, architectural patterns, and suggested next tasks. Parse structured JSON findings. Truncate to last 50 task summaries for context safety.\n\nDB: Add ProjectScan model (scanType + status + findings JSON + findingsCount + scannedTaskCount + runOnServerId + startedAt + completedAt); add autoScanEnabled + scanFrequencyDays + lastScannedAt to Project.\nAPI: POST /api/projects/[id]/scan (body: { scanType }), GET /api/projects/[id]/scans, GET /api/project-scans/[id].\nScheduler: Weekly runDueProjectScans() for active projects with autoScanEnabled=true, completionPct > 50%, and scan overdue.\nScan prompt: XML-fenced task summaries via prompt-sanitiser.ts; require JSON output { findings: [{ type, title, severity, description, suggestedAction }] }.	P3	completed	high	coding	\N	\N	2026-06-10 11:42:34.28	2026-06-10 19:22:28.376	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	87e95994-74c0-4924-911a-b72fc2726f6b	94	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vt0il000m0xms72cipceo	cmq6ldsxs0000mm5uuxbgs1s8	Add WebSocket auto-reconnect with exponential backoff in terminal	The InteractiveTerminal component (app/_components/InteractiveTerminal.tsx) has no reconnect logic. If the WS connection drops (network hiccup, server restart), the terminal silently dies and the user must reload the page. Implement exponential backoff reconnect: attempt after 1s, 2s, 4s, 8s up to 30s max. Show a status overlay (Reconnecting... attempt N) during backoff. Reset attempt count on successful connect. Preserve the terminal output buffer across reconnects so the user does not lose history. Also apply the same pattern to the poller-driven status updates on the task detail page.	P2	completed	low	coding	\N	\N	2026-06-11 02:31:42.045	2026-06-11 03:46:24.792	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	b6c9f778-2def-4115-a458-a07135b10375	89	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vsncr000f0xmsks224km2	cmq6ldsxs0000mm5uuxbgs1s8	Add task export to CSV and JSON from tasks list page	No export functionality exists. Add GET /api/tasks/export?format=csv|json&projectId=&status= route that streams tasks with their execution logs. On the /tasks page add an Export button (top-right, secondary style) that opens a small modal for format and filter selection. JSON should include nested executionLogs array. CSV should flatten key fields. Honour existing status/project filter state so the user exports what they are currently viewing.	P2	completed	low	coding	\N	\N	2026-06-11 02:31:24.987	2026-06-11 03:51:29.125	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	2b6f87f9-f2d9-40ed-a93e-26d3217c3dd3	89	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801l1z0004p35uz19utqpy	cmq6ldsxs0000mm5uuxbgs1s8	Task Execution Timeout	Enforce a hard wall-clock timeout per task. Resolution order: task.timeoutMinutes → server/agent defaultTaskTimeoutMinutes → SystemConfig global default (120 min). Auto-fail tasks that exceed their timeout; log errorMessage = "Execution timeout (Xmin)"; kill the per-task tmux session.\n\nDB: Task.timeoutMinutes (shared with Zombie Detection task), defaultTaskTimeoutMinutes on Server and Agent.\nAPI: timeoutMinutes accepted in POST /api/tasks and PUT /api/tasks/[id]; timeoutExpiresAt computed field in GET /api/tasks/[id].\nScheduler: In running-task scan loop — read startedAt from latest ExecutionLog, compare against resolved timeout.\nUI: Progress bar showing elapsed vs timeout on running task detail page. Build this task first — simplest, highest-value P0 change.	P1	completed	low	coding	\N	\N	2026-06-10 11:42:34.199	2026-06-10 11:52:46.057	cmq6ke2xl0000s25u4a8i94ta	cmq6w5d940000525uus1ckhga	75b6694b-f1f3-4eee-bb4d-96b81a0f4494	1094	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801kq60000p35uw6lst3ro	cmq6ldsxs0000mm5uuxbgs1s8	Worker Health Monitor	Continuously evaluate and score the health of every server and agent. Track SSH latency, tmux session presence, Claude process state, and consecutive failure streaks. Store WorkerHealth history records each cycle. Surface a 0–100 health score on server/agent cards and a /admin/health dashboard. Prerequisite for Auto Recovery.\n\nDB: Add WorkerHealth model, healthScore + consecutiveFailures + lastHealthCheckAt to Server and Agent.\nAPI: GET /api/health, GET /api/servers/[id]/health, GET /api/agents/[id]/health.\nScheduler: runHealthChecks() every 5 poller cycles (~5 min) using Promise.allSettled across all workers.\nHealth score: SSH responds +40, tmux present +30, Claude online +20, latency <500ms +10.	P1	completed	medium	coding	\N	\N	2026-06-10 11:42:33.774	2026-06-10 11:58:46.042	cmq6ke2xl0000s25u4a8i94ta	cmq6w5d940000525uus1ckhga	c456ac4a-532e-4164-a40a-8f5125035a04	1094	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801l170001p35uxhm9nigd	cmq6ldsxs0000mm5uuxbgs1s8	Claude Session Auto Recovery	When a worker's Claude session is detected offline (tmuxMissing or consecutiveFailures >= 2), automatically call launchClaudeInTmux() to relaunch it without human intervention. Log every recovery attempt to RecoveryLog. Respect maxRecoveryAttempts cap (default 3). Add manual Recover button on server/agent detail pages.\n\nDB: Add RecoveryLog model, autoRecovery + recoveryAttempts + maxRecoveryAttempts + lastRecoveryAt to Server and Agent.\nAPI: POST /api/servers/[id]/recover, POST /api/agents/[id]/recover, GET /api/recovery-logs.\nScheduler: After health checks — for offline workers with autoRecovery=true and attempts < max, call launchClaudeInTmux().\nSafety: only recover workers with no running tasks to avoid session corruption.	P1	completed	medium	coding	\N	\N	2026-06-10 11:42:34.173	2026-06-10 12:04:28.215	cmq6ke2xl0000s25u4a8i94ta	cmq6w5d940000525uus1ckhga	70497908-2a2a-49f3-950d-873e05ade3e9	1094	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801l4b000hp35u6q21s4je	cmq6ldsxs0000mm5uuxbgs1s8	Technical Debt Detector	Run a specialised debt-detection scan against a project's task history to surface TODO/FIXME patterns, deferred tests, hardcoded values, missing error handling, undocumented APIs, security shortcuts, and performance anti-patterns. Store findings as DebtItem records with severity and category.\n\nDB: Add DebtItem model (title + description + severity: low/medium/high/critical + category: architecture/testing/documentation/security/performance + status: open/acknowledged/in_progress/resolved/wont_fix + evidence JSON + resolvedAt).\nAPI: GET /api/projects/[id]/debt (filter by status/severity), PUT /api/debt/[id], GET /api/debt?status=open&severity=high.\nUI: Debt Register tab on project detail; severity-coloured items; "Create task to resolve" button; open debt count badge; debt trend chart (open items over 8 weeks).\nReuses ProjectScan infrastructure with scanType="debt".	P3	completed	medium	coding	\N	\N	2026-06-10 11:42:34.283	2026-06-10 19:28:28.466	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	437a99f0-68c2-44ef-8878-6c2a51fac30a	94	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801l4f000ip35ubcwhnamd	cmq6ldsxs0000mm5uuxbgs1s8	Backlog Generator	Convert scan findings, debt items, and review verdicts into structured TaskSuggestion records. Human-approval staging area before suggestions become real Tasks. Cap at 10 suggestions per scan. De-duplicate against existing open suggestions.\n\nDB: Add TaskSuggestion model (sourceType: scan/debt/review/manual + sourceId + title + description + priority + taskType + estimatedCostLevel + rationale + status: pending_review/approved/rejected/converted + convertedTaskId + reviewNote + reviewedAt).\nAPI: GET /api/projects/[id]/suggestions, POST /api/suggestions/[id]/approve (creates Task), POST /api/suggestions/[id]/reject, PUT /api/suggestions/[id] (edit before approving), POST /api/projects/[id]/generate-suggestions.\nUI: Suggestions tab on project page with approve/reject/edit flow, bulk approve/reject, suggestion count badge.\nScheduler: After ProjectScan completes — generateSuggestionsFromScan(scanId); after DebtItem created — generateSuggestionFromDebt(debtItemId).	P3	completed	medium	coding	\N	\N	2026-06-10 11:42:34.287	2026-06-10 21:07:34.535	cmq6ke2xl0000s25u4a8i94ta	cmq6w5d940000525uus1ckhga	91e66938-775a-4f89-a84f-49cbc31b5d56	1105	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801l35000ap35ul2ionidc	cmq6ldsxs0000mm5uuxbgs1s8	Audit Timeline	Immutable, append-only event log for every meaningful state change across tasks, projects, servers, and agents. Add emitAudit(event) helper in lib/audit.ts; call it from task-service.ts, task-dispatch.ts, instrumentation.node.ts, and API routes. Foundational data layer for analytics and the improvement engine.\n\nDB: Add AuditEvent model (entityType + entityId + eventType + actorType + payload JSON + createdAt); composite indexes on (entityType, entityId, createdAt) and (eventType, createdAt).\nInitial events: task.created/queued/dispatched/completed/failed/timeout/retried, task.review.sent/done/incomplete, agent.offline/recovered, server.status_changed.\nAPI: GET /api/audit?entityType=X&entityId=Y, GET /api/audit?eventType=Z&since=W (cursor-paginated, 50/page).\nUI: Timeline tab on task detail, activity feed on project page, /admin/audit search page.	P2	completed	medium	coding	\N	\N	2026-06-10 11:42:34.241	2026-06-10 12:26:56.222	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	7ef188b4-989b-43f6-9cc4-18bad6ba211a	159	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801l3a000bp35uthvxo7l1	cmq6ldsxs0000mm5uuxbgs1s8	Execution History Storage	Enrich ExecutionLog with structured metadata captured at completion: durationMs, exitReason, paneCapture (last 200 lines of tmux output), retryNumber, failureReason. Add PostgreSQL tsvector full-text search. Nightly archival of logs older than 90 days.\n\nDB: Extend ExecutionLog with durationMs + exitReason (completion_marker/idle_fallback/timeout/manual/error) + paneCapture + retryNumber + failureReason + archivedAt + searchVector (tsvector); GIN index on searchVector.\nAPI: GET /api/execution-logs?taskId&projectId&since&exitReason, GET /api/execution-logs/[id] (full detail with paneCapture), GET /api/execution-logs/search?q= (full-text).\nScheduler: Store paneCapture at completion; nightly archival step at 1 AM UTC (set archivedAt, compress logText to null, keep outputSummary and metadata).	P2	completed	medium	coding	\N	\N	2026-06-10 11:42:34.246	2026-06-10 12:40:55.97	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	7eb7c039-529a-4119-8763-9fe5ee0023b2	158	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801l3k000dp35uluceb7un	cmq6ldsxs0000mm5uuxbgs1s8	Automated Daily Reports	Generate daily operational reports automatically via the poller at 1 AM UTC, without requiring a manual POST /api/reports/daily. Refactor existing generation logic into a shared generateDailyReport() service function used by both the poller and the manual API route.\n\nDB: Extend DailyReport with queuedCount + retriedCount + timedOutCount + recoveryCount + avgExecutionMinutes + activeServerCount + activeAgentCount + generatedBy ("manual"|"auto") + periodStart + periodEnd.\nAPI: GET /api/reports/daily/[date] (YYYY-MM-DD), GET /api/reports/daily/latest.\nScheduler: runDailyReportIfNeeded() in poller — if today's UTC-date report is missing and hour >= 1, generate with generatedBy="auto".\nUI: "Auto" badge on auto-generated reports; today's summary widget on dashboard.	P3	completed	low	coding	\N	\N	2026-06-10 11:42:34.256	2026-06-10 16:20:03.907	cmq6ke2xl0000s25u4a8i94ta	cmq6w5d940000525uus1ckhga	1392cd93-d686-4d8a-b60f-02656b854066	1094	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vt0ld000q0xms01l89pp0	cmq6ldsxs0000mm5uuxbgs1s8	Add bulk task operations: multi-select, bulk assign, bulk archive	The tasks list page (/tasks) has no multi-select. Users cannot reassign or archive multiple tasks at once - they must open each individually. Implement: (1) checkbox column on the task table that enables row selection, (2) a sticky action bar that appears when 1+ rows are selected showing count + action buttons: Assign to Server, Assign to Agent, Mark Completed, Archive, (3) POST /api/tasks/bulk route accepting { ids: string[], action: string, payload?: object }. The route must validate all IDs belong to the authenticated session and run updates in a single Prisma transaction.	P2	completed	medium	coding	\N	\N	2026-06-11 02:31:42.145	2026-06-11 03:57:26.984	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	f0a45e57-68ac-42f8-afc1-831a8caeee83	89	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vs37n000b0xmsnu2oqier	cmq6ldsxs0000mm5uuxbgs1s8	Expand Playwright E2E test suite to cover all major page flows	Only 2 Playwright spec files exist (`e2e/core-workflows.spec.ts` and `e2e/exec-security.spec.ts`). The majority of the application (agents, task detail, analytics, admin pages, queue management) has zero E2E coverage.\n\nAdd specs for:\n- `e2e/auth.spec.ts` — login/logout, session expiry redirect\n- `e2e/projects.spec.ts` — create, view, edit, task count badges\n- `e2e/tasks.spec.ts` — create task, assign to server/agent, status badge updates, run-blocked state\n- `e2e/agents.spec.ts` — create agent, view usage, launch-claude button\n- `e2e/queue.spec.ts` — queue ordering, priority display\n- `e2e/reports.spec.ts` — generate daily report, view report\n- `e2e/admin.spec.ts` — audit log viewer, worker health dashboard\n\nEach spec must run against a seeded test DB (use `npm run db:seed` in beforeAll). Add a `test:e2e:ci` script to `package.json` that runs headless with retries=1.	P2	completed	high	coding	\N	\N	2026-06-11 02:30:58.883	2026-06-11 04:22:29.368	cmq6ke2xl0000s25u4a8i94ta	cmq6w5d940000525uus1ckhga	ee88ee43-e126-4509-9567-b13f5c754d0d	1100	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vteq2000u0xmsrzxq2w1t	cmq6ldsxs0000mm5uuxbgs1s8	Add weekly and monthly report generation alongside daily reports	Only daily reports exist (DailyReport model, /api/reports/daily, /reports/daily page). Add WeeklyReport and MonthlyReport models via migration with fields: weekStart/monthStart date, taskCounts by status, agentUtilisation summary, topCompletedTasks JSON, reportText. Create /api/reports/weekly and /api/reports/monthly POST endpoints that trigger Claude-based summarization (same pattern as daily). Add /reports/weekly and /reports/monthly pages. Add report-type tabs at the top of the reports section in Nav. Weekly auto-generate on Monday, monthly on the 1st, via the background poller.	P3	completed	high	coding	\N	\N	2026-06-11 02:32:00.458	2026-06-11 04:34:11.027	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	12ce3ecb-6433-47bc-b7e9-381b807fd86f	89	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vsnes000h0xms0j94euut	cmq6ldsxs0000mm5uuxbgs1s8	Add full-text search across tasks, projects, and agents	No search exists. Implement a global search bar in the Nav sidebar that accepts a query string and hits GET /api/search?q= returning ranked results grouped by entity type (tasks, projects, agents, servers). Use Postgres ILIKE or ts_vector for the query. Results should show entity type chip, title, and a short excerpt. Clicking a result navigates to the entity detail page. Debounce the input 300ms. Show empty state when no results.	P2	completed	medium	coding	\N	\N	2026-06-11 02:31:25.06	2026-06-11 04:27:21.018	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	c36fc66b-51d5-44e2-a5bc-e71e3c9a6853	89	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vtryv00100xmsjp3bvgo3	cmq6ldsxs0000mm5uuxbgs1s8	Add docker-compose.yml for one-command local development setup	New contributors must manually create a Docker container for Postgres, configure env vars, and run migrations before the app works. Reduce this to docker compose up. Create docker-compose.yml with: (1) postgres:16 service with the correct credentials matching .env.example, persistent volume, and healthcheck, (2) optional app service (Next.js + ws-server via concurrently) that depends_on postgres. Add a depends_on healthcheck wait so the app doesnt start before Postgres is ready. Update README.md with a Getting Started section. The compose file must work on both Apple Silicon (arm64) and amd64.	P3	completed	low	maintenance	\N	\N	2026-06-11 02:32:17.623	2026-06-11 07:00:06.373	cmq6ke2xl0000s25u4a8i94ta	cmq6w5d940000525uus1ckhga	9b367d5c-58bb-47e6-9102-1b4e1fe4f39b	1089	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq801l4i000jp35uipdtjawc	cmq6ldsxs0000mm5uuxbgs1s8	Continuous Improvement Engine	Orchestrate the complete autonomous improvement cycle as an 8-state machine per project. One state transition per poller tick — non-blocking. Configurable automationLevel per project.\n\nState machine: idle → scanning → detecting_debt → generating_suggestions → awaiting_approval → executing → reviewing → completed → (schedule next cycle)\n\nAutomation levels:\n  0 = disabled\n  1 = scan + detect + suggest, stops for human approval\n  2 = level 1 + auto-approve low-severity suggestions\n  3 = fully autonomous (auto-approve all, auto-queue, auto-execute, auto-review, auto-rescan)\n\nSafeguards: max 10 tasks/cycle, Level 3 blocked when agent uses full_autonomous Claude permission mode, 7-day cycle hard timeout, all actions emit AuditEvent records.\n\nDB: Add ImprovementCycle model (status + automationLevel + scanId + counters + cycleError + startedAt + completedAt + nextCycleAt); add improvementAutomationLevel + cycleFrequencyDays + lastImprovementCycleAt + nextImprovementCycleAt to Project.\nAPI: POST /api/projects/[id]/improvement-cycle, GET /api/projects/[id]/improvement-cycles, GET /api/improvement-cycles/[id], POST /api/improvement-cycles/[id]/cancel.\nScheduler: advanceImprovementCycles() every poller cycle; start new cycles for due projects.	P3	completed	high	coding	\N	\N	2026-06-10 11:42:34.29	2026-06-10 19:41:32.845	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	8c782108-bbc1-493c-be9e-9a6096d6dfe7	103	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vterw000w0xms74u219q3	cmq6ldsxs0000mm5uuxbgs1s8	Implement time-based scheduled task dispatch (run task at specific datetime)	Tasks can only be queued for immediate dispatch. There is no way to say run this task at 2am on Tuesday. The ScheduledResume model already exists for paused-task resumption - extend this pattern. Add scheduledFor: DateTime? field to Task via migration. In the background poller, after the existing queue-advance logic, check for pending tasks where scheduledFor <= now() and auto-transition them to queued. On the task detail page, add a Schedule Run section with a datetime-local picker and a Set Schedule button. Show the scheduled time with a cancel button if set. In the task list, show a clock icon and formatted time for scheduled tasks.	P3	completed	medium	coding	\N	\N	2026-06-11 02:32:00.524	2026-06-11 05:14:01.823	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	933a9b50-bf97-467b-9cc6-abb5fc5a93a7	89	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vud7c001a0xmsat6b7ywk	cmq6ldsxs0000mm5uuxbgs1s8	Add database backup and restore scripts with automated daily snapshot	No backup mechanism exists. A single database corruption or accidental db:reset wipes all task history. Create: (1) scripts/db-backup.sh that runs pg_dump into a timestamped .sql.gz file in a configurable BACKUP_DIR (default ./backups/), (2) scripts/db-restore.sh that accepts a backup file path and restores after confirmation prompt, (3) add npm scripts: db:backup and db:restore, (4) add a cron entry example in README.md for daily automated backup (0 2 * * * cd /path && npm run db:backup), (5) add backup rotation: keep last 7 daily + 4 weekly snapshots, deleting older files. Scripts must work with the Docker-hosted Postgres using PGPASSWORD from DATABASE_URL parsing. No external dependencies beyond pg_dump.	P4	running	low	maintenance	\N	\N	2026-06-11 02:32:45.144	2026-06-11 07:12:18.996	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	5774fe01-75b4-4198-96f8-6ce0f5275448	89	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vteoe000s0xms4o0opkg6	cmq6ldsxs0000mm5uuxbgs1s8	Build task dependency DAG visualization on project detail page	lib/task-dependency.ts implements dependency logic and cycle detection, but there is no visual representation. On the /projects/[id] page, add a Dependency Graph tab next to the task list. Render a directed acyclic graph using a lightweight library (d3-dag, dagre-d3, or plain SVG with elk.js layout). Nodes are tasks (coloured by status badge colour). Directed edges show dependsOn relationships. Clicking a node navigates to the task detail. Also add dependency management to the task detail page: a multi-select to add/remove dependencies with the cycle-detection API validating each change client-side before saving.	P2	completed	high	coding	\N	\N	2026-06-11 02:32:00.398	2026-06-11 03:03:28.577	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	a2d40d1b-b8a7-4cd9-8119-dbd946729513	89	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vrbrn00050xmsc3knzsma	cmq6ldsxs0000mm5uuxbgs1s8	Fix production build: resolve ssh2 / Turbopack incompatibility	The production build (`next build`) is completely broken because `ssh2` emits a `non-ecmascript placeable asset` error under Turbopack. This blocks any production deployment.\n\nAccepted approaches (pick best):\n1. Move all `ssh2` usage into a standalone Node.js service (already partially done with `ws-server.ts`) and have Next.js call it over HTTP/IPC instead of importing `ssh` directly.\n2. Wrap SSH routes with a dynamic import guard (`{ ssr: false }` equivalent for route handlers) using `next.config.ts` `serverExternalPackages: [ssh2]`.\n3. Replace `ssh2` with the system `ssh` CLI via `child_process.spawn` where full PTY is not needed.\n\nAcceptance: `npm run build` completes without error. All existing SSH routes continue to work in both dev and prod.	P1	completed	high	coding	\N	\N	2026-06-11 02:30:23.315	2026-06-11 04:05:29.351	cmq6ke2xl0000s25u4a8i94ta	cmq6w5d940000525uus1ckhga	1337e459-63f5-4a69-aa4c-dae61812a845	1096	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vsnbo000d0xmsrr2fbhca	cmq6ldsxs0000mm5uuxbgs1s8	Set up GitHub Actions CI/CD pipeline (lint, unit tests, E2E)	No automated CI/CD exists. Create .github/workflows/ci.yml with 4 jobs: (1) Lint on Node 22, (2) unit tests with coverage gate >70%, (3) production build check, (4) E2E via Postgres service container running migrate+seed+playwright headless. Cache node_modules on package-lock hash. Add README.md CI badge.	P2	completed	medium	maintenance	\N	\N	2026-06-11 02:31:24.948	2026-06-11 02:51:28.561	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	2d981641-140e-4f40-9a8a-555a0cf9f73d	89	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vu61w00140xms13kqf5dy	cmq6ldsxs0000mm5uuxbgs1s8	Enable improvement cycle automation (level 1) for WorkerAI project	The WorkerAI project currently has improvementAutomationLevel=0 (disabled) and lastImprovementCycleAt=null. The 8-state improvement cycle engine (lib/improvement-cycle-service.ts) is fully implemented but never triggered for this project. Set automationLevel=1 for the WorkerAI project so the engine runs scan+detect_debt+generate_suggestions and pauses at awaiting_approval for human review before any tasks are created. Set scanFrequencyDays=7 and cycleFrequencyDays=14. Verify the poller picks up the cycle on the next tick by checking logs. Add a UI control on the project detail page to change automation level (0-3) with a confirmation dialog explaining each level.	P3	completed	low	maintenance	\N	\N	2026-06-11 02:32:35.876	2026-06-11 05:01:45.63	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	703e7611-4260-4867-aa1d-5f86334e1b4f	89	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vtrwi000y0xmscdmrqzyd	cmq6ldsxs0000mm5uuxbgs1s8	Track actual Claude API cost per execution and surface cost analytics	Tasks have estimatedCostLevel (low/medium/high) but no actual cost data. Claude CLI outputs token usage in /usage. Parse the session token counts from claudeUsageRaw and map them to USD cost using the Sonnet/Haiku/Opus pricing table from lib/constants.ts. Add actualCostUsd: Float? and tokenCount: Int? to ExecutionLog via migration. Populate these fields when a task completes (compare usage before/after dispatch). On the analytics page, add a Cost tab showing total spend by project, agent, and time period. Show cost per completed task in the task list as a small badge.	P3	completed	medium	coding	\N	\N	2026-06-11 02:32:17.538	2026-06-11 05:35:29.824	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	143b7a90-431e-4a5a-89f6-2ad72c8cc5f4	89	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vu64700180xmsprc9twqh	cmq6ldsxs0000mm5uuxbgs1s8	Add keyboard shortcuts for power-user navigation and common actions	No keyboard shortcuts exist. Add a global keydown handler (useEffect in a root layout or dedicated hook): N = new task (opens create modal on /tasks), P = go to projects, Q = go to queue, D = go to dashboard, / = focus search bar (once T17 search is implemented), Escape = close any open modal. Add a keyboard shortcut reference panel accessible via ? key or a Help button in the Nav footer. On list pages, add J/K for moving selection up/down and Enter to open detail. Implement using a lightweight hook (no external dep) that checks event.key and ignores shortcuts when focus is inside an input/textarea/select.	P4	completed	low	coding	\N	\N	2026-06-11 02:32:35.96	2026-06-11 07:12:18.201	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	0bc406b5-c2e4-4685-828d-d001925836fe	89	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vts0p00120xms50ew2d47	cmq6ldsxs0000mm5uuxbgs1s8	Improve mobile responsiveness: collapsible sidebar, responsive tables	The current layout uses a fixed-width sidebar (app/_components/Nav.tsx) with no mobile breakpoint. On screens below 768px the sidebar and content both render full-width, overlapping. Tables in tasks/projects list pages overflow horizontally. Fix: (1) convert the sidebar to a slide-in drawer on mobile triggered by a hamburger menu button in a top app bar, (2) make data tables horizontally scrollable on small screens with overflow-x-auto wrapper, (3) collapse non-essential table columns below md breakpoint using hidden md:table-cell, (4) test at 375px and 768px viewport widths. Use Tailwind responsive prefixes only - no JS resize listeners.	P3	completed	medium	coding	\N	\N	2026-06-11 02:32:17.689	2026-06-11 04:38:55.981	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	1659158f-dd77-467e-9e7b-571c7c1e4853	89	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vt0jo000o0xms5jqwfipu	cmq6ldsxs0000mm5uuxbgs1s8	Implement SSH connection pool to eliminate per-request handshake overhead	Every call to execSSH() in lib/ssh.ts opens a new TCP connection + SSH handshake (~300-800ms). High-frequency polling (usage refresh every 60s across multiple servers) accumulates latency and burns resources. Implement a connection pool using ssh2 Client keepalive or a globalThis-scoped Map<serverKey, ConnEntry> where ConnEntry holds an active ssh2.Client and a last-used timestamp. Reuse the connection if it is healthy; reconnect otherwise. Add a configurable pool TTL (default 5 min idle). Ensure the pool entry is released on error so failed connections dont block. Add a cleanup interval that prunes stale entries.	P2	completed	medium	coding	\N	\N	2026-06-11 02:31:42.084	2026-06-11 02:57:28.596	cmq6ke2xl0000s25u4a8i94ta	cmq6wcl430001525urn13fvcx	6a84db3d-c0ba-4cf3-a390-9e13063f1243	89	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
cmq8vrq5y00090xmsgixurzts	cmq6ldsxs0000mm5uuxbgs1s8	Fix tmux rate-limit false positive in fetchClaudeUsageViaTmux	Documented bug in `lib/ssh-claude-tmux.ts`: if a previous task left a `rate_limit_error` or `too many requests` message visible in the tmux pane, `fetchClaudeUsageViaTmux` returns `status: rate_limited` even when the API is healthy. The workaround (press Enter manually) is terrible UX and breaks automated polling.\n\nFix:\n1. Before scanning for rate-limit strings, send a blank Enter keystroke to the tmux pane and wait 300ms to push stale text up and out of the visible window.\n2. OR: track a `lastUsageFetchedAt` offset and only scan the lines *after* the last successful fetch (use `tmuxOutputOffset` pattern already used in task completion detection).\n3. OR: clear the approach by capturing pane line count before/after `/usage` injection and only reading delta lines.\n\nThe fix must not break the happy path where a real rate limit is correctly detected. Add a unit test in `lib/__tests__/` that covers both the true-positive and false-positive cases.	P1	completed	low	coding	Fixed fetchClaudeUsageViaTmux rate-limit false positive: added blank Enter keystroke (tmux send-keys "\\"\\"" Enter && sleep 0.3) before the preflight pane capture in lib/ssh-claude-tmux.ts. This scrolls stale rate-limit error text from previous tasks into the scrollback buffer so it falls outside the PREFLIGHT_TAIL_LINES tail window that classifyPreflightPane inspects, preventing false positives while preserving true-positive detection. Updated 2 existing tests in lib/__tests__/usage-poller.test.ts to account for the new SSH call. Added 8 unit tests in lib/__tests__/preflight-rate-limit-fix.test.ts covering: blank Enter ordering (before first capture-pane), session targeting, rate_limit_error/rate-limit/too-many-requests true-positive variants, false-positive prevention (clean pane → not rate_limited, /usage reached), and blank Enter failure resilience. TypeScript clean; 71 tests pass.	\N	2026-06-11 02:30:41.974	2026-06-11 05:13:23.26	cmq6ke2xl0000s25u4a8i94ta	cmq6w5d940000525uus1ckhga	098c437e-f821-45fc-9e2c-d56854625063	1096	\N	\N	\N	\N	\N	0	\N	0	0	f	\N	\N	\N	\N	\N	\N
\.


--
-- TOC entry 3809 (class 0 OID 38960)
-- Dependencies: 231
-- Data for Name: TaskDependency; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TaskDependency" (id, "taskId", "dependsOnId", "createdAt") FROM stdin;
\.


--
-- TOC entry 3813 (class 0 OID 43437)
-- Dependencies: 235
-- Data for Name: TaskSuggestion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TaskSuggestion" (id, "projectId", "sourceType", "sourceId", title, description, priority, "taskType", "estimatedCostLevel", rationale, status, "convertedTaskId", "reviewNote", "reviewedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 3807 (class 0 OID 37230)
-- Dependencies: 229
-- Data for Name: TaskTemplate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TaskTemplate" (id, name, category, "taskType", "estimatedCostLevel", priority, "titleTemplate", "descriptionTemplate", variables, "isBuiltIn", "usageCount", "createdAt", "updatedAt") FROM stdin;
cmq8dvpwb000n0xnw5flim2rs	Write Tests	testing	coding	medium	P3	Write tests for {{target}}	Write comprehensive tests for {{target}}.\n\nRequirements:\n- Cover happy-path and edge cases\n- Mock external dependencies where appropriate\n- Follow the existing test conventions in the project\n\n{{extra_context}}	["target", "extra_context"]	t	0	2026-06-10 18:09:55.163	2026-06-10 18:09:55.163
cmq8dvpwq000o0xnwjw3633c5	Fix Bug	bugfix	coding	medium	P2	Fix: {{bug_description}}	## Bug Description\n{{bug_description}}\n\n## Steps to Reproduce\n{{steps_to_reproduce}}\n\n## Expected Behaviour\n{{expected_behaviour}}\n\n## Notes\n{{extra_context}}	["bug_description", "steps_to_reproduce", "expected_behaviour", "extra_context"]	t	0	2026-06-10 18:09:55.178	2026-06-10 18:09:55.178
cmq8dvpww000p0xnw1zqtdsg6	Update Documentation	docs	writing	low	P3	Update docs: {{target}}	Update the documentation for {{target}}.\n\nScope of changes:\n{{scope}}\n\nEnsure the documentation is accurate, clear, and consistent with the current implementation.\n\n{{extra_context}}	["target", "scope", "extra_context"]	t	0	2026-06-10 18:09:55.184	2026-06-10 18:09:55.184
cmq8dvpx0000q0xnwwi42mpbt	Refactor	refactor	coding	medium	P3	Refactor: {{target}}	Refactor {{target}} to improve {{goal}}.\n\nGuidelines:\n- Preserve existing behaviour (all tests must still pass)\n- Keep changes focused — do not expand scope\n- Document any non-obvious decisions\n\n{{extra_context}}	["target", "goal", "extra_context"]	t	0	2026-06-10 18:09:55.188	2026-06-10 18:09:55.188
cmq8dvpw4000m0xnw7g2e16a8	Code Review	review	review	low	P2	Code review: {{target}}	Review the code in {{target}} for correctness, readability, and adherence to project conventions.\n\nFocus areas:\n- Logic errors and edge cases\n- Code style and naming\n- Test coverage\n- Security concerns\n\n{{extra_context}}	["target", "extra_context"]	t	1	2026-06-10 18:09:55.157	2026-06-11 06:49:49.348
\.


--
-- TOC entry 3808 (class 0 OID 38245)
-- Dependencies: 230
-- Data for Name: WeeklyAnalytics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WeeklyAnalytics" (id, "weekStart", "weekEnd", "tasksCompleted", "tasksFailed", "tasksRetried", "tasksTimedOut", "tasksCreated", "reviewsRun", "reviewsPassed", "reviewsFailed", "avgExecutionMinutes", "p50ExecutionMinutes", "p95ExecutionMinutes", "workerRecoveries", "dispatchFailures", "createdAt") FROM stdin;
cmq8zamy100430xms6lvd0o9z	2026-06-01 00:00:00	2026-06-08 00:00:00	0	0	0	0	0	0	0	0	\N	\N	\N	0	0	2026-06-11 04:09:23.113
\.


--
-- TOC entry 3814 (class 0 OID 44569)
-- Dependencies: 236
-- Data for Name: WeeklyReport; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WeeklyReport" (id, "weekStart", "completedCount", "failedCount", "runningCount", "pendingCount", "queuedCount", "retriedCount", "timedOutCount", "recoveryCount", "avgExecutionMinutes", "activeServerCount", "activeAgentCount", "agentUtilisation", "topCompletedTasks", "generatedBy", "reportText", "createdAt") FROM stdin;
cmq94zk03006he8msptgeou0l	2026-06-08 00:00:00	20	0	0	0	4	0	0	4	8.2	0	2	[{"name": "agent-2", "count": 16}, {"name": "agent-1", "count": 4}]	[{"title": "Track actual Claude API cost per execution and surface cost analytics", "project": "WorkerAI"}, {"title": "Implement time-based scheduled task dispatch (run task at specific datetime)", "project": "WorkerAI"}, {"title": "Fix tmux rate-limit false positive in fetchClaudeUsageViaTmux", "project": "WorkerAI"}, {"title": "Enable improvement cycle automation (level 1) for WorkerAI project", "project": "WorkerAI"}, {"title": "Improve mobile responsiveness: collapsible sidebar, responsive tables", "project": "WorkerAI"}, {"title": "Add weekly and monthly report generation alongside daily reports", "project": "WorkerAI"}, {"title": "Add full-text search across tasks, projects, and agents", "project": "WorkerAI"}, {"title": "Expand Playwright E2E test suite to cover all major page flows", "project": "WorkerAI"}, {"title": "Fix production build: resolve ssh2 / Turbopack incompatibility", "project": "WorkerAI"}, {"title": "Add bulk task operations: multi-select, bulk assign, bulk archive", "project": "WorkerAI"}]	manual	# Weekly Report — 2026-06-08 to 2026-06-14\n\n## Summary\nCompleted: 20 | Failed: 0 | Timeouts: 0 | Retried: 0 | Recoveries: 4\nAvg Execution: 8.2m\nActive Servers: 0 | Active Agents: 2\n\n## Top Completed Tasks\n- [WorkerAI] Track actual Claude API cost per execution and surface cost analytics\n- [WorkerAI] Implement time-based scheduled task dispatch (run task at specific datetime)\n- [WorkerAI] Fix tmux rate-limit false positive in fetchClaudeUsageViaTmux\n- [WorkerAI] Enable improvement cycle automation (level 1) for WorkerAI project\n- [WorkerAI] Improve mobile responsiveness: collapsible sidebar, responsive tables\n- [WorkerAI] Add weekly and monthly report generation alongside daily reports\n- [WorkerAI] Add full-text search across tasks, projects, and agents\n- [WorkerAI] Expand Playwright E2E test suite to cover all major page flows\n- [WorkerAI] Fix production build: resolve ssh2 / Turbopack incompatibility\n- [WorkerAI] Add bulk task operations: multi-select, bulk assign, bulk archive\n\n## Agent Utilisation\n- agent-2: 16 tasks\n- agent-1: 4 tasks\n\n## Current State\nRunning: 0 | Pending: 0 | Queued: 4\n	2026-06-11 06:48:43.779
\.


--
-- TOC entry 3801 (class 0 OID 27687)
-- Dependencies: 223
-- Data for Name: WorkerHealth; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WorkerHealth" (id, "serverId", "agentId", "healthScore", "sshOk", "tmuxOk", "claudeOk", "latencyMs", "errorMessage", "checkedAt") FROM stdin;
cmq80ynhs0003fy5ulbnzf8b8	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	82	\N	2026-06-10 12:08:17.008
cmq80ynja0004fy5ub6b2ivq3	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	115	\N	2026-06-10 12:08:17.062
cmq80ynjx0005fy5ubj1zosoc	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	110	\N	2026-06-10 12:08:17.085
cmq8152ji0001n75umtwq69rf	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	66	\N	2026-06-10 12:13:16.446
cmq8152jp0002n75urps4ae09	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	98	\N	2026-06-10 12:13:16.453
cmq8152k50003n75uv6irj6ru	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	106	\N	2026-06-10 12:13:16.469
cmq81bi0u0005n75u3zthip6z	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	116	\N	2026-06-10 12:18:16.446
cmq81bi130006n75u0ve3vodh	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	87	\N	2026-06-10 12:18:16.455
cmq81bi1a0007n75ugs1uovec	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	116	\N	2026-06-10 12:18:16.462
cmq81issx0000qr5ul6h7ctmg	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	164	\N	2026-06-10 12:23:57.01
cmq81istb0001qr5ui5wintkv	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	92	\N	2026-06-10 12:23:57.023
cmq81isv40002qr5uhr9ta1uq	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	168	\N	2026-06-10 12:23:57.088
cmq81p7qa0004qr5ut5qclsm7	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	83	\N	2026-06-10 12:28:56.29
cmq81p7r40005qr5uv9ypbt8o	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	118	\N	2026-06-10 12:28:56.32
cmq81p7s30006qr5uael5j1cp	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	123	\N	2026-06-10 12:28:56.355
cmq81vn9o0008qr5uznwte33l	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	124	\N	2026-06-10 12:33:56.364
cmq81vnai0009qr5ueqms0n2b	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	129	\N	2026-06-10 12:33:56.394
cmq81vnav000aqr5usqeattv4	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	133	\N	2026-06-10 12:33:56.407
cmq8222se000bqr5u687x4664	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	112	\N	2026-06-10 12:38:56.414
cmq8222sr000cqr5u2by5hn85	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	77	\N	2026-06-10 12:38:56.427
cmq8222td000dqr5u93x4xe62	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	119	\N	2026-06-10 12:38:56.449
cmq82cqsy0002m05umunksl22	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	70	\N	2026-06-10 12:47:14.098
cmq82cqtv0003m05ufk4d4rz6	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	97	\N	2026-06-10 12:47:14.131
cmq82cqvj0004m05u342e4mmj	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	100	\N	2026-06-10 12:47:14.191
cmq82snn800000k5unwj2wa8e	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	69	\N	2026-06-10 12:59:36.501
cmq82snnh00010k5u9niwt6py	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	96	\N	2026-06-10 12:59:36.509
cmq82snnu00020k5urwlm9ukq	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	101	\N	2026-06-10 12:59:36.522
cmq82z2zp00030k5ulvhqz1q4	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	72	\N	2026-06-10 13:04:36.325
cmq82z2zz00040k5uk152j68o	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	100	\N	2026-06-10 13:04:36.336
cmq82z30p00050k5uz7pmdqhc	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	103	\N	2026-06-10 13:04:36.361
cmq835ik600060k5upe7kb1ps	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	75	\N	2026-06-10 13:09:36.438
cmq835ik800070k5uurnxp05i	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	102	\N	2026-06-10 13:09:36.44
cmq835ilw00080k5u920fz91r	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	105	\N	2026-06-10 13:09:36.501
cmq83jauz00000xpealsdzcra	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	42	\N	2026-06-10 13:20:19.643
cmq83jav400010xpeznc16yjv	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	46	\N	2026-06-10 13:20:19.648
cmq83jax000020xpejnel812e	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	51	\N	2026-06-10 13:20:19.717
cmq83pqdk00080xpe5314hhit	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	71	\N	2026-06-10 13:25:19.688
cmq83pqds00090xpe5l6jqntq	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	68	\N	2026-06-10 13:25:19.696
cmq83pqdw000a0xpe82nliko8	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	74	\N	2026-06-10 13:25:19.7
cmq83w2nb000e0xpebiq55axn	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	58	\N	2026-06-10 13:30:15.527
cmq83w2nc000f0xpeoyvep5wy	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	54	\N	2026-06-10 13:30:15.528
cmq83w2o3000g0xpee03y0xs4	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	60	\N	2026-06-10 13:30:15.555
cmq842lfv000h0xpenzgeiynb	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	72	\N	2026-06-10 13:35:19.819
cmq842lfz000i0xpeld3be4vx	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	68	\N	2026-06-10 13:35:19.823
cmq842lg5000j0xpe12e09ey2	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	72	\N	2026-06-10 13:35:19.829
cmq848xij000k0xpeuahkh46r	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	66	\N	2026-06-10 13:40:15.403
cmq848xir000l0xpefl91fgtg	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	70	\N	2026-06-10 13:40:15.411
cmq848xiz000m0xpeuu6towvk	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	67	\N	2026-06-10 13:40:15.419
cmq84fgew000n0xpe32y95mjk	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	71	\N	2026-06-10 13:45:19.832
cmq84fgfa000o0xpeteb8ubuh	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	65	\N	2026-06-10 13:45:19.846
cmq84fgfg000p0xpej3w0z0fk	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	72	\N	2026-06-10 13:45:19.852
cmq84lskz000q0xpebb1v9k21	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	68	\N	2026-06-10 13:50:15.539
cmq84lsl4000r0xpezp410ho0	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	63	\N	2026-06-10 13:50:15.544
cmq84lslr000s0xpe9gxz7j6v	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	73	\N	2026-06-10 13:50:15.567
cmq84sbem000t0xpevhouwkzt	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	69	\N	2026-06-10 13:55:19.87
cmq84sbeo000u0xpef52nr4zf	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	71	\N	2026-06-10 13:55:19.872
cmq84sbep000v0xpei234z06x	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	73	\N	2026-06-10 13:55:19.873
cmq84ynnz000w0xpes4jfbglm	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	89	\N	2026-06-10 14:00:15.695
cmq84yno6000x0xpeb54z29xp	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	88	\N	2026-06-10 14:00:15.702
cmq84ynoe000y0xpee3dxlw0n	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	88	\N	2026-06-10 14:00:15.71
cmq8556ea000z0xpeh4y3ccoh	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	103	\N	2026-06-10 14:05:19.906
cmq8556ek00100xpe8yyodcer	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	95	\N	2026-06-10 14:05:19.916
cmq8556er00110xpet3halvly	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	102	\N	2026-06-10 14:05:19.923
cmq85bilw00120xpe149qdjrm	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	93	\N	2026-06-10 14:10:15.668
cmq85bim200130xpewncu87cl	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	95	\N	2026-06-10 14:10:15.674
cmq85bim700140xpem7a6be9t	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	90	\N	2026-06-10 14:10:15.679
cmq85i1dt00150xpewxidb115	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	82	\N	2026-06-10 14:15:19.937
cmq85i1eq00160xpewfiorn8i	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	85	\N	2026-06-10 14:15:19.97
cmq85i1ez00170xpeqirftpst	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	88	\N	2026-06-10 14:15:19.979
cmq85odjb00180xpepn8cyfdz	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	90	\N	2026-06-10 14:20:15.623
cmq85odk300190xpeak49xsmz	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	83	\N	2026-06-10 14:20:15.651
cmq85odkq001a0xpezlcd8ciw	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	90	\N	2026-06-10 14:20:15.674
cmq85uwev001b0xpepmobxs4f	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	90	\N	2026-06-10 14:25:20.023
cmq85uwf6001c0xpewi70uour	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	104	\N	2026-06-10 14:25:20.034
cmq85uwf8001d0xpef34fu1xk	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	94	\N	2026-06-10 14:25:20.036
cmq8618ot001e0xpep0gdtm5l	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	45	\N	2026-06-10 14:30:15.872
cmq8618pr001f0xpe8gcc39zq	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	48	\N	2026-06-10 14:30:15.903
cmq8618pw001g0xpe35quey5n	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	42	\N	2026-06-10 14:30:15.908
cmq86aclu0000sv5ua9nukk8m	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	105	\N	2026-06-10 14:37:20.851
cmq86acm00001sv5u5vwwpese	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	106	\N	2026-06-10 14:37:20.856
cmq86acmt0002sv5ubbmhis94	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	107	\N	2026-06-10 14:37:20.885
cmq86peh90004lt5us45dyw7q	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	207	\N	2026-06-10 14:49:03.117
cmq86peig0005lt5uodd5xh1x	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	223	\N	2026-06-10 14:49:03.16
cmq86pejf0006lt5uzstr3mpn	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	217	\N	2026-06-10 14:49:03.195
cmq86vtxr000alt5uvaxwf6p8	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	84	\N	2026-06-10 14:54:03.087
cmq86vtxz000blt5uy09dakvg	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	152	\N	2026-06-10 14:54:03.095
cmq86vtzp000clt5uk6q4ay0c	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	154	\N	2026-06-10 14:54:03.157
cmq8729b4000dlt5uysr1ovfn	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	98	\N	2026-06-10 14:59:02.945
cmq8729c6000elt5uwtms3zmb	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	133	\N	2026-06-10 14:59:02.983
cmq8729d2000flt5unwhbg4l9	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	138	\N	2026-06-10 14:59:03.014
cmq87dyvj0002pw5uvjab6xjs	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	75	\N	2026-06-10 15:08:09.295
cmq87dyx10003pw5uq9hhan6b	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	108	\N	2026-06-10 15:08:09.349
cmq87dyx80004pw5u4saywy3d	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	108	\N	2026-06-10 15:08:09.356
cmq87ke6w000dpw5ul05hwl8l	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	66	\N	2026-06-10 15:13:09.08
cmq87ke7b000epw5udb0ctbjs	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	94	\N	2026-06-10 15:13:09.096
cmq87ke7r000fpw5urk30d369	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	94	\N	2026-06-10 15:13:09.111
cmq87qtrf000gpw5uyccv558g	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	179	\N	2026-06-10 15:18:09.195
cmq87qtri000hpw5ua0oehlp8	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	150	\N	2026-06-10 15:18:09.198
cmq87qtsc000ipw5ut3dk0rm6	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	179	\N	2026-06-10 15:18:09.228
cmq87x918000jpw5u26cqr55d	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	108	\N	2026-06-10 15:23:08.924
cmq87x920000kpw5uzcvrvbr1	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	111	\N	2026-06-10 15:23:08.952
cmq87x92p000lpw5uyxvtiwq9	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	110	\N	2026-06-10 15:23:08.977
cmq883omh000npw5uiuqn39td	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	76	\N	2026-06-10 15:28:09.065
cmq883on9000opw5ud3xbij4g	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	103	\N	2026-06-10 15:28:09.093
cmq883onx000ppw5uooyug80g	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	105	\N	2026-06-10 15:28:09.117
cmq88a46r000qpw5u6e61kx52	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	70	\N	2026-06-10 15:33:09.171
cmq88a46t000rpw5udmdttacs	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	96	\N	2026-06-10 15:33:09.173
cmq88a47k000spw5uxa7va97s	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	99	\N	2026-06-10 15:33:09.2
cmq88gjob000tpw5u8mp3fsj2	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	70	\N	2026-06-10 15:38:09.179
cmq88gjod000upw5usbizebs1	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	99	\N	2026-06-10 15:38:09.181
cmq88gjoo000vpw5ubbdtltzb	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	101	\N	2026-06-10 15:38:09.192
cmq88mz4k000wpw5ukitxp7l4	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	69	\N	2026-06-10 15:43:09.14
cmq88mz4z000xpw5u99f55f25	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	97	\N	2026-06-10 15:43:09.155
cmq88mz5e000ypw5u7d9573s9	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	101	\N	2026-06-10 15:43:09.17
cmq88teif0011pw5u5yatlfrz	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	68	\N	2026-06-10 15:48:09.016
cmq88tejp0012pw5uruyri74c	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	102	\N	2026-06-10 15:48:09.061
cmq88tejz0013pw5u1cxz5m50	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	112	\N	2026-06-10 15:48:09.071
cmq88zubg001epw5uvyl8kaop	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	82	\N	2026-06-10 15:53:09.436
cmq88zubx001fpw5umhcn03cq	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	110	\N	2026-06-10 15:53:09.454
cmq88zucr001gpw5u05e1e9bn	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	107	\N	2026-06-10 15:53:09.483
cmq896aei001opw5u9fj381ng	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	99	\N	2026-06-10 15:58:10.218
cmq896af1001ppw5ujpvpiizt	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	147	\N	2026-06-10 15:58:10.237
cmq896agg001qpw5ul1k1efq6	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	179	\N	2026-06-10 15:58:10.288
cmq89cpgr001spw5um8h1biya	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	83	\N	2026-06-10 16:03:09.676
cmq89cphg001tpw5utgi6nn7k	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	118	\N	2026-06-10 16:03:09.7
cmq89cphl001upw5uxrbuatm4	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	119	\N	2026-06-10 16:03:09.705
cmq89j0hn00016c5up39htpt7	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	76	\N	2026-06-10 16:08:03.899
cmq89j0it00026c5uzi3thpoz	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	123	\N	2026-06-10 16:08:03.941
cmq89j0jr00036c5uammqm8e8	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	128	\N	2026-06-10 16:08:03.975
cmq89pg1o000b6c5uioqlniaf	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	105	\N	2026-06-10 16:13:03.996
cmq89pg2p000c6c5uvgwulhwj	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	108	\N	2026-06-10 16:13:04.033
cmq89pg3c000d6c5uuyyliy75	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	108	\N	2026-06-10 16:13:04.056
cmq89vvj5000h6c5ut1s7phg6	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	84	\N	2026-06-10 16:18:04.001
cmq89vvk4000i6c5uruv6v57u	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	122	\N	2026-06-10 16:18:04.036
cmq89vvkw000j6c5uh58o7jr8	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	140	\N	2026-06-10 16:18:04.064
cmq8a2ash000t6c5ud3fkxbov	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	69	\N	2026-06-10 16:23:03.713
cmq8a2asn000u6c5u5w6snayu	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	98	\N	2026-06-10 16:23:03.719
cmq8a2ati000v6c5uy1nh6tqa	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	102	\N	2026-06-10 16:23:03.75
cmq8ahz4z00010xn2wlaznlu8	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	47	\N	2026-06-10 16:35:15.107
cmq8ahz5000020xn2as1erk1e	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	50	\N	2026-06-10 16:35:15.108
cmq8ahz6w00030xn2pqmkstgx	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	50	\N	2026-06-10 16:35:15.176
cmq8aoens00040xn2pvtx5dnk	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	51	\N	2026-06-10 16:40:15.16
cmq8aoeo800050xn2y7oacw0l	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	56	\N	2026-06-10 16:40:15.176
cmq8aoeoc00060xn25p2mstj4	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	56	\N	2026-06-10 16:40:15.18
cmq8auu6w00070xn2gbszkiim	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	45	\N	2026-06-10 16:45:15.224
cmq8auu7600080xn2s8x5efxw	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	45	\N	2026-06-10 16:45:15.234
cmq8auu7700090xn2ddl9vu6k	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	49	\N	2026-06-10 16:45:15.235
cmq8b19kx000a0xn25il68l3r	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	51	\N	2026-06-10 16:50:15.105
cmq8b19m0000b0xn26xgpdi5f	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	54	\N	2026-06-10 16:50:15.144
cmq8b19m1000c0xn2pq795tfe	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	54	\N	2026-06-10 16:50:15.145
cmq8b7p39000e0xn26lxacaol	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	55	\N	2026-06-10 16:55:15.141
cmq8b7p3i000f0xn2mkjpveot	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	59	\N	2026-06-10 16:55:15.15
cmq8b7p4e000g0xn2rrcfwgh3	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	67	\N	2026-06-10 16:55:15.182
cmq8be4qn000h0xn2o4wtvp4w	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	59	\N	2026-06-10 17:00:15.359
cmq8be4r2000i0xn266rqngsi	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	61	\N	2026-06-10 17:00:15.374
cmq8be4r6000j0xn2bqq1qwim	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	61	\N	2026-06-10 17:00:15.378
cmq8bkk4l000k0xn2tp4g40w9	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	52	\N	2026-06-10 17:05:15.238
cmq8bkk4w000l0xn2270shb64	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	48	\N	2026-06-10 17:05:15.248
cmq8bkk5g000m0xn2sef58nw0	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	52	\N	2026-06-10 17:05:15.268
cmq8bqzlh000n0xn2i1o50ghx	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	54	\N	2026-06-10 17:10:15.221
cmq8bqzlp000o0xn2gu4295zh	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	56	\N	2026-06-10 17:10:15.229
cmq8bqzmb000p0xn2so1gthnx	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	58	\N	2026-06-10 17:10:15.251
cmq8bxf21000q0xn2hlao5xgs	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	52	\N	2026-06-10 17:15:15.193
cmq8bxf2w000r0xn26ywzwl4e	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	52	\N	2026-06-10 17:15:15.224
cmq8bxf35000s0xn2faaqw05r	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	55	\N	2026-06-10 17:15:15.233
cmq8c3ukz000t0xn23epoz52a	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	52	\N	2026-06-10 17:20:15.251
cmq8c3ula000u0xn25of1noyq	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	60	\N	2026-06-10 17:20:15.262
cmq8c3uld000v0xn2cyx5bcsx	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	60	\N	2026-06-10 17:20:15.265
cmq8caa5r000w0xn2aad44ofg	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	58	\N	2026-06-10 17:25:15.375
cmq8caa61000x0xn2vibynfih	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	59	\N	2026-06-10 17:25:15.385
cmq8caa62000y0xn286pctwpw	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	56	\N	2026-06-10 17:25:15.386
cmq8cgpl4000z0xn2s43jk5w2	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	64	\N	2026-06-10 17:30:15.304
cmq8cgplc00100xn2g2mrtqzh	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	60	\N	2026-06-10 17:30:15.312
cmq8cgplk00110xn22c6u8xtc	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	67	\N	2026-06-10 17:30:15.32
cmq8cn52r00120xn22u4h9a69	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	59	\N	2026-06-10 17:35:15.315
cmq8cn52z00130xn2ag8fvc4f	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	57	\N	2026-06-10 17:35:15.323
cmq8cn53400140xn28a0miwm8	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	61	\N	2026-06-10 17:35:15.328
cmq8ctkog00150xn2om5ywyds	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	64	\N	2026-06-10 17:40:15.472
cmq8ctkoi00160xn2qu1h0riu	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	67	\N	2026-06-10 17:40:15.474
cmq8ctkon00170xn21ktza1om	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	70	\N	2026-06-10 17:40:15.479
cmq8d007g00180xn2cm4q7guh	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	50	\N	2026-06-10 17:45:15.532
cmq8d007o00190xn2yjhfmd46	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	56	\N	2026-06-10 17:45:15.54
cmq8d008a001a0xn2an6i4ozp	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	55	\N	2026-06-10 17:45:15.562
cmq8d6fpt001b0xn2jgfko62v	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	51	\N	2026-06-10 17:50:15.569
cmq8d6fqt001c0xn2bubgkqxr	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	53	\N	2026-06-10 17:50:15.606
cmq8d6fqz001d0xn2azt4vzvt	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	56	\N	2026-06-10 17:50:15.611
cmq8dnijt00050xnwtu89u3yc	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	55	\N	2026-06-10 18:03:32.393
cmq8dnim300060xnwdmcf1vy7	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	59	\N	2026-06-10 18:03:32.475
cmq8dnim500070xnwrvewj921	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	59	\N	2026-06-10 18:03:32.477
cmq8dty49000i0xnwp0fdvlus	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	77	\N	2026-06-10 18:08:32.506
cmq8dty4f000j0xnwxlbq9quv	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	86	\N	2026-06-10 18:08:32.511
cmq8dty4s000k0xnwb2391jcn	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	83	\N	2026-06-10 18:08:32.524
cmq8e0djo000v0xnw0orsnuux	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	64	\N	2026-06-10 18:13:32.437
cmq8e0dk5000w0xnw8rpqk9me	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	71	\N	2026-06-10 18:13:32.453
cmq8e0dkc000x0xnwsgb7ryvr	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	71	\N	2026-06-10 18:13:32.46
cmq8e6tm300110xnw32gb05wn	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	83	\N	2026-06-10 18:18:33.195
cmq8e6tma00120xnwgcgbcpcw	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	76	\N	2026-06-10 18:18:33.202
cmq8e6tmb00130xnwmklge8fr	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	68	\N	2026-06-10 18:18:33.203
cmq8ed57r00140xnwv8lz0a8m	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	73	\N	2026-06-10 18:23:28.169
cmq8ed57w00150xnw6v8qeksj	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	68	\N	2026-06-10 18:23:28.172
cmq8ed58h00160xnwxfjwejcn	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	74	\N	2026-06-10 18:23:28.194
cmq8ejnsv00190xnw90uiqshh	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	57	\N	2026-06-10 18:28:32.191
cmq8ejnt7001a0xnwtutxbfcz	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	60	\N	2026-06-10 18:28:32.203
cmq8ejnti001b0xnw6ai86t86	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	61	\N	2026-06-10 18:28:32.214
cmq8eq048001c0xnwwu5ouszh	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	44	\N	2026-06-10 18:33:28.088
cmq8eq049001d0xnwbmf2fi2m	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	47	\N	2026-06-10 18:33:28.089
cmq8eq062001e0xnwgwxgqgxd	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	47	\N	2026-06-10 18:33:28.154
cmq8ewitr001f0xnw3vljlhj8	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	53	\N	2026-06-10 18:38:32.271
cmq8ewits001g0xnw5sp3zmph	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	54	\N	2026-06-10 18:38:32.272
cmq8ewivs001h0xnwe8fcvaif	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	56	\N	2026-06-10 18:38:32.344
cmq8f2yc9001i0xnwr6t5fnhg	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	42	\N	2026-06-10 18:43:32.313
cmq8f2ycc001j0xnwqk22lq5q	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	44	\N	2026-06-10 18:43:32.316
cmq8f2yd1001k0xnwiq7iyvjs	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	47	\N	2026-06-10 18:43:32.341
cmq8f9dwc001l0xnwtla7jryq	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	55	\N	2026-06-10 18:48:32.412
cmq8f9dwk001m0xnw6oujr2h1	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	56	\N	2026-06-10 18:48:32.42
cmq8f9dwl001n0xnw7pprshaw	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	60	\N	2026-06-10 18:48:32.421
cmq8fftd4001o0xnwnuys0seh	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	65	\N	2026-06-10 18:53:32.392
cmq8fftdf001p0xnwata2w1dz	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	68	\N	2026-06-10 18:53:32.403
cmq8fftdn001q0xnwpnm8yyt8	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	68	\N	2026-06-10 18:53:32.411
cmq8fm8sz001r0xnwtfozupjp	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	57	\N	2026-06-10 18:58:32.339
cmq8fm8t9001s0xnw5ba9gjib	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	65	\N	2026-06-10 18:58:32.349
cmq8fm8tf001t0xnwz9klwiak	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	59	\N	2026-06-10 18:58:32.355
cmq8fsogt001u0xnw1y0gy80x	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	56	\N	2026-06-10 19:03:32.573
cmq8fsogv001v0xnw6rbq8isc	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	53	\N	2026-06-10 19:03:32.575
cmq8fsohi001w0xnwwmmm5z8m	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	60	\N	2026-06-10 19:03:32.598
cmq8fz0mf001x0xnwm8erkje0	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	47	\N	2026-06-10 19:08:28.263
cmq8fz0ms001y0xnwi4jryyd7	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	49	\N	2026-06-10 19:08:28.276
cmq8fz0mv001z0xnwi1tc9z8b	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	43	\N	2026-06-10 19:08:28.279
cmq8g5jh600220xnwwbhhqnta	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	61	\N	2026-06-10 19:13:32.634
cmq8g5jh800230xnwf2y2m9aa	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	74	\N	2026-06-10 19:13:32.636
cmq8g5jhf00240xnwsmaihlfk	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	62	\N	2026-06-10 19:13:32.643
cmq8gbvsa00280xnw5hkqqmi4	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	72	\N	2026-06-10 19:18:28.522
cmq8gbvt100290xnw9ke2egbp	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	78	\N	2026-06-10 19:18:28.55
cmq8gbvtc002a0xnwkz424ujq	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	83	\N	2026-06-10 19:18:28.56
cmq8giem6002e0xnwwaqgi9e7	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	78	\N	2026-06-10 19:23:32.862
cmq8giem9002f0xnwvfjidd9b	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	75	\N	2026-06-10 19:23:32.865
cmq8gieog002g0xnwnk78r4df	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	84	\N	2026-06-10 19:23:32.944
cmq8gora4002k0xnwcplty32h	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	88	\N	2026-06-10 19:28:29.212
cmq8gorag002l0xnw29ucndfv	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	98	\N	2026-06-10 19:28:29.224
cmq8gorb0002m0xnwrst99lnc	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	91	\N	2026-06-10 19:28:29.244
cmq8gv9ls002n0xnwpv9y179n	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	70	\N	2026-06-10 19:33:32.896
cmq8gv9m8002o0xnwt8uedhul	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	70	\N	2026-06-10 19:33:32.912
cmq8gv9mg002p0xnweu9uk8qw	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	73	\N	2026-06-10 19:33:32.92
cmq8h1lz1002q0xnwtz4bxkkp	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	76	\N	2026-06-10 19:38:28.861
cmq8h1lzf002r0xnwcjo7ncp5	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	73	\N	2026-06-10 19:38:28.875
cmq8h1m02002s0xnwzohknz7l	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	72	\N	2026-06-10 19:38:28.898
cmq8h84o6002u0xnw4ztmahfx	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	58	\N	2026-06-10 19:43:33.03
cmq8h84ol002v0xnwhx6aey2a	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	66	\N	2026-06-10 19:43:33.045
cmq8h84om002w0xnwclk0ub9i	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	60	\N	2026-06-10 19:43:33.046
cmq8hegy6002x0xnw7tv7h4u1	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	59	\N	2026-06-10 19:48:28.878
cmq8hegz3002y0xnw06nw0jdr	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	65	\N	2026-06-10 19:48:28.912
cmq8hegz9002z0xnwbfqbnstv	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	61	\N	2026-06-10 19:48:28.917
cmq8hkztp00300xnwz8zrm1o8	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	55	\N	2026-06-10 19:53:33.277
cmq8hkztt00310xnwhxivkhnh	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	54	\N	2026-06-10 19:53:33.281
cmq8hkzuf00320xnwf2hvfmbx	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	56	\N	2026-06-10 19:53:33.303
cmq8hrc3400330xnwtaqd3ffq	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	61	\N	2026-06-10 19:58:29.104
cmq8hrc3a00340xnwq66g85sy	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	62	\N	2026-06-10 19:58:29.111
cmq8hrc3g00350xnww2271ciw	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	61	\N	2026-06-10 19:58:29.116
cmq8hxrnl00360xnwnz2zw6yr	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	51	\N	2026-06-10 20:03:29.217
cmq8hxrnr00370xnwx2dzxupg	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	47	\N	2026-06-10 20:03:29.223
cmq8hxroc00380xnwz9y0ge48	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	49	\N	2026-06-10 20:03:29.244
cmq8i477l00390xnwm2ugjouw	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	54	\N	2026-06-10 20:08:29.313
cmq8i477v003a0xnwb4l9i3ge	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	57	\N	2026-06-10 20:08:29.323
cmq8i478k003b0xnwq78ep13l	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	53	\N	2026-06-10 20:08:29.348
cmq8iamsr003c0xnwxzv9j6ri	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	46	\N	2026-06-10 20:13:29.451
cmq8iamt2003d0xnwljj4mxdu	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	50	\N	2026-06-10 20:13:29.462
cmq8iamte003e0xnw37wjy3ty	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	51	\N	2026-06-10 20:13:29.474
cmq8ih2bn003f0xnw0rbrd5u2	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	43	\N	2026-06-10 20:18:29.507
cmq8ih2bt003g0xnw1kj352pj	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	49	\N	2026-06-10 20:18:29.513
cmq8ih2dr003h0xnwwdp71vre	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	53	\N	2026-06-10 20:18:29.583
cmq8inhx2003i0xnweblbl3ll	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	64	\N	2026-06-10 20:23:29.654
cmq8inhx8003j0xnw2q5wvvgf	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	61	\N	2026-06-10 20:23:29.66
cmq8inhxg003k0xnwc09a4ph1	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	66	\N	2026-06-10 20:23:29.668
cmq8iu0qd003l0xnwr0qgcrvs	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	58	\N	2026-06-10 20:28:33.974
cmq8iu0qe003m0xnwhy0sqv92	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	60	\N	2026-06-10 20:28:33.974
cmq8iu0qg003n0xnwfj1lvjlr	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	56	\N	2026-06-10 20:28:33.976
cmq8j0g75003o0xnwjhl7urib	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	64	\N	2026-06-10 20:33:33.954
cmq8j0g7e003p0xnw7p5kj5j4	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	65	\N	2026-06-10 20:33:33.962
cmq8j0g7p003q0xnwajxewswx	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	66	\N	2026-06-10 20:33:33.973
cmq8j6vsk003r0xnwz6tqdoum	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	54	\N	2026-06-10 20:38:34.1
cmq8j6vsp003s0xnwbxvwsjpe	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	55	\N	2026-06-10 20:38:34.105
cmq8j6vsq003t0xnw8m09zigx	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	56	\N	2026-06-10 20:38:34.106
cmq8jdbaw003u0xnwbfbub3ej	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	57	\N	2026-06-10 20:43:34.136
cmq8jdbb4003v0xnwmtvu0ox7	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	56	\N	2026-06-10 20:43:34.144
cmq8jdbb8003w0xnwajupn65c	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	58	\N	2026-06-10 20:43:34.148
cmq8jjqxb003x0xnw7881i11q	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	47	\N	2026-06-10 20:48:34.319
cmq8jjqxj003y0xnwq2dba6ph	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	42	\N	2026-06-10 20:48:34.327
cmq8jjqxp003z0xnwonkvu5me	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	44	\N	2026-06-10 20:48:34.333
cmq8jq6hf00400xnwytror061	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	48	\N	2026-06-10 20:53:34.419
cmq8jq6hk00410xnwiw6tm452	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	50	\N	2026-06-10 20:53:34.424
cmq8jq6hl00420xnwr0psgixd	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	53	\N	2026-06-10 20:53:34.426
cmq8jwlwo00430xnwylfak7t3	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	49	\N	2026-06-10 20:58:34.344
cmq8jwlxl00440xnwfnd54qo8	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	52	\N	2026-06-10 20:58:34.377
cmq8jwlxo00450xnwm995cciv	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	54	\N	2026-06-10 20:58:34.38
cmq8k31ot00480xnwwjqa2fe6	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	70	\N	2026-06-10 21:03:34.733
cmq8k31p000490xnwdx9vztfc	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	76	\N	2026-06-10 21:03:34.74
cmq8k31p6004a0xnw92nvgkkc	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	77	\N	2026-06-10 21:03:34.746
cmq8k9dsn004c0xnwg5r5b6tm	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	52	\N	2026-06-10 21:08:30.359
cmq8k9dsz004e0xnwe7ftfkjc	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	47	\N	2026-06-10 21:08:30.371
cmq8k9dsy004d0xnw07tj5sop	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	45	\N	2026-06-10 21:08:30.37
cmq8kfwm9004g0xnwfpwwoy45	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	57	\N	2026-06-10 21:13:34.689
cmq8kfwm8004f0xnwz8uqj0ci	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	58	\N	2026-06-10 21:13:34.688
cmq8kfwma004h0xnwm5m41s8r	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	55	\N	2026-06-10 21:13:34.69
cmq8km8yb004i0xnwtcyzrebf	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	47	\N	2026-06-10 21:18:30.611
cmq8km8yk004j0xnwbuobxrr8	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	49	\N	2026-06-10 21:18:30.62
cmq8km8yl004k0xnwrcv42t82	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	45	\N	2026-06-10 21:18:30.621
cmq8ksrrl004l0xnwal993s07	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	44	\N	2026-06-10 21:23:34.929
cmq8ksrrq004m0xnwudftvrv9	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	53	\N	2026-06-10 21:23:34.934
cmq8ksrrz004n0xnwh6bchrms	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	49	\N	2026-06-10 21:23:34.943
cmq8kz438004o0xnwqj3r4dkk	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	44	\N	2026-06-10 21:28:30.836
cmq8kz43g004p0xnwtlexzj8m	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	44	\N	2026-06-10 21:28:30.844
cmq8kz442004q0xnw3gdm2uk0	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	45	\N	2026-06-10 21:28:30.866
cmq8l5msj004r0xnw77o8z2km	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	42	\N	2026-06-10 21:33:35.011
cmq8l5mth004s0xnwk04ni1p9	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	47	\N	2026-06-10 21:33:35.045
cmq8l5mtm004t0xnwal04hcuy	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	46	\N	2026-06-10 21:33:35.05
cmq8lc2eq004u0xnwhxjfuuk5	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	50	\N	2026-06-10 21:38:35.186
cmq8lc2ew004v0xnwmxfuo51r	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	47	\N	2026-06-10 21:38:35.192
cmq8lc2f2004w0xnwok9qchm4	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	51	\N	2026-06-10 21:38:35.198
cmq8lihvl004x0xnw1sdlslr0	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	66	\N	2026-06-10 21:43:35.169
cmq8lihvn004y0xnwu1akhx5w	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	60	\N	2026-06-10 21:43:35.171
cmq8lihvo004z0xnwdbvbvpy4	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	63	\N	2026-06-10 21:43:35.172
cmq8loxjo00500xnwoj9q2rkf	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	56	\N	2026-06-10 21:48:35.412
cmq8loxjw00510xnw40t6gghm	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	55	\N	2026-06-10 21:48:35.42
cmq8loxkg00520xnw2hbxprhe	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	61	\N	2026-06-10 21:48:35.44
cmq8lvcyg00530xnwq4c97cgd	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	53	\N	2026-06-10 21:53:35.32
cmq8lvcyn00540xnwxy1xiqsa	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	58	\N	2026-06-10 21:53:35.327
cmq8lvcz800550xnw7824hrtm	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	60	\N	2026-06-10 21:53:35.348
cmq8m1sic00560xnwea57n6e8	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	58	\N	2026-06-10 21:58:35.412
cmq8m1siq00570xnwellac4jp	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	60	\N	2026-06-10 21:58:35.426
cmq8m1sit00580xnwutdlr0mh	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	59	\N	2026-06-10 21:58:35.429
cmq8m886w00590xnwvi8izwas	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	58	\N	2026-06-10 22:03:35.672
cmq8m8874005a0xnw0q6ignmu	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	60	\N	2026-06-10 22:03:35.68
cmq8m887c005b0xnwuh9m8th8	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	60	\N	2026-06-10 22:03:35.688
cmq8mekdo005c0xnwvnexy7c0	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	46	\N	2026-06-10 22:08:31.404
cmq8mekdv005d0xnw0rgezg83	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	56	\N	2026-06-10 22:08:31.411
cmq8mekeh005e0xnw64sthp96	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	51	\N	2026-06-10 22:08:31.433
cmq8ml37m005f0xnwidyqwdz0	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	56	\N	2026-06-10 22:13:35.746
cmq8ml37x005g0xnwqlrfb7ou	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	56	\N	2026-06-10 22:13:35.757
cmq8ml38m005h0xnwujfrb1d9	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	63	\N	2026-06-10 22:13:35.782
cmq8mrfgs005i0xnw39in5akt	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	46	\N	2026-06-10 22:18:31.564
cmq8mrfgw005j0xnwxc65p05e	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	39	\N	2026-06-10 22:18:31.568
cmq8mrfh4005k0xnwn58zn858	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	46	\N	2026-06-10 22:18:31.576
cmq8mxya9005l0xnw7k52f50s	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	54	\N	2026-06-10 22:23:35.889
cmq8mxyad005m0xnwm3bxugm0	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	57	\N	2026-06-10 22:23:35.893
cmq8mxycc005n0xnwkyao2hms	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	62	\N	2026-06-10 22:23:35.964
cmq8n4alz005o0xnw1oxi66so	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	67	\N	2026-06-10 22:28:31.799
cmq8n4am6005p0xnwfxc8zp9h	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	61	\N	2026-06-10 22:28:31.806
cmq8n4amb005q0xnws3evgjvn	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	58	\N	2026-06-10 22:28:31.811
cmq8nataq005r0xnw7l7uwead	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	63	\N	2026-06-10 22:33:35.954
cmq8natau005s0xnwnllkqxpw	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	64	\N	2026-06-10 22:33:35.958
cmq8nataz005t0xnw8a6es3f1	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	67	\N	2026-06-10 22:33:35.963
cmq8nh5pi005u0xnw58vcf3fb	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	59	\N	2026-06-10 22:38:31.974
cmq8nh5pl005v0xnwd9ep6271	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	58	\N	2026-06-10 22:38:31.977
cmq8nh5qb005w0xnwna1678fc	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	60	\N	2026-06-10 22:38:32.003
cmq8nnod3005x0xnwrjb3hzh7	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	60	\N	2026-06-10 22:43:36.087
cmq8nnod9005y0xnwd270mugr	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	58	\N	2026-06-10 22:43:36.093
cmq8nnof8005z0xnwpp3h1a9e	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	66	\N	2026-06-10 22:43:36.164
cmq8nu0uc00600xnwoew2d9ey	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	43	\N	2026-06-10 22:48:32.196
cmq8nu0uk00610xnw7y9kipsq	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	45	\N	2026-06-10 22:48:32.204
cmq8nu0uq00620xnwhmg817cf	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	51	\N	2026-06-10 22:48:32.21
cmq8o0jkg00630xnwnz04zl0h	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	58	\N	2026-06-10 22:53:36.4
cmq8o0jkl00640xnw0kcp03yl	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	57	\N	2026-06-10 22:53:36.405
cmq8o0jl900650xnwz2493zik	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	58	\N	2026-06-10 22:53:36.429
cmq8o6w0r00660xnwbbhse6xd	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	51	\N	2026-06-10 22:58:32.475
cmq8o6w0z00670xnwg8cb5d12	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	53	\N	2026-06-10 22:58:32.483
cmq8o6w1300680xnwaa5cpj2p	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	50	\N	2026-06-10 22:58:32.487
cmq8odeok00690xnw1x2p263q	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	57	\N	2026-06-10 23:03:36.596
cmq8odepi006a0xnwrjhdy293	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	54	\N	2026-06-10 23:03:36.63
cmq8odepn006b0xnwy66nkqcg	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	53	\N	2026-06-10 23:03:36.635
cmq8ojr2f006c0xnwpdpr6yoh	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	52	\N	2026-06-10 23:08:32.583
cmq8ojr2n006d0xnwgkzceoen	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	49	\N	2026-06-10 23:08:32.591
cmq8ojr2s006e0xnwqktt1lgc	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	52	\N	2026-06-10 23:08:32.596
cmq8oq9tm006f0xnw07lux25l	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	53	\N	2026-06-10 23:13:36.826
cmq8oq9tv006g0xnw2ln5v533	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	59	\N	2026-06-10 23:13:36.835
cmq8oq9tx006h0xnw7s258l7d	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	60	\N	2026-06-10 23:13:36.837
cmq8owm4q006i0xnwvgpolife	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	51	\N	2026-06-10 23:18:32.714
cmq8owm50006j0xnwry0j9vcq	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	55	\N	2026-06-10 23:18:32.725
cmq8owm58006k0xnwk9arye6o	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	54	\N	2026-06-10 23:18:32.732
cmq8p34yq006l0xnwidgd4y49	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	63	\N	2026-06-10 23:23:37.058
cmq8p34z2006m0xnwv98brywd	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	65	\N	2026-06-10 23:23:37.07
cmq8p34z7006n0xnw2oq08204	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	62	\N	2026-06-10 23:23:37.075
cmq8p9ki7006o0xnw16injdon	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	54	\N	2026-06-10 23:28:37.135
cmq8p9ki7006p0xnwrqf2f1rf	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	58	\N	2026-06-10 23:28:37.135
cmq8p9ki8006q0xnwu7n4p0il	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	58	\N	2026-06-10 23:28:37.136
cmq8pg010006r0xnw3gr3yooa	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	52	\N	2026-06-10 23:33:37.188
cmq8pg01y006s0xnwowd1r61h	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	52	\N	2026-06-10 23:33:37.222
cmq8pg024006t0xnwhyog8c7y	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	54	\N	2026-06-10 23:33:37.228
cmq8pmcbb006u0xnwrvvrkgun	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	54	\N	2026-06-10 23:38:33.047
cmq8pmcbn006v0xnw5i0sant5	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	56	\N	2026-06-10 23:38:33.059
cmq8pmcbt006w0xnwd3v4h6ix	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	55	\N	2026-06-10 23:38:33.065
cmq8psv4i006x0xnwzpdof03b	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	56	\N	2026-06-10 23:43:37.362
cmq8psv59006y0xnwpu46kmbs	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	54	\N	2026-06-10 23:43:37.389
cmq8psv5y006z0xnwpd16urqw	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	57	\N	2026-06-10 23:43:37.414
cmq8pz7bl00700xnwxpzhgho0	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	58	\N	2026-06-10 23:48:33.105
cmq8pz7bt00710xnw17ebew7h	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	55	\N	2026-06-10 23:48:33.113
cmq8pz7bx00720xnwyyrhh72p	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	60	\N	2026-06-10 23:48:33.117
cmq8q5q5n00730xnw3ppdadoe	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	57	\N	2026-06-10 23:53:37.451
cmq8q5q7x00740xnwf6rq3ags	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	59	\N	2026-06-10 23:53:37.533
cmq8q5q7y00750xnwqnw5xgrc	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	61	\N	2026-06-10 23:53:37.534
cmq8qc2ja00760xnwcqfstyp0	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	54	\N	2026-06-10 23:58:33.43
cmq8qc2jj00770xnw8urlvbsk	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	56	\N	2026-06-10 23:58:33.439
cmq8qc2jk00780xnwhpgz0q7y	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	55	\N	2026-06-10 23:58:33.44
cmq8qil8q00790xnwumtx11tu	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	55	\N	2026-06-11 00:03:37.61
cmq8qil92007a0xnwt6iz229t	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	56	\N	2026-06-11 00:03:37.622
cmq8qil93007b0xnwfzvbutgy	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	58	\N	2026-06-11 00:03:37.623
cmq8qoxly007c0xnw0wu1ymeu	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	54	\N	2026-06-11 00:08:33.574
cmq8qoxmw007d0xnwlgh1ro2k	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	55	\N	2026-06-11 00:08:33.608
cmq8qoxn2007e0xnwahzftslu	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	57	\N	2026-06-11 00:08:33.614
cmq8qvgd5007f0xnw9sf5bupx	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	72	\N	2026-06-11 00:13:37.817
cmq8qvgd7007g0xnwlj87em1q	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	73	\N	2026-06-11 00:13:37.819
cmq8qvgf2007h0xnw3fxql38a	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	76	\N	2026-06-11 00:13:37.886
cmq8r1sqf007i0xnwtenlcxls	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	56	\N	2026-06-11 00:18:33.783
cmq8r1sqg007j0xnwd8k95m4k	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	53	\N	2026-06-11 00:18:33.784
cmq8r1sr7007k0xnw2qq0n333	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	56	\N	2026-06-11 00:18:33.811
cmq8r8biu007l0xnwslpl9l15	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	70	\N	2026-06-11 00:23:38.07
cmq8r8bj8007m0xnw4nnvf3yw	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	70	\N	2026-06-11 00:23:38.084
cmq8r8bjb007n0xnwbfiz9ib0	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	72	\N	2026-06-11 00:23:38.088
cmq8rensv007o0xnw01t7ld69	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	52	\N	2026-06-11 00:28:33.919
cmq8rensx007p0xnw9lbtnsar	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	55	\N	2026-06-11 00:28:33.921
cmq8rent2007q0xnwd8xu0wp8	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	53	\N	2026-06-11 00:28:33.926
cmq8rl6pe007r0xnwxfsmnfn6	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	72	\N	2026-06-11 00:33:38.354
cmq8rl6pg007s0xnw3fj4uxai	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	68	\N	2026-06-11 00:33:38.356
cmq8rl6q5007t0xnwq9mzmbql	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	78	\N	2026-06-11 00:33:38.381
cmq8rrizh007u0xnwdjh5qo7o	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	45	\N	2026-06-11 00:38:34.205
cmq8rrizm007v0xnwmapqst9o	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	48	\N	2026-06-11 00:38:34.21
cmq8rrizs007w0xnwvp7yozar	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	45	\N	2026-06-11 00:38:34.216
cmq8ry1sr007x0xnwj3k2eb7z	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	56	\N	2026-06-11 00:43:38.523
cmq8ry1t1007y0xnw2e0o7yj5	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	55	\N	2026-06-11 00:43:38.533
cmq8ry1t1007z0xnwr91v0225	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	59	\N	2026-06-11 00:43:38.533
cmq8s4e2y00800xnweh6c5ojg	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	43	\N	2026-06-11 00:48:34.378
cmq8s4e3600810xnw8s51wsjp	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	46	\N	2026-06-11 00:48:34.386
cmq8s4e3h00820xnwze2wqcwp	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	47	\N	2026-06-11 00:48:34.397
cmq8sawuw00830xnw82npmcwe	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	64	\N	2026-06-11 00:53:38.648
cmq8sawvs00840xnwia18721m	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	62	\N	2026-06-11 00:53:38.68
cmq8sawvz00850xnwwh8t7z39	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	67	\N	2026-06-11 00:53:38.687
cmq8sh94e00860xnwko4nftdc	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	53	\N	2026-06-11 00:58:34.478
cmq8sh94g00870xnwxtxcpubg	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	54	\N	2026-06-11 00:58:34.48
cmq8sh96700880xnwzpzy7pos	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	57	\N	2026-06-11 00:58:34.543
cmq8sns1d008a0xnwicf8rgwz	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	83	\N	2026-06-11 01:03:38.929
cmq8sns1p008b0xnw8f324s5h	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	87	\N	2026-06-11 01:03:38.941
cmq8sns1s008c0xnwkbevl7nf	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	74	\N	2026-06-11 01:03:38.944
cmq8su493008d0xnw1t1ge46y	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	59	\N	2026-06-11 01:08:34.695
cmq8su49c008e0xnw4i0gy47h	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	60	\N	2026-06-11 01:08:34.704
cmq8su49f008f0xnwu4g95c2y	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	63	\N	2026-06-11 01:08:34.707
cmq8t0n4d008g0xnwn0uu0ju5	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	49	\N	2026-06-11 01:13:39.085
cmq8t0n4j008h0xnwrmjnyje2	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	45	\N	2026-06-11 01:13:39.091
cmq8t0n4k008i0xnwtoehqx0w	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	48	\N	2026-06-11 01:13:39.092
cmq8t6zbt008j0xnwwm6f1x5l	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	55	\N	2026-06-11 01:18:34.841
cmq8t6zbz008k0xnw9bryqdq2	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	57	\N	2026-06-11 01:18:34.847
cmq8t6zcl008l0xnw0742yq3l	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	60	\N	2026-06-11 01:18:34.869
cmq8tdi75008m0xnwdsgoem34	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	66	\N	2026-06-11 01:23:39.233
cmq8tdi78008n0xnw3daakhvp	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	63	\N	2026-06-11 01:23:39.236
cmq8tdi79008o0xnwjdszd5qu	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	65	\N	2026-06-11 01:23:39.237
cmq8tjuel008p0xnw23952gjl	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	69	\N	2026-06-11 01:28:34.989
cmq8tjuem008q0xnwflv776ud	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	66	\N	2026-06-11 01:28:34.99
cmq8tjueo008r0xnw3ftk92av	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	58	\N	2026-06-11 01:28:34.992
cmq8tqd9y008s0xnwzusvzzy0	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	70	\N	2026-06-11 01:33:39.382
cmq8tqda8008t0xnwuzv5prjx	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	73	\N	2026-06-11 01:33:39.392
cmq8tqda8008u0xnwickragkv	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	70	\N	2026-06-11 01:33:39.393
cmq8twpj3008v0xnwcx5vawme	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	54	\N	2026-06-11 01:38:35.199
cmq8twpj7008w0xnw9mxku17t	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	55	\N	2026-06-11 01:38:35.203
cmq8twpja008x0xnwb7mwm8nd	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	59	\N	2026-06-11 01:38:35.206
cmq8u38dg008y0xnw16pdashn	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	51	\N	2026-06-11 01:43:39.557
cmq8u38dn008z0xnwvu73cvd6	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	50	\N	2026-06-11 01:43:39.563
cmq8u38dr00900xnwn4fsnswo	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	47	\N	2026-06-11 01:43:39.567
cmq8u9kmv00910xnwu3qbb4jp	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	41	\N	2026-06-11 01:48:35.383
cmq8u9kn500920xnwb0v4tb62	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	45	\N	2026-06-11 01:48:35.393
cmq8u9kn900930xnw5cs729pe	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	47	\N	2026-06-11 01:48:35.398
cmq8ug3o300980xnwrsarn12t	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	53	\N	2026-06-11 01:53:39.987
cmq8ug3od00990xnw4lreisuy	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	54	\N	2026-06-11 01:53:39.997
cmq8ug3od009a0xnwn2nej59z	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	50	\N	2026-06-11 01:53:39.997
cmq8umfsi009c0xnwac1qbnrk	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	43	\N	2026-06-11 01:58:35.637
cmq8umft8009d0xnwh1pqa4sw	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	48	\N	2026-06-11 01:58:35.66
cmq8umftm009e0xnwg0sqygu8	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	49	\N	2026-06-11 01:58:35.674
cmq8usyyv009f0xnwyrfvc3bz	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	89	\N	2026-06-11 02:03:40.426
cmq8usyze009g0xnwxl750zty	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	105	\N	2026-06-11 02:03:40.442
cmq8usyzg009h0xnw40gs8q0v	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	107	\N	2026-06-11 02:03:40.444
cmq8v1ywq0000j05u2i6xehpu	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	265	\N	2026-06-11 02:10:40.25
cmq8v1ywt0001j05ungp5pd31	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	313	\N	2026-06-11 02:10:40.253
cmq8v1yx10002j05uamrn9u5t	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	265	\N	2026-06-11 02:10:40.261
cmq8vmarp00000xms5jzf4ckq	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	50	\N	2026-06-11 02:26:28.741
cmq8vmaru00010xms2bfknbhv	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	49	\N	2026-06-11 02:26:28.746
cmq8vmarv00020xms2gvpo3i2	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	50	\N	2026-06-11 02:26:28.747
cmq8vsq4q000j0xmsnfjl3g2o	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	53	\N	2026-06-11 02:31:28.586
cmq8vsq4w000k0xmsz4lufrtq	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	50	\N	2026-06-11 02:31:28.593
cmq8vsq5p000l0xmsoth0x1vq	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	62	\N	2026-06-11 02:31:28.621
cmq8vz5lx001c0xmsh8x4wj9f	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	47	\N	2026-06-11 02:36:28.581
cmq8vz5mh001d0xmsqn9uixvc	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	47	\N	2026-06-11 02:36:28.601
cmq8vz5mq001e0xmsnh5j39x4	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	53	\N	2026-06-11 02:36:28.61
cmq8w5l77001s0xmst3qevthu	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	63	\N	2026-06-11 02:41:28.723
cmq8w5l8d001t0xmsen6jww6s	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	77	\N	2026-06-11 02:41:28.765
cmq8w5l8e001u0xmscw0lxuti	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	55	\N	2026-06-11 02:41:28.766
cmq8wby0p001y0xmsi3eclqen	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	74	\N	2026-06-11 02:46:25.273
cmq8wby0v001z0xms9146w9nd	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	92	\N	2026-06-11 02:46:25.279
cmq8wby1400200xmsk6ahb7t8	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	92	\N	2026-06-11 02:46:25.288
cmq8wigoi00240xms6bjsc77l	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	87	\N	2026-06-11 02:51:29.394
cmq8wigoy00250xmshab9jtey	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	83	\N	2026-06-11 02:51:29.41
cmq8wigp000260xmsb0f8r7ca	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	86	\N	2026-06-11 02:51:29.412
cmq8wosh100270xmss8ka2967	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	74	\N	2026-06-11 02:56:24.613
cmq8woshh00280xmsox54rabg	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	80	\N	2026-06-11 02:56:24.629
cmq8woshj00290xms3i0ahedk	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	83	\N	2026-06-11 02:56:24.631
cmq8wvb99002d0xms36cxf1tr	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	86	\N	2026-06-11 03:01:28.893
cmq8wvb9f002e0xmsk4eh85lp	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	88	\N	2026-06-11 03:01:28.899
cmq8wvbbt002f0xmsklxh12qs	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	91	\N	2026-06-11 03:01:28.985
cmq8x1nc9002h0xmszpu1v931	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	71	\N	2026-06-11 03:06:24.489
cmq8x1ncl002i0xms2d2oo7lw	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	68	\N	2026-06-11 03:06:24.501
cmq8x1nct002j0xmskly5l4dn	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	66	\N	2026-06-11 03:06:24.509
cmq8x865j002k0xmss5m9kp8u	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	77	\N	2026-06-11 03:11:28.807
cmq8x865n002l0xms45thpc7s	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	79	\N	2026-06-11 03:11:28.811
cmq8x865p002m0xms19sq3b79	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	82	\N	2026-06-11 03:11:28.813
cmq8xeicw002n0xms0zeiohx8	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	67	\N	2026-06-11 03:16:24.56
cmq8xeid8002o0xmsxu2fx9fg	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	74	\N	2026-06-11 03:16:24.572
cmq8xeid9002p0xms4c2rm97w	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	73	\N	2026-06-11 03:16:24.573
cmq8xl13q002q0xmstu3mlie4	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	72	\N	2026-06-11 03:21:28.79
cmq8xl14n002r0xmsh1h6dy1u	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	77	\N	2026-06-11 03:21:28.823
cmq8xl14v002s0xmsly45pktc	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	74	\N	2026-06-11 03:21:28.831
cmq8xrddx002t0xmswwhhfatc	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	80	\N	2026-06-11 03:26:24.645
cmq8xrde7002u0xmspr3nm8px	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	76	\N	2026-06-11 03:26:24.655
cmq8xrdea002v0xmscl58csci	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	80	\N	2026-06-11 03:26:24.658
cmq8xxw6y002w0xmsy8qlx6mk	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	74	\N	2026-06-11 03:31:28.954
cmq8xxw76002x0xmsycntao2b	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	77	\N	2026-06-11 03:31:28.962
cmq8xxw7b002y0xmsgza55i3a	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	74	\N	2026-06-11 03:31:28.967
cmq8y48hh002z0xmsxfm9yfkz	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	75	\N	2026-06-11 03:36:24.822
cmq8y48hu00300xmsv1ke9n5d	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	74	\N	2026-06-11 03:36:24.834
cmq8y48i100310xmsyiznpoka	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	78	\N	2026-06-11 03:36:24.841
cmq8yars900380xmscnmhftwj	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	90	\N	2026-06-11 03:41:29.771
cmq8yarsp00390xmsxi6a44zt	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	92	\N	2026-06-11 03:41:29.785
cmq8yart0003a0xmsjryzeerj	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	79	\N	2026-06-11 03:41:29.796
cmq8yh460003h0xms3qv175na	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	83	\N	2026-06-11 03:46:25.752
cmq8yh464003i0xmse5jl9hmh	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	73	\N	2026-06-11 03:46:25.756
cmq8yh467003j0xms10xn8rno	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	59	\N	2026-06-11 03:46:25.759
cmq8ynmuc003n0xmsmphj026c	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	50	\N	2026-06-11 03:51:29.892
cmq8ynmun003o0xmsw2a8iu8d	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	78	\N	2026-06-11 03:51:29.903
cmq8ynmv8003p0xmswmqxzu62	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	99	\N	2026-06-11 03:51:29.924
cmq8ytyr2003q0xmsc7z7yol5	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	109	\N	2026-06-11 03:56:25.262
cmq8ytyrg003r0xms752jrx0t	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	93	\N	2026-06-11 03:56:25.276
cmq8ytysl003s0xmspayae35u	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	119	\N	2026-06-11 03:56:25.317
cmq8z0e8u003t0xmsnqwxjcr0	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	63	\N	2026-06-11 04:01:25.278
cmq8z0e91003u0xmsknu9o8dj	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	60	\N	2026-06-11 04:01:25.285
cmq8z0e92003v0xmsyiges1b5	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	63	\N	2026-06-11 04:01:25.286
cmq8z6wyd003z0xmsq8nygajy	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	66	\N	2026-06-11 04:06:29.461
cmq8z6wym00400xmsk3nsg9xo	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	70	\N	2026-06-11 04:06:29.47
cmq8z6wyw00410xmsz9487mdd	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	70	\N	2026-06-11 04:06:29.48
cmq8zdcn3004i0xmsbb3ewj66	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	100	\N	2026-06-11 04:11:29.727
cmq8zdcnx004j0xmsxu78r7kp	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	101	\N	2026-06-11 04:11:29.757
cmq8zdcom004k0xmst0uzbd8s	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	114	\N	2026-06-11 04:11:29.782
cmq8zjsbu004l0xmsamjeinmh	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	112	\N	2026-06-11 04:16:29.994
cmq8zjsby004m0xms28atbgz9	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	103	\N	2026-06-11 04:16:29.998
cmq8zjscf004n0xms7v42i9fi	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	115	\N	2026-06-11 04:16:30.015
cmq8zq7qp004p0xmsjwocurbx	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	83	\N	2026-06-11 04:21:29.905
cmq8zq7r0004q0xmsqwak09fh	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	59	\N	2026-06-11 04:21:29.916
cmq8zq7sf004r0xmsjd2mp9ni	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	93	\N	2026-06-11 04:21:29.967
cmq8zwn0600520xms3zwynaad	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	65	\N	2026-06-11 04:26:29.622
cmq8zwn0d00530xms9x37m3en	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	70	\N	2026-06-11 04:26:29.629
cmq8zwn0p00540xmsa7kvg9he	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	67	\N	2026-06-11 04:26:29.641
cmq9032gc00570xmsyy0u3yim	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	68	\N	2026-06-11 04:31:29.58
cmq9032gr00580xmsrfswcapf	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	65	\N	2026-06-11 04:31:29.595
cmq9032gs00590xmsgups6x0q	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	67	\N	2026-06-11 04:31:29.596
cmq909i30005c0xmsqkx4l6t6	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	67	\N	2026-06-11 04:36:29.772
cmq909i35005d0xmsa67bzicj	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	74	\N	2026-06-11 04:36:29.777
cmq909i3f005e0xms9l7458yb	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	76	\N	2026-06-11 04:36:29.787
cmq90fxio005h0xms1odzv21e	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	75	\N	2026-06-11 04:41:29.712
cmq90fxiz005i0xmsmuae9n8y	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	80	\N	2026-06-11 04:41:29.723
cmq90fxj4005j0xmstkpjuc78	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	79	\N	2026-06-11 04:41:29.728
cmq90md4r005p0xmsks5cfuk2	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	72	\N	2026-06-11 04:46:29.883
cmq90md4w005q0xmsflfyn1st	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	70	\N	2026-06-11 04:46:29.888
cmq90md5r005r0xmssuz9uu6w	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	76	\N	2026-06-11 04:46:29.919
cmq90ssne005z0xmsnwip886z	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	89	\N	2026-06-11 04:51:29.93
cmq90ssni00600xms4pr435y5	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	88	\N	2026-06-11 04:51:29.934
cmq90ssnv00610xmsmk4styq4	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	96	\N	2026-06-11 04:51:29.947
cmq916gso000eczmsonxfsoq6	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	57	\N	2026-06-11 05:02:07.752
cmq916gtr000fczmsdnf85v0m	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	67	\N	2026-06-11 05:02:07.791
cmq916gu7000gczmsyxkw3ifz	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	65	\N	2026-06-11 05:02:07.807
cmq91cwm4000wczmsntyh09g0	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	88	\N	2026-06-11 05:07:08.189
cmq91cwo1000xczms28krhmli	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	105	\N	2026-06-11 05:07:08.257
cmq91cwp2000yczmsx0x9h7lq	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	118	\N	2026-06-11 05:07:08.294
cmq91jbx0001bczmsnp4qy089	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	49	\N	2026-06-11 05:12:07.956
cmq91jbxe001cczmscrk0ojrz	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	51	\N	2026-06-11 05:12:07.97
cmq91jby2001dczms2h3lp17a	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	54	\N	2026-06-11 05:12:07.994
cmq91pmsv000ep2mspr56jbpb	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	157	\N	2026-06-11 05:17:01.999
cmq91pmv7000fp2msswe6g68t	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	138	\N	2026-06-11 05:17:02.083
cmq91pmvg000gp2msu67mpg55	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	166	\N	2026-06-11 05:17:02.092
cmq91w1y2000tp2msmitdasiv	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	108	\N	2026-06-11 05:22:01.562
cmq91w1yn000up2ms8nm0m96p	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	100	\N	2026-06-11 05:22:01.586
cmq91w211000vp2msqfuivjrr	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	111	\N	2026-06-11 05:22:01.669
cmq922ide0019p2ms6r7hjqrh	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	237	\N	2026-06-11 05:27:02.787
cmq922ie2001ap2msg3u441xk	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	248	\N	2026-06-11 05:27:02.81
cmq922ifi001bp2msvn4xe7qx	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	251	\N	2026-06-11 05:27:02.862
cmq928xst001op2mswytjrxia	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	147	\N	2026-06-11 05:32:02.731
cmq928xtr001pp2msllzg0qzj	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	100	\N	2026-06-11 05:32:02.751
cmq928xv3001qp2mspqhkoa0i	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	191	\N	2026-06-11 05:32:02.799
cmq92iczh000ce8ms68oi47ot	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	73	\N	2026-06-11 05:39:22.301
cmq92iczo000de8ms6r23sge8	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	66	\N	2026-06-11 05:39:22.308
cmq92iczv000ee8ms1fq0wx9l	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	67	\N	2026-06-11 05:39:22.315
cmq92os8t000se8mswe5qi95n	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	51	\N	2026-06-11 05:44:22.013
cmq92osb2000te8msu5shn8gz	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	49	\N	2026-06-11 05:44:22.094
cmq92osb3000ue8mswe7tb9vc	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	53	\N	2026-06-11 05:44:22.095
cmq92v7tl0017e8ms68l672cx	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	43	\N	2026-06-11 05:49:22.137
cmq92v7uk0018e8mspr59e33d	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	46	\N	2026-06-11 05:49:22.172
cmq92v7um0019e8msznn35t7r	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	45	\N	2026-06-11 05:49:22.174
cmq931n8r001ne8mstgmz2oeu	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	48	\N	2026-06-11 05:54:22.059
cmq931n8x001oe8ms22178sht	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	52	\N	2026-06-11 05:54:22.065
cmq931n9m001pe8msegq8sdnh	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	57	\N	2026-06-11 05:54:22.09
cmq9382ru0022e8msouozkt5s	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	51	\N	2026-06-11 05:59:22.122
cmq9382s30023e8msg6hzyxmh	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	53	\N	2026-06-11 05:59:22.131
cmq9382sb0024e8mswjxuhgc4	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	54	\N	2026-06-11 05:59:22.139
cmq93ei9f002ie8ms0h2kjm0o	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	56	\N	2026-06-11 06:04:22.132
cmq93ei9r002je8mssj5faq28	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	61	\N	2026-06-11 06:04:22.143
cmq93ei9w002ke8ms76l6neda	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	56	\N	2026-06-11 06:04:22.148
cmq93kxrg0031e8ms5iwp79hr	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	47	\N	2026-06-11 06:09:22.156
cmq93kxrp0032e8msjctq4lm1	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	53	\N	2026-06-11 06:09:22.165
cmq93kxsc0033e8msssfbs00g	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	59	\N	2026-06-11 06:09:22.188
cmq93rd51003he8msbk6m0xqj	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	55	\N	2026-06-11 06:14:22.021
cmq93rd7c003ie8mshtqn3css	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	63	\N	2026-06-11 06:14:22.104
cmq93rd7d003je8msxdqnrm2g	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	58	\N	2026-06-11 06:14:22.105
cmq93xsrl003we8msne3nvtph	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	53	\N	2026-06-11 06:19:22.209
cmq93xsrn003xe8mssxp9gsix	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	55	\N	2026-06-11 06:19:22.211
cmq93xstp003ye8msfr6sxwmz	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	54	\N	2026-06-11 06:19:22.285
cmq94489w004ce8ms1y9ecpkn	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	51	\N	2026-06-11 06:24:22.244
cmq94489x004de8ms6iklqnx4	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	55	\N	2026-06-11 06:24:22.245
cmq9448an004ee8mstc8cmnsi	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	58	\N	2026-06-11 06:24:22.271
cmq94anst004re8msn27l2z7m	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	55	\N	2026-06-11 06:29:22.301
cmq94ansv004se8ms063xum0s	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	52	\N	2026-06-11 06:29:22.303
cmq94anuv004te8ms21pfazcz	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	56	\N	2026-06-11 06:29:22.375
cmq94h3dj0057e8msc5lsyop9	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	59	\N	2026-06-11 06:34:22.423
cmq94h3dl0058e8ms85hbb9bd	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	54	\N	2026-06-11 06:34:22.425
cmq94h3do0059e8ms4nkdf77e	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	58	\N	2026-06-11 06:34:22.428
cmq94niyy005me8msccwhuidn	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	53	\N	2026-06-11 06:39:22.57
cmq94nizm005ne8ms67lty1p0	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	53	\N	2026-06-11 06:39:22.594
cmq94nizx005oe8ms6qbbfo1i	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	54	\N	2026-06-11 06:39:22.605
cmq94tyin0062e8ms8yo4865f	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	57	\N	2026-06-11 06:44:22.656
cmq94tyiw0063e8msl86nozsd	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	58	\N	2026-06-11 06:44:22.664
cmq94tyj10064e8msyohes1f4	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	59	\N	2026-06-11 06:44:22.669
cmq950e1l006ie8msms0lc2sh	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	61	\N	2026-06-11 06:49:22.713
cmq950e1u006je8msv500ffrm	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	63	\N	2026-06-11 06:49:22.722
cmq950e1y006ke8ms9ew8bu3z	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	60	\N	2026-06-11 06:49:22.726
cmq956u50007be8msd62x612f	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	98	\N	2026-06-11 06:54:23.508
cmq956u5d007ce8mseajvz813	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	108	\N	2026-06-11 06:54:23.521
cmq956u67007de8msmtfh5z0h	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	119	\N	2026-06-11 06:54:23.551
cmq95mqcc0009wc5ukzivjpy1	cmq6ke2xl0000s25u4a8i94ta	\N	100	t	t	t	135	\N	2026-06-11 07:06:45.084
cmq95mqch000awc5umup2ntmw	\N	cmq6w5d940000525uus1ckhga	100	t	t	t	274	\N	2026-06-11 07:06:45.089
cmq95mqcl000bwc5ujygh83xi	\N	cmq6wcl430001525urn13fvcx	100	t	t	t	288	\N	2026-06-11 07:06:45.093
\.


--
-- TOC entry 3793 (class 0 OID 16545)
-- Dependencies: 215
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
74a94662-78c2-45a4-a34d-76d70a54c301	e12015d347bb2020fff4e600254760fd83eb3c7f36f6573d4fd8bd6dc1e3a38f	2026-06-09 11:34:15.132504+00	20260608102910_init	\N	\N	2026-06-09 11:34:15.084368+00	1
5c9e5f07-729d-459e-b800-d5c21d1e46a4	2c508a75092c5af81d7481934ab382551608c758155db577ad5150b6c5601753	2026-06-10 14:28:55.907409+00	20260610142855_add_agent_usage_snapshot	\N	\N	2026-06-10 14:28:55.864468+00	1
30289f34-40cb-45ed-9f60-0748218b33fa	79b9016d2bef84d5d71718cad0fde794de04d209e721d0bda9c52602f307d370	2026-06-09 11:34:15.158681+00	20260608104055_add_servers	\N	\N	2026-06-09 11:34:15.134332+00	1
2d6d3951-c922-4cea-9b05-90769a4d98d7	914443ca69b2fd1adc34d266a8eecf111f0846665e8db5e7ab7471d32c17c225	2026-06-10 11:54:08.129037+00	20260610115408_add_worker_health	\N	\N	2026-06-10 11:54:08.077342+00	1
5fb3b7d5-a849-448f-bfb1-9649c7f539b6	1efcd86d090d3a4212dec2a8b8b202e5089da98f97a3d994b18a1da0eaf76f74	2026-06-09 11:34:15.165715+00	20260608140717_add_claude_usage_fields	\N	\N	2026-06-09 11:34:15.160235+00	1
30af06ca-a71e-4223-b633-277d4647a53c	9d18b52ed5abbcb2b104514449a456fbd4d7d7e91bc29927628498810eb49757	2026-06-09 11:34:15.176248+00	20260608143826_add_server_to_task_and_reset_timestamps	\N	\N	2026-06-09 11:34:15.167209+00	1
62ffc8c2-f674-43e8-827c-9479580d0a1e	f3e493bbfb5f717572b447b02397d4b9256b1d0ac6a0a8714d24bdeaa568a80d	2026-06-09 11:34:15.182933+00	20260608144657_add_queued_task_status	\N	\N	2026-06-09 11:34:15.17794+00	1
d39bfed4-bbdb-4c29-8d75-8365a97a9098	93d8a84aae88899db22ed1b5543907a78977ca1a94de46e43d70086d0f67729d	2026-06-10 11:59:55.087709+00	20260610115955_add_auto_recovery	\N	\N	2026-06-10 11:59:55.052492+00	1
535e00a9-8c12-4f96-bc7a-3b5a6898142a	1d1155ecd7e63a82a6fc86ab62813be9dc8ab44a47d26a83ac01f42d10d31ced	2026-06-09 11:34:15.191755+00	20260608153832_add_claude_permission_mode	\N	\N	2026-06-09 11:34:15.18484+00	1
e506f56f-bb18-446a-8931-b24d93adfd73	7856bf9ef8795816ff18f5ad153b5c1eaa8d19b6740206bd443e7a2c6dfbf949	2026-06-09 11:34:15.201054+00	20260609000000_add_archived_task_status	\N	\N	2026-06-09 11:34:15.193244+00	1
5af8efa5-650f-48d8-a625-ac92ba4ce48a	a2741da54a133d6dcceb5a0d7946c4ff1492550ae8f3d70ede247ba0bc2fcea9	2026-06-09 16:18:22.615619+00	20260609100000_add_agents	\N	\N	2026-06-09 16:18:22.550227+00	1
061b6828-195f-429d-9776-46927eae2bc7	211e605946b474788c0d3cf88be23c3a34a2a85bb1fe604d992bb16328637e8a	2026-06-10 12:05:48.740769+00	20260610120548_add_zombie_detection	\N	\N	2026-06-10 12:05:48.719972+00	1
1fd825dd-fd43-4647-afc7-03c4f9eac75b	c6672798cfe767087edc2221be71dcf243ad52bb9e9ae093043eec7bc9f60b8f	2026-06-09 16:18:22.640839+00	20260609110000_add_task_indexes	\N	\N	2026-06-09 16:18:22.617506+00	1
99fecf6a-81e4-41b5-a4da-cfc0eafd5c07	db6e26e00b32c91e3de3b6a7aacba029b2a4c5efb24ba7f65e2d8e45e4902c29	2026-06-09 19:20:58.623532+00	20260609120000_add_server_tmux_session	\N	\N	2026-06-09 19:20:58.610128+00	1
afc2bad3-768a-4dd2-9eb4-0a23f98d59e6	e7dd8c7be27e9168a642e0a2e82a17bde8d0ebd50a16240fe433a108b5ef4194	2026-06-10 15:55:40.013334+00	20260610150000_add_server_capacity	\N	\N	2026-06-10 15:55:39.980914+00	1
7b5d44a3-1f4b-4706-bec7-208d6982a5c5	af8172e721f7ca1ffc96e7b2d98abff01d6cf0df3998fe2e165173c660a658f9	2026-06-10 07:29:07.351094+00	20260610072907_add_completion_nonce_and_output_offset	\N	\N	2026-06-10 07:29:07.343159+00	1
9332053f-503d-4872-9d93-38255633b602	46e7c80545386161006290f2ffa42b4c6d219e921d176df862875ac1fd12918c	2026-06-10 12:10:28.635861+00	20260610121028_add_scheduled_resume	\N	\N	2026-06-10 12:10:28.606019+00	1
33049065-4b2e-41df-aa8f-9dbd974aaeaf	2e40dcfc07bccd8ea6dbb7ade81c58500acd8cc72407ee693d1355c1417ffb51	2026-06-10 09:03:05.571198+00	20260610090305_add_task_tmux_session	\N	\N	2026-06-10 09:03:05.564064+00	1
a8e1746c-c80e-4460-ba91-f8a504a324b7	fb8852bcca8ac803d4b32729ee6a88dbb870f04ec1084a53f363ead7e88a356f	2026-06-10 11:45:34.447494+00	20260610114534_add_timeout_fields	\N	\N	2026-06-10 11:45:34.436346+00	1
e3967dd7-7f19-45a0-9d4f-1ea9efe94305	be09405fa916540e82295ba59af978c7cf9551a13cb6f42ef2fac7d238f3df85	2026-06-10 12:14:30.23263+00	20260610121430_add_task_retry	\N	\N	2026-06-10 12:14:30.217127+00	1
58f32fb2-e5ae-4879-b26a-dc1bd6aa254c	e8602ca483d7723600c8b1f9b9a9e1d8c89cec3491ffd39dba6d2246bd20a721	2026-06-10 19:29:12.946275+00	20260610192912_add_improvement_cycles	\N	\N	2026-06-10 19:29:12.917227+00	1
67a1515b-cca9-4ab7-96f5-7f94f3688259	5d935a27ee42dd23d74ae8b08d0968382f359933c720400b2fc0a76f3eb894b4	2026-06-10 12:21:24.953544+00	20260610122124_add_audit_event	\N	\N	2026-06-10 12:21:24.918038+00	1
168f144f-d7b3-4882-89ed-49c2cc2e778a	0fee416a534c2b4563315d5238df14af4b6511245f280250337e24d57371458d	2026-06-10 15:58:51.553734+00	20260610160000_add_task_template	\N	\N	2026-06-10 15:58:51.519944+00	1
4f5df1f2-fbce-42df-aec9-567c8c4db012	a096ac12faa3f8cd8ec51aca562370a481a89782dd5e932a7e20dbceda260c35	2026-06-10 12:27:29.586108+00	20260610122729_add_project_progress	\N	\N	2026-06-10 12:27:29.576585+00	1
98883c18-5e83-4ece-8d2c-d19b721c0f0c	46f48ea0f8f617f8f839edda4e7c734b9dbb01f8dcf13e466c1800ddc7c1d3a5	2026-06-10 12:35:29.806605+00	20260610123509_add_execution_log_enrichment	\N	\N	2026-06-10 12:35:29.766684+00	1
3828aa50-5164-4c4a-8782-b407739fe066	553ca70d9cf1d0e21d7e47f748c607fbc603533ef812911f2b6eea311ff560c9	2026-06-10 19:12:34.385231+00	20260610191234_add_auto_review	\N	\N	2026-06-10 19:12:34.367138+00	1
15fe333e-5646-4508-8542-4447be7ecac5	4a9e10b4469112d47f81e301cd2242c066269e3d3f57157efdd8758e78207535	2026-06-10 16:13:51.920118+00	20260610170000_extend_daily_report	\N	\N	2026-06-10 16:13:51.852708+00	1
49cadf09-07ef-454b-aa41-0f98dbd612bf	01110c8ccc72f4926b45814660ba2d8e3955c4e3604f80eef6658def01ed7636	2026-06-10 18:12:51.949049+00	20260610181251_add_weekly_analytics	\N	\N	2026-06-10 18:12:51.915046+00	1
1fa384d4-63e6-4032-b4bc-7b68f7c0f27c	f96ad7379fffa4a8e41bf25b8b21fe7f78f402e7b5b9a9709041b2261c3914f0	2026-06-10 19:17:14.92237+00	20260610191714_add_project_scanner	\N	\N	2026-06-10 19:17:14.892795+00	1
a315dcb7-cfc5-44f1-9337-60f8b7616426	9a05390a37331d42ada4355a07a4b051574c0810ed4a489796ff9477ea9f3ae4	2026-06-10 18:18:58.485277+00	20260610181858_add_task_dependencies	\N	\N	2026-06-10 18:18:58.445243+00	1
09381e0d-26a5-4f40-b453-6bd2f6485fa9	301a08b800abe43fcf4962b7fd0d4a5f906ebf1680624cae853bc0d5c5900396	2026-06-10 19:23:09.207898+00	20260610192309_add_debt_items	\N	\N	2026-06-10 19:23:09.173838+00	1
6c9daaad-cf3f-4f8e-918a-8f49760e9196	64f699b34c05321ae666c56ac7bf7a0793ba53726845b982aae1f8952c5cc061	2026-06-10 21:01:29.072672+00	20260610210129_add_task_suggestion	\N	\N	2026-06-10 21:01:29.043349+00	1
5826e7d9-56ec-4a9e-b781-377448e41b31	8364c9e25a386c15a7730bca787fc1eadb1c2f2ce41c7020532ba49c27e08ccc	2026-06-11 05:04:36.906041+00	20260611050436_add_task_scheduled_for	\N	\N	2026-06-11 05:04:36.886157+00	1
d6a199c7-893c-4e84-8cf1-4d2b1b32af82	ffd5cc716c8f8ca983c238072abd99381fdce40dc521ae8f05eea1499474937f	2026-06-11 04:29:35.555836+00	20260611042935_add_weekly_monthly_reports	\N	\N	2026-06-11 04:29:35.512649+00	1
c4ceb6d3-118b-40e4-abda-2df3bdb6eda6	d7a6841f9acf8c2706c2db587d94c15f178b7f1f99ee1d4aac9a29fec6213cc9	2026-06-11 05:17:09.656919+00	20260611051709_add_execution_log_cost_fields	\N	\N	2026-06-11 05:17:09.649082+00	1
\.


--
-- TOC entry 3595 (class 2606 OID 35679)
-- Name: AgentUsageSnapshot AgentUsageSnapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AgentUsageSnapshot"
    ADD CONSTRAINT "AgentUsageSnapshot_pkey" PRIMARY KEY (id);


--
-- TOC entry 3573 (class 2606 OID 24948)
-- Name: Agent Agent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Agent"
    ADD CONSTRAINT "Agent_pkey" PRIMARY KEY (id);


--
-- TOC entry 3592 (class 2606 OID 30258)
-- Name: AuditEvent AuditEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AuditEvent"
    ADD CONSTRAINT "AuditEvent_pkey" PRIMARY KEY (id);


--
-- TOC entry 3567 (class 2606 OID 16646)
-- Name: DailyReport DailyReport_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DailyReport"
    ADD CONSTRAINT "DailyReport_pkey" PRIMARY KEY (id);


--
-- TOC entry 3614 (class 2606 OID 41402)
-- Name: DebtItem DebtItem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DebtItem"
    ADD CONSTRAINT "DebtItem_pkey" PRIMARY KEY (id);


--
-- TOC entry 3564 (class 2606 OID 16633)
-- Name: ExecutionLog ExecutionLog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExecutionLog"
    ADD CONSTRAINT "ExecutionLog_pkey" PRIMARY KEY (id);


--
-- TOC entry 3619 (class 2606 OID 42382)
-- Name: ImprovementCycle ImprovementCycle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ImprovementCycle"
    ADD CONSTRAINT "ImprovementCycle_pkey" PRIMARY KEY (id);


--
-- TOC entry 3631 (class 2606 OID 44610)
-- Name: MonthlyReport MonthlyReport_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MonthlyReport"
    ADD CONSTRAINT "MonthlyReport_pkey" PRIMARY KEY (id);


--
-- TOC entry 3610 (class 2606 OID 40522)
-- Name: ProjectScan ProjectScan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProjectScan"
    ADD CONSTRAINT "ProjectScan_pkey" PRIMARY KEY (id);


--
-- TOC entry 3552 (class 2606 OID 16612)
-- Name: Project Project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Project"
    ADD CONSTRAINT "Project_pkey" PRIMARY KEY (id);


--
-- TOC entry 3581 (class 2606 OID 28153)
-- Name: RecoveryLog RecoveryLog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RecoveryLog"
    ADD CONSTRAINT "RecoveryLog_pkey" PRIMARY KEY (id);


--
-- TOC entry 3586 (class 2606 OID 29175)
-- Name: ScheduledResume ScheduledResume_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ScheduledResume"
    ADD CONSTRAINT "ScheduledResume_pkey" PRIMARY KEY (id);


--
-- TOC entry 3571 (class 2606 OID 16689)
-- Name: ServerCommandLog ServerCommandLog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServerCommandLog"
    ADD CONSTRAINT "ServerCommandLog_pkey" PRIMARY KEY (id);


--
-- TOC entry 3569 (class 2606 OID 16680)
-- Name: Server Server_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Server"
    ADD CONSTRAINT "Server_pkey" PRIMARY KEY (id);


--
-- TOC entry 3584 (class 2606 OID 28662)
-- Name: SystemConfig SystemConfig_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SystemConfig"
    ADD CONSTRAINT "SystemConfig_pkey" PRIMARY KEY (key);


--
-- TOC entry 3606 (class 2606 OID 38967)
-- Name: TaskDependency TaskDependency_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaskDependency"
    ADD CONSTRAINT "TaskDependency_pkey" PRIMARY KEY (id);


--
-- TOC entry 3623 (class 2606 OID 43449)
-- Name: TaskSuggestion TaskSuggestion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaskSuggestion"
    ADD CONSTRAINT "TaskSuggestion_pkey" PRIMARY KEY (id);


--
-- TOC entry 3599 (class 2606 OID 37243)
-- Name: TaskTemplate TaskTemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaskTemplate"
    ADD CONSTRAINT "TaskTemplate_pkey" PRIMARY KEY (id);


--
-- TOC entry 3554 (class 2606 OID 16624)
-- Name: Task Task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_pkey" PRIMARY KEY (id);


--
-- TOC entry 3601 (class 2606 OID 38262)
-- Name: WeeklyAnalytics WeeklyAnalytics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WeeklyAnalytics"
    ADD CONSTRAINT "WeeklyAnalytics_pkey" PRIMARY KEY (id);


--
-- TOC entry 3627 (class 2606 OID 44589)
-- Name: WeeklyReport WeeklyReport_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WeeklyReport"
    ADD CONSTRAINT "WeeklyReport_pkey" PRIMARY KEY (id);


--
-- TOC entry 3577 (class 2606 OID 27694)
-- Name: WorkerHealth WorkerHealth_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WorkerHealth"
    ADD CONSTRAINT "WorkerHealth_pkey" PRIMARY KEY (id);


--
-- TOC entry 3550 (class 2606 OID 16553)
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3593 (class 1259 OID 35680)
-- Name: AgentUsageSnapshot_agentId_capturedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AgentUsageSnapshot_agentId_capturedAt_idx" ON public."AgentUsageSnapshot" USING btree ("agentId", "capturedAt");


--
-- TOC entry 3574 (class 1259 OID 24949)
-- Name: Agent_serverId_slug_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Agent_serverId_slug_key" ON public."Agent" USING btree ("serverId", slug);


--
-- TOC entry 3589 (class 1259 OID 30259)
-- Name: AuditEvent_entityType_entityId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditEvent_entityType_entityId_createdAt_idx" ON public."AuditEvent" USING btree ("entityType", "entityId", "createdAt");


--
-- TOC entry 3590 (class 1259 OID 30260)
-- Name: AuditEvent_eventType_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AuditEvent_eventType_createdAt_idx" ON public."AuditEvent" USING btree ("eventType", "createdAt");


--
-- TOC entry 3615 (class 1259 OID 41403)
-- Name: DebtItem_projectId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "DebtItem_projectId_status_idx" ON public."DebtItem" USING btree ("projectId", status);


--
-- TOC entry 3616 (class 1259 OID 41404)
-- Name: DebtItem_severity_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "DebtItem_severity_idx" ON public."DebtItem" USING btree (severity);


--
-- TOC entry 3617 (class 1259 OID 41405)
-- Name: DebtItem_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "DebtItem_status_idx" ON public."DebtItem" USING btree (status);


--
-- TOC entry 3561 (class 1259 OID 31948)
-- Name: ExecutionLog_archivedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ExecutionLog_archivedAt_idx" ON public."ExecutionLog" USING btree ("archivedAt");


--
-- TOC entry 3562 (class 1259 OID 31949)
-- Name: ExecutionLog_finishedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ExecutionLog_finishedAt_idx" ON public."ExecutionLog" USING btree ("finishedAt");


--
-- TOC entry 3565 (class 1259 OID 31947)
-- Name: ExecutionLog_taskId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ExecutionLog_taskId_idx" ON public."ExecutionLog" USING btree ("taskId");


--
-- TOC entry 3620 (class 1259 OID 42383)
-- Name: ImprovementCycle_projectId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ImprovementCycle_projectId_createdAt_idx" ON public."ImprovementCycle" USING btree ("projectId", "createdAt");


--
-- TOC entry 3621 (class 1259 OID 42384)
-- Name: ImprovementCycle_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ImprovementCycle_status_idx" ON public."ImprovementCycle" USING btree (status);


--
-- TOC entry 3629 (class 1259 OID 44612)
-- Name: MonthlyReport_monthStart_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "MonthlyReport_monthStart_idx" ON public."MonthlyReport" USING btree ("monthStart");


--
-- TOC entry 3611 (class 1259 OID 40523)
-- Name: ProjectScan_projectId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProjectScan_projectId_createdAt_idx" ON public."ProjectScan" USING btree ("projectId", "createdAt");


--
-- TOC entry 3612 (class 1259 OID 40524)
-- Name: ProjectScan_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProjectScan_status_idx" ON public."ProjectScan" USING btree (status);


--
-- TOC entry 3579 (class 1259 OID 28155)
-- Name: RecoveryLog_agentId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "RecoveryLog_agentId_createdAt_idx" ON public."RecoveryLog" USING btree ("agentId", "createdAt");


--
-- TOC entry 3582 (class 1259 OID 28154)
-- Name: RecoveryLog_serverId_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "RecoveryLog_serverId_createdAt_idx" ON public."RecoveryLog" USING btree ("serverId", "createdAt");


--
-- TOC entry 3587 (class 1259 OID 29177)
-- Name: ScheduledResume_resourceType_resourceId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "ScheduledResume_resourceType_resourceId_key" ON public."ScheduledResume" USING btree ("resourceType", "resourceId");


--
-- TOC entry 3588 (class 1259 OID 29176)
-- Name: ScheduledResume_resumeAt_triggered_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ScheduledResume_resumeAt_triggered_idx" ON public."ScheduledResume" USING btree ("resumeAt", triggered);


--
-- TOC entry 3604 (class 1259 OID 38969)
-- Name: TaskDependency_dependsOnId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TaskDependency_dependsOnId_idx" ON public."TaskDependency" USING btree ("dependsOnId");


--
-- TOC entry 3607 (class 1259 OID 38970)
-- Name: TaskDependency_taskId_dependsOnId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "TaskDependency_taskId_dependsOnId_key" ON public."TaskDependency" USING btree ("taskId", "dependsOnId");


--
-- TOC entry 3608 (class 1259 OID 38968)
-- Name: TaskDependency_taskId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TaskDependency_taskId_idx" ON public."TaskDependency" USING btree ("taskId");


--
-- TOC entry 3624 (class 1259 OID 43450)
-- Name: TaskSuggestion_projectId_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TaskSuggestion_projectId_status_idx" ON public."TaskSuggestion" USING btree ("projectId", status);


--
-- TOC entry 3625 (class 1259 OID 43451)
-- Name: TaskSuggestion_sourceType_sourceId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TaskSuggestion_sourceType_sourceId_idx" ON public."TaskSuggestion" USING btree ("sourceType", "sourceId");


--
-- TOC entry 3596 (class 1259 OID 37244)
-- Name: TaskTemplate_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TaskTemplate_category_idx" ON public."TaskTemplate" USING btree (category);


--
-- TOC entry 3597 (class 1259 OID 37245)
-- Name: TaskTemplate_isBuiltIn_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TaskTemplate_isBuiltIn_idx" ON public."TaskTemplate" USING btree ("isBuiltIn");


--
-- TOC entry 3555 (class 1259 OID 24961)
-- Name: Task_priority_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Task_priority_idx" ON public."Task" USING btree (priority);


--
-- TOC entry 3556 (class 1259 OID 24962)
-- Name: Task_projectId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Task_projectId_idx" ON public."Task" USING btree ("projectId");


--
-- TOC entry 3557 (class 1259 OID 39731)
-- Name: Task_reviewStatus_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Task_reviewStatus_idx" ON public."Task" USING btree ("reviewStatus");


--
-- TOC entry 3558 (class 1259 OID 45809)
-- Name: Task_scheduledFor_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Task_scheduledFor_idx" ON public."Task" USING btree ("scheduledFor");


--
-- TOC entry 3559 (class 1259 OID 24963)
-- Name: Task_serverId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Task_serverId_idx" ON public."Task" USING btree ("serverId");


--
-- TOC entry 3560 (class 1259 OID 24960)
-- Name: Task_status_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Task_status_idx" ON public."Task" USING btree (status);


--
-- TOC entry 3602 (class 1259 OID 38264)
-- Name: WeeklyAnalytics_weekStart_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "WeeklyAnalytics_weekStart_idx" ON public."WeeklyAnalytics" USING btree ("weekStart");


--
-- TOC entry 3603 (class 1259 OID 38263)
-- Name: WeeklyAnalytics_weekStart_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "WeeklyAnalytics_weekStart_key" ON public."WeeklyAnalytics" USING btree ("weekStart");


--
-- TOC entry 3628 (class 1259 OID 44611)
-- Name: WeeklyReport_weekStart_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "WeeklyReport_weekStart_idx" ON public."WeeklyReport" USING btree ("weekStart");


--
-- TOC entry 3575 (class 1259 OID 27696)
-- Name: WorkerHealth_agentId_checkedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "WorkerHealth_agentId_checkedAt_idx" ON public."WorkerHealth" USING btree ("agentId", "checkedAt");


--
-- TOC entry 3578 (class 1259 OID 27695)
-- Name: WorkerHealth_serverId_checkedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "WorkerHealth_serverId_checkedAt_idx" ON public."WorkerHealth" USING btree ("serverId", "checkedAt");


--
-- TOC entry 3649 (class 2620 OID 31952)
-- Name: ExecutionLog execution_log_search_vector_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER execution_log_search_vector_trigger BEFORE INSERT OR UPDATE ON public."ExecutionLog" FOR EACH ROW EXECUTE FUNCTION public.execution_log_search_vector_update();


--
-- TOC entry 3642 (class 2606 OID 35681)
-- Name: AgentUsageSnapshot AgentUsageSnapshot_agentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AgentUsageSnapshot"
    ADD CONSTRAINT "AgentUsageSnapshot_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES public."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3637 (class 2606 OID 24950)
-- Name: Agent Agent_serverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Agent"
    ADD CONSTRAINT "Agent_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES public."Server"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3646 (class 2606 OID 41406)
-- Name: DebtItem DebtItem_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DebtItem"
    ADD CONSTRAINT "DebtItem_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3635 (class 2606 OID 16652)
-- Name: ExecutionLog ExecutionLog_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExecutionLog"
    ADD CONSTRAINT "ExecutionLog_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public."Task"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3647 (class 2606 OID 42385)
-- Name: ImprovementCycle ImprovementCycle_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ImprovementCycle"
    ADD CONSTRAINT "ImprovementCycle_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3645 (class 2606 OID 40525)
-- Name: ProjectScan ProjectScan_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProjectScan"
    ADD CONSTRAINT "ProjectScan_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3640 (class 2606 OID 28161)
-- Name: RecoveryLog RecoveryLog_agentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RecoveryLog"
    ADD CONSTRAINT "RecoveryLog_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES public."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3641 (class 2606 OID 28156)
-- Name: RecoveryLog RecoveryLog_serverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."RecoveryLog"
    ADD CONSTRAINT "RecoveryLog_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES public."Server"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3636 (class 2606 OID 16690)
-- Name: ServerCommandLog ServerCommandLog_serverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ServerCommandLog"
    ADD CONSTRAINT "ServerCommandLog_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES public."Server"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3643 (class 2606 OID 38976)
-- Name: TaskDependency TaskDependency_dependsOnId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaskDependency"
    ADD CONSTRAINT "TaskDependency_dependsOnId_fkey" FOREIGN KEY ("dependsOnId") REFERENCES public."Task"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3644 (class 2606 OID 38971)
-- Name: TaskDependency TaskDependency_taskId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaskDependency"
    ADD CONSTRAINT "TaskDependency_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES public."Task"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3648 (class 2606 OID 43452)
-- Name: TaskSuggestion TaskSuggestion_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TaskSuggestion"
    ADD CONSTRAINT "TaskSuggestion_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3632 (class 2606 OID 24955)
-- Name: Task Task_agentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES public."Agent"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3633 (class 2606 OID 16647)
-- Name: Task Task_projectId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES public."Project"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3634 (class 2606 OID 16695)
-- Name: Task Task_serverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES public."Server"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3638 (class 2606 OID 27702)
-- Name: WorkerHealth WorkerHealth_agentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WorkerHealth"
    ADD CONSTRAINT "WorkerHealth_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES public."Agent"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3639 (class 2606 OID 27697)
-- Name: WorkerHealth WorkerHealth_serverId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WorkerHealth"
    ADD CONSTRAINT "WorkerHealth_serverId_fkey" FOREIGN KEY ("serverId") REFERENCES public."Server"(id) ON UPDATE CASCADE ON DELETE CASCADE;


-- Completed on 2026-06-11 07:14:27 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict IRA9wPhYBlg3h0vhLfvXqbu6BVoIBURTOxpL0y3gh8IpzWhIkghEYrpeJWe3fW0

